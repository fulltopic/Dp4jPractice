package rl.dqn.reinforcement.dqn.client

import java.io.{File, PrintWriter}

import rl.dqn.reinforcement.dqn.clientmdpmsg.{ActionResponse, MdpInnerState}

class MsgHelper {
  private val state = new MdpInnerState()
  private val actionHelper = new ActionParse(state)
  private val msgHelper = new MessageParser(state)
  private var oya: Int = 0 //don't what to do


  def iam(): Int = {
    state.iam
  }

  def isInReachAction(): Boolean = state.inReachAction

  //  private def turnOnReachAction(): Unit = {
  //    state.inReachAction = true
  //  }
  private def turnOffReachAction(): Unit = {
    state.inReachAction = false
    state.decideReach = false
    actionHelper.clearTry()
  }

  def reached(): Boolean = {
    MessageParseUtils.reached(state)
  }

  def getKAMsg(): String = {
    msgHelper.getKAMsg()
  }

  def getHeloMsg(userName: String): String = {
    msgHelper.getHeloMsg(userName)
  }

  def getHeloReply(msg: String): String = {
    msgHelper.getHeloReply(msg)
  }

  def getPxrMsg(): String = {
    msgHelper.getPxrMsg()
  }

  def getJoinMsg(): String = {
    msgHelper.getJoinMsg()
  }

  def getRejoinMsg(msg: String): String = {
    msgHelper.getRejoinMsg(msg)
  }

  def getIam(msg: String): Int = {
    state.iam = msgHelper.getIam(msg)
    state.iam
  }

  def getGokMsg(): String = {
    msgHelper.getGokMsg()
  }

  def getNextReadyMsg(): String = {
    msgHelper.getNextReadyMsg()
  }

  def getByeMsg(): String = {
    msgHelper.getByeMsg()
  }

  def parseTaikyokuMsg(msg: String): Unit = {
    val content = MessageParseUtils.extractMsg(msg)
    oya = content.split(" ").apply(1).trim.drop("oya=\"".length).dropRight("\"".length).toInt

    RewardLogger.writeLog(msg)
  }

  def parseNoopAction(): String = {
    actionHelper.parseNoopAction()
  }

  def genReachMsg(action: Int): String = {
    val msg = actionHelper.genReachMsg(action)
    turnOffReachAction()

    msg
  }

  def genDropOnlyMsg(action: Int): String = {
    actionHelper.genDropOnlyMsg(action)
  }

  def genStealActionMsg(action: Int): String = {
    println("deal with steal " + action)
    actionHelper.genStealActionMsg(action)
  }

  def isStealResponse(): Boolean = {
    MessageParseUtils.isStealResponse(state.state)
  }

  def isTerminalMsg(msg: String): Boolean = {
    msgHelper.isTerminalMsg(msg)
  }

  def requiresAction(msg: String): Boolean = {
    msgHelper.requiresAction(msg)
  }

  def genDropAfterReach(msg: String): String = {
    actionHelper.genDropAfterReach(msg)
  }

  def genAcceptReply(msg: String): ActionResponse = {
    actionHelper.genAcceptReply(msg)
  }

  def generateMyActionReply(msg: String): ActionResponse = {
    actionHelper.generateMyActionReply(msg)
  }

  def generatePeerActionReply(msg: String): ActionResponse = {
    actionHelper.generatePeerActionReply(msg)
  }

  def genDropActionReply(): ActionResponse = {
    actionHelper.genDropActionReply()
  }

  //  var rewardFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/testdqnmodels/rewards/reward" + System.currentTimeMillis() + ".txt"
  //  val rewardWriter = new PrintWriter(new File(rewardFileName))

  //  def writeReward(msg: String): Unit = {
  //    rewardWriter.write(msg + "\n")
  //    rewardWriter.flush()
  //  }

  def parseNoReplyMsg(msg: String): Unit = {
    msgHelper.parseNoReplyMsg(msg)
  }

  def genReachDropActionReply(): ActionResponse = {
    state.decideReach = true
    actionHelper.genReachDropActionReply()
  }

  def genReachResponse(msg: String): ActionResponse = {
    actionHelper.genReachResponse(msg)
  }

  def genAbortResponse(): ActionResponse = {
    actionHelper.genAbortResponse()
  }

  def isDropAction(action: Int): Boolean = {
    MessageParseUtils.isDropAction(action)
  }

  def isStealAction(action: Int): Boolean = {
    MessageParseUtils.isStealAction(action)
  }

  def isRonIndicator(msg: String): Boolean = {
    val isRon = MessageParseUtils.isRonIndicator(msg)

    if (isRon) {
      RewardLogger.writeLog(msg)
    }

    isRon
  }

  def isReachIndicator(msg: String): Boolean = {
    MessageParseUtils.isReachIndicator(msg)
  }

  def genRonMsg(msg: String): String = {
    actionHelper.genRonMsg(msg)
  }

  def getGameReward(msg: String): Int = {
    MessageParseUtils.getGameReward(state.iam, msg)
  }

  def genTermActionReply(msg: String, tourEnd: Boolean): ActionResponse = {
    RewardLogger.writeLog(msg)
    actionHelper.genTermActionReply(msg, tourEnd)
  }

  def parseGameEndMsg(msg: String): Int = {
    RewardLogger.writeLog(msg)
    msgHelper.parseGameEndMsg(msg)
  }

  def genGameEndReply(reward: Int, tourEnd: Boolean): ActionResponse = {
    actionHelper.genGameEndReply(reward, tourEnd)
  }

}
