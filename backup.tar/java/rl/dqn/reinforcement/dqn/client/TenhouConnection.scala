package rl.dqn.reinforcement.dqn.client

import java.net.InetSocketAddress

import akka.actor.{Actor, ActorRef}
import akka.event.Logging
import akka.io.{IO, UdpConnected}
import akka.util.ByteString
import rl.dqn.reinforcement.dqn.clientmdpmsg.ConnReady

class TenhouConnection(remote: InetSocketAddress, client: TenhouClient) extends Actor {
  val log = Logging(context.system, this)

//  val helper = new ConnectionHelper(client.userName)

  import context.system
  IO(UdpConnected) ! UdpConnected.Connect(self, remote)

  log.info("Udp connection connected to " + remote)

  def receive = {
    case UdpConnected.Connected =>
      log.info("Connection received something and transfer to ready")
      client.self ! new ConnReady()
      log.info("Sent connection ready to client")
      context.become(ready(sender))
  }

  def ready(sock: ActorRef): Receive = {
    case UdpConnected.Received(data) =>
//      log.info("Connection received message")
      processData(data.utf8String)
    case msg: String =>
      log.info("Connection received msg to be sent to server " + msg)
      sock ! UdpConnected.Send(ByteString(msg))
    case UdpConnected.Disconnect => sock ! UdpConnected.Disconnect
    case UdpConnected.Disconnected => context.stop(self)
  }

  def processData(msg: String): Unit = {
    msg match {
//      case s if ConnectionHelper.isConnMsg(s) => self ! helper.processMsg(s)
      case s if MessageParseUtils.isSceneKey(s) => client.self ! s
      case _ => log.error("Received unrecoganizable message " + msg)
    }
  }
}
