package rl.dqn.reinforcement.dqn.clientmdpmsg

class ConnReady {

}
