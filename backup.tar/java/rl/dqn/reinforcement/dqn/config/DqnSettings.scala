package rl.dqn.reinforcement.dqn.config

import rl.dqn.reinforcement.dqn.{TenhouServerIp, TenhouUserName}

object DqnSettings {
  /*
  For All
   */
  val TestName1 = "ID59DC5036-YQSVMgX6" //deprecated
  val TestName2 = "ID2E336B42-BfAf8H9F"
/*
  For cloud
 */

//  val GameEndWaitTime: Int = 3 //second
//  val KALimit: Int = 5
//  val LNLimit: Int = 10
//
//  val ServerIP = TenhouServerIp
//  val Port = 10080
//  val UserName = "ID2E336B42-BfAf8H9F"
//
//  val StartEpsilon: Float = 0.1f
//  val MinEpsilon: Float = 0.1f
//  val EpsilonScaleRate: Float = 0.05f
//  val AggressiveStealValue: Float = 0.0f
//  val UpdateTillSave: Int = 200
//  val RewardFileName = "/home/ec2-user/tenhoulogs/dqntest/rewards/cnnreward"
//  val ModelFileName = "/home/ec2-user/tenhoulogs/dqntest/models/cnnmodel"
//  val LoadModelFileName = "/home/ec2-user/tenhoulogs/dqntest/models/model1532756470038.xml"

/*
  For local
 */
  val GameEndWaitTime: Int = 3 //second
  val KALimit: Int = 5
  val LNLimit: Int = 10

  val ServerIP = TenhouServerIp
  val Port = 10080
  val UserName = TestName2

  val StartEpsilon: Float = 0.40f
  val MinEpsilon: Float = 0.1f
  val EpsilonScaleRate: Float = 0.02f
  val AggressiveStealValue: Float = 0.0f
  val UpdateTillSave: Int = 200

  val RewardFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/testdqnmodels/rewards/reward"
  val ModelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/testdqnmodels/models/model"
  val LoadModelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/testdqnmodels/models/modelaggressive1532679692515.xml" //TODO: To modify
  val LoadNNModelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/nnmodel_1533100997846.xml"
}
