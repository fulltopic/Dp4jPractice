package rl.dqn.reinforcement.dqn.mdp

import java.util.concurrent.TimeUnit

import akka.actor.{ActorSystem, Props}
import akka.pattern.Patterns
import akka.util.Timeout
import org.deeplearning4j.gym.StepReply
import org.deeplearning4j.rl4j.mdp.MDP
import org.deeplearning4j.rl4j.space.{ActionSpace, ObservationSpace}
import org.json.{JSONArray, JSONObject}
import org.nd4j.linalg.api.ndarray
import org.nd4j.linalg.api.ndarray.INDArray
import rl.dqn.reinforcement.dqn.client.TenhouClient
import rl.dqn.reinforcement.dqn.clientmdpmsg.{ActionRequest, ActionResponse}
import rl.dqn.reinforcement.dqn.client.MessageParseUtils

import scala.concurrent.{Await, Future}

class TenhouMdp extends MDP[INDArray, Int, TenhouActionSpace] {
  private[this] var done = false
  var lastStep: Int = 1
  var isReach: Boolean = false
  var lastTile: Int = MessageParseUtils.InvalidTile
  var lastActions: JSONObject = null
  var isTourEnd: Boolean = true


  val system = ActorSystem("testSystem")
  private val client = system.actorOf(Props[TenhouClient], "tenhouClient")
  println("Tenhou mdp created")


  override def getObservationSpace: ObservationSpace[INDArray] = new TenhouObservationSpace[INDArray]()

  override def getActionSpace: TenhouActionSpace = new TenhouActionSpace()

//  private def initClient(): Unit = {
  val timeout = new Timeout(100000L, TimeUnit.SECONDS) // As infinity

//  def initClient(): Unit = {

//    println("Try initClient")
//    val rspFuture: Future[AnyRef] = Patterns.ask(client, "ISCLIENTOK?", timeout)
//    val rspObj = Await.result(rspFuture, timeout.duration).asInstanceOf[String]
//    println("---------------> End of init")
//  }

//  def initClient(): Unit = {
//    if (isTourEnd) {
//      println("Try initClient")
//      val rspFuture: Future[AnyRef] = Patterns.ask(client, "ISCLIENTOK?", timeout)
//      val rspObj = Await.result(rspFuture, timeout.duration).asInstanceOf[String]
//      println("---------------> End of init")
//    }
//  }

  def initClient(): Unit = {
    if (isTourEnd) {
      println("Try initClient")
      val rspFuture: Future[AnyRef] = Patterns.ask(client, MessageParseUtils.StartConnection, timeout)
      val rspObj = Await.result(rspFuture, timeout.duration).asInstanceOf[String]
      println("-----------------> End of init")
    }
  }


  override def reset: INDArray = {
    println("in reset")
    initClient()

    val request = generateRequest(MessageParseUtils.ResetAction, lastTile)
    val rspFuture: Future[AnyRef] = Patterns.ask(client, request, timeout)
    val rspObj = Await.result(rspFuture, timeout.duration).asInstanceOf[ActionResponse]
    isReach = rspObj.isReach
    isDoneFlag = rspObj.reply.isDone
    lastTile = rspObj.tile
    lastActions = rspObj.reply.getInfo
    isTourEnd = rspObj.isTourEnd


    rspObj.reply.getObservation
  }

  override def close(): Unit = {
    //TODO: To send close to connection
  }

//  private def checkAction(actionObj: JSONObject, action: Int): Unit = {
//    val actionArray = actionObj.getJSONArray(MessageParseUtils.jsonActionKey)
//    val actions = Array.fill[Int](actionArray.length)(0)
//    for (i <- actions.indices) {
//      val item = actionArray.getInt(i)
//      actions(i) = item
//    }
//
//    val valid: Boolean = actions.count(a => {a == action}) > 0
//
//    if (!valid) {
//      throw new Exception("Invalid action: " + action + "--> " + actions.mkString(","))
//    }
//  }


  import java.util.concurrent.TimeUnit


  override def step(action: Int): StepReply[ndarray.INDArray] = {

//    println("Step in mdp")
//    checkAction(lastActions, action)
    val request = generateRequest(action, lastTile)
    val rspFuture: Future[AnyRef] = Patterns.ask(client, request, timeout)
    val rspObj = Await.result(rspFuture, timeout.duration).asInstanceOf[ActionResponse]
    isReach = rspObj.isReach
    isDoneFlag = rspObj.reply.isDone
    lastTile = rspObj.tile
    lastActions = rspObj.reply.getInfo
    isTourEnd = rspObj.isTourEnd

    rspObj.reply
  }

  private[this] def generateRequest(action: Int, tile: Int): ActionRequest = {
    new ActionRequest(action, tile, isReach)
  }

  var isDoneFlag: Boolean = false
  //TODO: Make client send isDone
  override def isDone: Boolean = isDoneFlag

  override def newInstance: TenhouMdp = new TenhouMdp()
}
