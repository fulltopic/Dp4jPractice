package rl.dqn.reinforcement.dqn.nn;

import org.deeplearning4j.rl4j.learning.sync.ExpReplay;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.indexing.INDArrayIndex;
import org.nd4j.linalg.indexing.NDArrayIndex;
import org.nd4j.linalg.primitives.Pair;
import org.deeplearning4j.gym.StepReply;
import org.deeplearning4j.rl4j.learning.Learning;
import org.deeplearning4j.rl4j.learning.sync.Transition;
import org.deeplearning4j.rl4j.learning.sync.qlearning.QLearning;
import org.deeplearning4j.rl4j.mdp.MDP;
import org.deeplearning4j.rl4j.network.dqn.IDQN;
import org.deeplearning4j.rl4j.policy.DQNPolicy;
import org.deeplearning4j.rl4j.policy.EpsGreedy;
import org.deeplearning4j.rl4j.policy.Policy;
import org.deeplearning4j.rl4j.space.DiscreteSpace;
import org.deeplearning4j.rl4j.util.DataManager;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.util.ArrayUtil;
import rl.dqn.reinforcement.dqn.client.MessageParseUtils;
import rl.dqn.reinforcement.dqn.client.RewardLogger;
import rl.dqn.reinforcement.dqn.config.DqnSettings;
import rl.dqn.reinforcement.dqn.mdp.TenhouActionSpace;
import rl.dqn.reinforcement.dqn.mdp.TenhouIntegerActionSpace;
import org.deeplearning4j.rl4j.util.Constants;
import scala.Int;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class TenhouSimpleDenseQLDiscrete extends QLearning<TenhouArray, Integer, TenhouIntegerActionSpace> {
    protected QLearning.QLConfiguration conf;
    protected DataManager dataManager;
    protected MDP<TenhouArray, Integer, TenhouIntegerActionSpace> mdp;
    protected DQNPolicy<TenhouArray> policy;

    protected int epsilonNbStep;
    protected EpsGreedy<TenhouArray, Integer, TenhouIntegerActionSpace> egPolicy;
    protected IDQN currentDQN;
    protected IDQN targetDQN;
    protected int lastAction = 0;
    protected INDArray history[] = null;
    protected INDArray rawHistory[] = null;

    protected INDArray historyInput = null;
    protected INDArray rawHistoryInput = null;

    protected double accuReward = 0;
    protected int lastMonitor = Constants.MONITOR_FREQ * (-1);

//    private String modelBaseName = "/home/zf/workspaces/workspace_java/tenhoulogs/testdqnmodels/model";
    protected int updatedCounter = 0;
    protected static int UpdateTillSave = DqnSettings.UpdateTillSave();

    public TenhouSimpleDenseQLDiscrete(QLearning.QLConfiguration conf, MDP<TenhouArray, Integer, TenhouIntegerActionSpace> mdp, IDQN dqn, DataManager dataManager) {
        super(conf);
        this.conf = conf;
        this.dataManager = dataManager;
        this.mdp = mdp;
        this.policy = null;

        this.epsilonNbStep = conf.getEpsilonNbStep();
        this.currentDQN = dqn;
        this.targetDQN = dqn.clone();
        mdp.getActionSpace().setSeed(conf.getSeed());

        this.egPolicy = new TenhouEpsGreedy(dqn, conf.getUpdateStart(), epsilonNbStep, conf.getMinEpsilon(), this);
    }

//    public void setModelFileName(String fileName) {
//        this.modelBaseName = fileName;
//    }

    public MDP<TenhouArray, Integer, TenhouIntegerActionSpace> getMdp(){
      return mdp;
    }

    public IDQN getTargetDQN() {
        return targetDQN;
    }

    public IDQN getCurrentDQN() {
        return currentDQN;
    }

    public Policy<TenhouArray, Integer> getPolicy() {
        return null;
    }

    public DataManager getDataManager() {
        return dataManager;
    }

    public EpsGreedy<TenhouArray, Integer, TenhouIntegerActionSpace> getEgPolicy() {
        return egPolicy;
    }

    public QLConfiguration getConfiguration() {
        return conf;
    }

    public void setTargetDQN(IDQN dqn) {
        targetDQN = dqn;
    }

    public void postEpoch() {

        if (getHistoryProcessor() != null)
            getHistoryProcessor().stopMonitor();

    }

    public void preEpoch() {
        historyInput = null;
        rawHistoryInput = null;
        history = null;
        lastAction = 0;
        accuReward = 0;

        if (getStepCounter() - lastMonitor >= Constants.MONITOR_FREQ && getHistoryProcessor() != null
                && getDataManager().isSaveData()) {
            lastMonitor = getStepCounter();
            int[] shape = getMdp().getObservationSpace().getShape();
            getHistoryProcessor().startMonitor(getDataManager().getVideoDir() + "/video-" + getEpochCounter() + "-"
                    + getStepCounter() + ".mp4", shape);
        }
    }


    public static INDArray getNNInput(INDArray input)  {
        INDArray nnInput = input.dup();

        for (int i = 0; i < nnInput.shape()[1]; i ++) {
            double v = nnInput.getDouble(0, i);
            double remain = v - (double)((int)v);
            double nv = ((double)((int)v & 7) + remain) / 4.0;
            nnInput.putScalar(0, i, nv);
        }

//        System.out.println("Shape " + nnInput.shape().length);
//        for(int i = 0; i < nnInput.shape().length; i ++) {
//            System.out.print(nnInput.shape()[i] + ", ");
//        }
//        System.out.println("");

        return nnInput;
    }


    protected int transSize = 0;
    public QLearning.QLStepReturn<TenhouArray>  trainStep(TenhouArray obs){
        int action = 0;
        INDArray rawInput = getInput(obs);
        INDArray input = getNNInput(rawInput);

//        boolean isHistoryProcessor = false;

        int skipFrame = 1;
        int historyLength = 1;
        int updateStart = getConfiguration().getUpdateStart()
                + ((getConfiguration().getBatchSize() + historyLength) * skipFrame);

        Double maxQ = Double.NaN;

        if(historyInput == null) {
            historyInput = input;
            rawHistoryInput = rawInput;
            history = new INDArray[] {rawInput};
        }

        System.out.println("input: " + historyInput);
        System.out.println("rawInput: " + rawHistoryInput);


        INDArray qs = getCurrentDQN().output(historyInput);
        int maxAction = Learning.getMaxAction(qs);
        maxQ = qs.getDouble(maxAction);
        action = getEgPolicy().nextAction(rawHistoryInput);
        System.out.println("qs " + qs);
        System.out.println("maxAction " + maxAction);
        System.out.println("maxQ " + maxQ);
        System.out.println("action " + action);

        lastAction = action;
        StepReply<TenhouArray> stepReply = getMdp().step(action);
        accuReward += stepReply.getReward() * conf.getRewardFactor();
        System.out.println("The reward " + accuReward);

        RewardLogger.writeLog("maxQ: " + maxQ);
        RewardLogger.writeLog("reward: " + accuReward);

        INDArray rawNInput = getInput(stepReply.getObservation());
        INDArray nInput = getNNInput(rawNInput);
        INDArray[] nHistory = new INDArray[] {rawNInput};
        //TODO: nHistory should be the last history, not that one for nInput
        Transition<Integer> trans = new Transition<>(history, action, accuReward, stepReply.isDone(), rawNInput);
        getExpReplay().store(trans);
        transSize ++;

//        System.out.println("Get counter " + getStepCounter() + ", " + updateStart);
//        if (getStepCounter() > updateStart) {
        if (stepReply.isDone()){
            System.out.println("UPDATE tenhou simple dense dqn NN");
            Pair<INDArray, INDArray> targets = setTarget(((ExpReplay)getExpReplay()).getBatch(transSize));
            transSize = 0;

            getCurrentDQN().fit(targets.getFirst(), targets.getSecond());

            updatedCounter ++;
            if (updatedCounter > UpdateTillSave) {
                updatedCounter = 0;

                String currFileName = DqnSettings.ModelFileName() + System.currentTimeMillis() + ".xml";
                try {
//                    getCurrentDQN()
//                    currentDQN.
                    System.out.println("Save model into "+ currFileName);
                    getCurrentDQN().save(currFileName);
                }catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        historyInput = nInput;
        rawHistoryInput = rawNInput;
        accuReward = 0;
        history = nHistory;

        return new QLStepReturn<>(maxQ, getCurrentDQN().getLatestScore(), stepReply);
    }

    protected void printShape(INDArray data, String comment) {
        System.out.println(comment);
        int[] shape = data.shape();
        System.out.println("------------------>" + shape.length);
        for (int i = 0; i < shape.length; i ++) {
            System.out.println(shape[i]);
        }
    }

    protected Pair<INDArray, INDArray> setTarget(ArrayList<Transition<Integer>> transitions) {
        System.out.println("---------------------------------------> setTarget");
        if (transitions.size() == 0) {
            System.out.println("To throw exception");
            throw new IllegalArgumentException("too few transitions");
        }

        int size = transitions.size();

        int[] shape = getHistoryProcessor() == null ? getMdp().getObservationSpace().getShape()
                : getHistoryProcessor().getConf().getShape();
        int[] nshape = makeShape(size, shape);
        INDArray obs = Nd4j.create(nshape);
        INDArray nextObs = Nd4j.create(nshape);
        int[] actions = new int[size];
        boolean[] areTerminal = new boolean[size];
        printShape(obs, "obs");
        printShape(nextObs, "nextObs");

//        List transIndex = new ArrayList<Integer>();
//        for (int i = 0; i < size; i ++) {
//            transIndex.add(i);
//        }
//        Collections.shuffle(transIndex);

        for (int i = 0; i < size; i++) {
            Transition<Integer> trans = transitions.get(i);
            areTerminal[i] = trans.isTerminal();
            actions[i] = trans.getAction();

            INDArray[] obsArray = trans.getObservation();
            obs.putRow(i, getNNInput(obsArray[0]));

            nextObs.putRow(i, getNNInput(trans.getNextObservation()));
        }

        INDArray dqnOutputAr = dqnOutput(obs);
        INDArray dqnOutputNext = dqnOutput(nextObs);

        System.out.println("obs " + obs);
        System.out.println("nextObs " + nextObs);

        double[] tempQ = new double[size];
        for (int i = 0; i < size; i ++) {
            org.nd4j.linalg.primitives.Pair<Double, Integer> tempPair = MessageParseUtils.getLegalQAction(transitions.get(i).getNextObservation(), dqnOutputNext.getRow(i));
            tempQ[i] = tempPair.getFirst();
        }

//        printShape(getMaxAction, "getMaxAction");
//        printShape(tempPair.getKey(), "tempQ");

        for (int i = 0; i < size; i++) {
            double yTar = transitions.get(i).getReward();
            if (!areTerminal[i]) {
                double q = tempQ[i];
                yTar += getConfiguration().getGamma() * q;
            }


            if(dqnOutputAr.shape().length > 2) {
                double previousV = dqnOutputAr.getDouble(i, actions[i], 0);

                double lowB = previousV - getConfiguration().getErrorClamp();
                double highB = previousV + getConfiguration().getErrorClamp();
                double clamped = Math.min(highB, Math.max(yTar, lowB));

                dqnOutputAr.putScalar(i, actions[i], 0, clamped);
            }
            else {
                double previousV = dqnOutputAr.getDouble(i, actions[i]);
                double lowB = previousV - getConfiguration().getErrorClamp();
                double highB = previousV + getConfiguration().getErrorClamp();
                double clamped = Math.min(highB, Math.max(yTar, lowB));

                dqnOutputAr.putScalar(i, actions[i], clamped);
            }
        }

        printShape(dqnOutputAr, "dqnOutputAr");


        return new Pair<>(obs, dqnOutputAr);
    }


}
