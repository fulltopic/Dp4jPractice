package rl.dqn.reinforcement.dqn.nn;

import org.deeplearning4j.rl4j.learning.sync.Transition;
import org.deeplearning4j.rl4j.learning.sync.qlearning.QLearning;
import org.deeplearning4j.rl4j.mdp.MDP;
import org.deeplearning4j.rl4j.network.dqn.IDQN;
import org.deeplearning4j.rl4j.util.DataManager;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.primitives.Pair;
import rl.dqn.reinforcement.dqn.client.MessageParseUtils;
import rl.dqn.reinforcement.dqn.mdp.TenhouIntegerActionSpace;

import java.util.ArrayList;

public class TenhouSimpleDoubleDenseQLDiscrete extends TenhouSimpleDenseQLDiscrete {
    public TenhouSimpleDoubleDenseQLDiscrete(QLearning.QLConfiguration conf, MDP<TenhouArray, Integer, TenhouIntegerActionSpace> mdp, IDQN dqn, DataManager dataManager) {
        super(conf, mdp, dqn, dataManager);
    }

    protected Pair<INDArray, INDArray> setTarget(ArrayList<Transition<Integer>> transitions) {
        System.out.println("---------------------------------------> setTarget");
        if (transitions.size() == 0) {
            System.out.println("To throw exception");
            throw new IllegalArgumentException("too few transitions");
        }

        int size = transitions.size();

        int[] shape = getHistoryProcessor() == null ? getMdp().getObservationSpace().getShape()
                : getHistoryProcessor().getConf().getShape();
        int[] nshape = makeShape(size, shape);
        INDArray obs = Nd4j.create(nshape);
        INDArray nextObs = Nd4j.create(nshape);
        int[] actions = new int[size];
        boolean[] areTerminal = new boolean[size];
        printShape(obs, "obs");
        printShape(nextObs, "nextObs");


        for (int i = 0; i < size; i++) {
            Transition<Integer> trans = transitions.get(i);
            areTerminal[i] = trans.isTerminal();
            actions[i] = trans.getAction();

            INDArray[] obsArray = trans.getObservation();
            obs.putRow(i, getNNInput(obsArray[0]));

            nextObs.putRow(i, getNNInput(trans.getNextObservation()));
        }

        INDArray dqnOutputAr = dqnOutput(obs);
        INDArray dqnOutputNext = targetDqnOutput(nextObs);

        System.out.println("obs " + obs);
        System.out.println("nextObs " + nextObs);



        double[] tempQ = new double[size];
        for (int i = 0; i < size; i ++) {
            org.nd4j.linalg.primitives.Pair<Double, Integer> tempPair = MessageParseUtils.getLegalQAction(transitions.get(i).getNextObservation(), dqnOutputNext.getRow(i));
            tempQ[i] = tempPair.getFirst();
        }

//        printShape(getMaxAction, "getMaxAction");
//        printShape(tempPair.getKey(), "tempQ");

        for (int i = 0; i < size; i++) {
            double yTar = transitions.get(i).getReward();
            if (!areTerminal[i]) {
                double q = tempQ[i];
                yTar += getConfiguration().getGamma() * q;
                System.out.println("q = " + q + ", yTar = " + yTar);
            }


            if(dqnOutputAr.shape().length > 2) {
                double previousV = dqnOutputAr.getDouble(i, actions[i], 0);

                double lowB = previousV - getConfiguration().getErrorClamp();
                double highB = previousV + getConfiguration().getErrorClamp();
                double clamped = Math.min(highB, Math.max(yTar, lowB));

                dqnOutputAr.putScalar(i, actions[i], 0, clamped);
            }
            else {
                double previousV = dqnOutputAr.getDouble(i, actions[i]);
                double lowB = previousV - getConfiguration().getErrorClamp();
                double highB = previousV + getConfiguration().getErrorClamp();
                double clamped = Math.min(highB, Math.max(yTar, lowB));

                dqnOutputAr.putScalar(i, actions[i], clamped);
            }
        }

        printShape(dqnOutputAr, "dqnOutputAr");


        return new Pair<>(obs, dqnOutputAr);
    }

}
