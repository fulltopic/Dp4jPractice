package rl.dqn.reinforcement

package object dqn {
  val TestPort: Int = 52222
  val TestServerIp = "localhost"
  val TestUserName: String = "test"
  val KASnap: Int = 15


  val LocalProxy = "localhost"
  val TenhouServerIp = "133.242.10.78"
  val TenhouPort = 10080
  val TenhouUserName = "ID59DC5036-YQSVMgX6"
//  val TenhouUserName = "NoName"

}
