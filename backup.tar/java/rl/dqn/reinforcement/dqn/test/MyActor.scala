package rl.dqn.reinforcement.dqn.test

import java.net.InetSocketAddress

import akka.actor.{Actor, ActorRef, Props}
import akka.event.Logging
import akka.io.{IO, Udp, UdpConnected}
import akka.util.ByteString
import rl.dqn.reinforcement.dqn._


class MyActor extends Actor {
    val log = Logging(context.system, this)
  val remote = new InetSocketAddress(TestServerIp, TestPort)
  import context.system
  IO(UdpConnected) ! UdpConnected.Connect(self, remote)
  log.info("Connection request sent")

  def receive = {
    case UdpConnected.Connected =>
      log.info("Simple sender ready")
      context.become(ready(sender()))
//    case msg: String =>
//      log.info("To send to server " + msg)
//      sender ! Udp.Send(ByteString(msg), remote)
//      sender() ! Udp.Send(ByteString("hello"), remote )
  }

  def dummy(s: AnyRef): Unit = {
    log.info("dummy received " + s)
  }

  def ready(send:ActorRef): Receive = {
    case UdpConnected.Received(data) =>
      val processed = data.utf8String
      log.info("Server reply " + processed)
//      send ! Udp.Send(ByteString("INIT" + processed), remote)
    case msg: String =>
      log.info("To send to server " + msg)
      //      send ! Udp.Send(ByteString(msg), remote)
      send ! UdpConnected.Send(ByteString(msg))
    case Udp.Unbind =>
      log.info("Unbind")
      send ! Udp.Unbind
    case Udp.Unbound =>
      log.info("unbound")
      context.stop(self)
    case _      =>
      dummy(send)
      send ! Udp.Send(ByteString("Unknown"), remote)
  }
}
