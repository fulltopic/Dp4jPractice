package rl.dqn.reinforcement.dqn.test

import org.json.JSONObject
import org.nd4j.linalg.api.ndarray.INDArray
import rl.dqn.reinforcement.dqn.client.MessageParseUtils
import rl.dqn.reinforcement.dqn.mdp.TenhouMdp
import rl.dqn.supervised._

import scala.util.Random

class RandomNN {
  val mdp = new TenhouMdp()
  Thread.sleep(3000)
  var done: Boolean = false
  val actionRandom = new Random(53)
  var lastState: INDArray = null

  private def getStealTiles(): Array[Int] = {
    (for (i <- 0 until TileNum if math.floor(lastState.getDouble(i)) < lastState.getDouble(i)) yield  i).toArray
  }

//  private def canChow(tile: Int): Boolean = {
//    for (i <- math.max(0, tile - 2) to math.min(tile, 27 - 2 - 1)) {
//      if ((i to i + 2).forall(index => index != tile || (lastState.getDouble(index).toInt & ExtraValueFlag) > 0)) {
//        return true
//      }
//    }
//
//    false
//  }
//
//  private def canPong(tile: Int): Boolean = {
//    math.floor(lastState.getDouble(tile)) >= 2
//  }

  private def getAvailableActions(): Int = {
//    var actions = List.empty[Int]
//
//    // Reach
//    if (lastState.getDouble(PeerReachIndex) > math.floor(lastState.getDouble(PeerReachIndex))) {
//      println("----------------> Reach action")
//      actions = List[Int](REACHWoAccept, NOOPWoAccept)
//    }
//    else if(getStealTiles().length > 0) { // Steal
//      val candidates = getStealTiles()
//      println("----------------> Get steal tiles " + candidates.mkString(", "))
//
//      val stealTile = candidates.head
//      val delta = lastState.getDouble(stealTile) - math.floor(lastState.getDouble(stealTile))
//      println("----------------> Get steal tile and delta " + stealTile + ", " + delta)
//      if (delta == MessageParseUtils.pongValue) {
//        actions = actions :+ PongWoAccept
//      } else if (delta == MessageParseUtils.chowValue) {
//        actions = actions :+ ChowWoAccept
//      }else if (delta == MessageParseUtils.chowValue + MessageParseUtils.pongValue) {
//        actions = actions :+ PongWoAccept
//        actions = actions :+ ChowWoAccept
//      }
//      actions = actions :+ NOOPWoAccept
//    }else { //Drop
//      println("----------------------> Drop actions")
//      actions = (for (i <- 0 until TileNum if (lastState.getDouble(i).toInt & ExtraValueFlag) > 0) yield i).toList
//    }
//
//    println("Available actions: ", actions.mkString(","))

    val actions = MessageParseUtils.getAvailableActions(lastState)

    actions(actionRandom.nextInt(actions.length))
  }


  private def callSteps(): Unit = {
    while (!mdp.isDone) {
      val action = getAvailableActions()
      val reply = mdp.step(action)
      lastState = reply.getObservation
    }
  }

  def steps(): Unit = {
    while (true) {
      lastState = mdp.reset()
      callSteps()
    }
  }
}
