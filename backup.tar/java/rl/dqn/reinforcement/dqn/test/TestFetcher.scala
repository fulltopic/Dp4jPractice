package rl.dqn.reinforcement.dqn.test

import org.deeplearning4j.datasets.iterator.BaseDatasetIterator
import org.nd4j.linalg.factory.Nd4j
import rl.dqn.reinforcement.dqn.nn.datapocess.TenhouXmlFectcher

object TestFetcher extends App{
  Nd4j.zeros(2)

  val dirPath = "/home/ec2-user/tenhoulogs/xmlfiles/trainwrapper/"
  val fetcher = new TenhouXmlFectcher(dirPath)

  val trainIte = new BaseDatasetIterator(16, 2, fetcher)

  var count: Int = 0
  while (trainIte.hasNext && count < 1) {
    val dataset = trainIte.next()
    println("Features: ")
    println(dataset.getFeatureMatrix)
    println("Labels: ")
    println(dataset.getLabels)
    count += 1
  }

}
