package rl.dqn.reinforcement.dqn.test;

import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.IntStream;

public class TestRandomInt {
    public static void main(String[] args) {
        int storageSize = 8;
        int size = 7;
        int actualSize = Math.min(storageSize, size);

       IntStream a =  ThreadLocalRandom.current().ints(0, storageSize).distinct().limit(actualSize);
       int[] b = a.toArray();

       for (int i = 0; i < b.length; i ++) {
           System.out.println(b[i]);
       }
    }
}
