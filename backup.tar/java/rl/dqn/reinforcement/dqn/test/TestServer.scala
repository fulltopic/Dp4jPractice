package rl.dqn.reinforcement.dqn.test

import java.io.{BufferedReader, InputStreamReader}
import java.net.InetSocketAddress

import akka.actor.{Actor, ActorRef}
import akka.event.Logging
import akka.io.{IO, Udp}
import akka.util.ByteString
import rl.dqn.reinforcement.dqn._

import scala.io.Source

class TestServer(index: Int) extends Actor{
  val log = Logging(context.system, this)

  val fileName = "/home/zf/workspaces/workspace_java/tenhoulogs/clienttest/test" + index + "p.txt"
  var lines = Source.fromFile(fileName).getLines().toList

  import context.system
  IO(Udp) ! Udp.Bind(self, new InetSocketAddress(TestServerIp, TestPort))
  log.info("Server bind tried")

  def receive = {
    case Udp.Bound(local) =>
      log.info("In receive")
      context.become(ready(sender()))
  }

  def dummy(socket: ActorRef): Unit = {
    log.info("dummy")
  }

  def extractMsg(msg: String): String = {
    msg.drop("<".length).dropRight("/>".length).trim
  }

  def getDTile(msg: String): Int = {
    msg.split(" ").map(_.trim).apply(1).drop("p=\"".length).dropRight("\"".length).toInt
  }

  def getReachTile(msg: String): Int = {
    msg.split(" ").map(_.trim).apply(1).drop("hai=\"".length).dropRight("\"".length).toInt
  }

  def getNTile(msg: String, index: Int): Int = {
    msg.split(" ").map(_.trim).apply(index + 2).drop("hai0=\"".length).dropRight("\"".length).toInt
  }

  def msgMatch(expected: String, actual: String): Boolean = {
    var matched: Boolean = false
    if (expected.equals(actual)){
      matched = true
    }
    else {
      val e = expected.drop(1).dropRight(2).trim
      val a = actual.drop(1).dropRight(2).trim

      if (e.equals(a)) matched = true
      else {
        if (e.startsWith("REACH") && a.startsWith("REACH")) {
          val eTile = getReachTile(e)
          val aTile = getReachTile(a)
          if (aTile / 4 == eTile / 4) matched = true
        }else if (e.startsWith("D") && a.startsWith("D")) {
          val eTile = getDTile(e)
          val aTile = getDTile(a)
          if (aTile / 4 == eTile / 4) matched = true
        }else if (e.startsWith("N") && a.startsWith("N")) {
          if (e.split(" ").length >= 4) {
            val eTile0 = getNTile(e, 0)
            val eTile1 = getNTile(e, 1)
            val aTile0 = getNTile(a, 0)
            val aTile1 = getNTile(a, 1)

            if (aTile0 / 4 == eTile0 / 4 && eTile1 / 4 == aTile1 / 4) matched = true
          }
        }
      }
    }

    matched
  }

  var client: InetSocketAddress = null
  def ready(socket: ActorRef): Receive = {
    case Udp.Received(data, remote) =>
      log.info("Server received " + data.utf8String)
      val line = lines.head
      if (line.startsWith("Send")) {
        if (line.contains("<Z")) {
          //do nothing
        }else {
          val content = line.drop("Send: ".length)
          if(msgMatch(content, data.utf8String.toString)) {
            lines = lines.tail
            while (lines.head.startsWith("Get")) {
              val sendMsg = lines.head.drop("Get: ".length)
              socket ! Udp.Send(ByteString(sendMsg), remote)
              Thread.sleep(1000)
              lines = lines.tail
            }

            println("To receive " + content)
            if (content.equals("<N type=\"6\" />")) {
//              println("CONTENT EQUALS " + lines.head)
              if (lines.head.contains("<N")) {
//                println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Received discard ron")
                lines = "Send: <N />" +: lines.tail
//                println("new lines  " + lines.head)
//                println(lines.tail.head)
              }
            }
          }else {
            println("TestServer Received unexpected message ")
            println("--> " + content)
            println("--> " + data.utf8String)
          }
        }
      }else {

      }
      client = remote
    case msg: String =>
      log.info("Received a message from queue")
//      socket ! Udp.Send(ByteString(msg), client)
    case Udp.Unbind =>
      log.info("Unbind")
      socket ! Udp.Unbind
    case Udp.Unbound =>
      log.info("unbound")
      context.stop(self)
    case _ => dummy(socket)
  }
}
