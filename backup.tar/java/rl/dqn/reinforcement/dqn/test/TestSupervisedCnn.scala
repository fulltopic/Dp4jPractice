package rl.dqn.reinforcement.dqn.test

import java.io.{File, FileOutputStream, PrintWriter}

import org.deeplearning4j.datasets.fetchers.BaseDataFetcher
import org.deeplearning4j.datasets.iterator.BaseDatasetIterator
import org.deeplearning4j.nn.api.OptimizationAlgorithm
import org.deeplearning4j.nn.conf.inputs.InputType
import org.deeplearning4j.nn.conf._
import org.deeplearning4j.nn.conf.layers._
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import org.deeplearning4j.nn.weights.WeightInit
import org.deeplearning4j.ui.api.UIServer
import org.deeplearning4j.ui.stats.StatsListener
import org.deeplearning4j.ui.storage.InMemoryStatsStorage
import org.deeplearning4j.util.ModelSerializer
import org.nd4j.linalg.activations.Activation
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.lossfunctions.LossFunctions
import rl.dqn.reinforcement.dqn.nn.datapocess.{TenhouXmlCnnFetcher, TenhouXmlFectcher}
import rl.dqn.supervised.{ActionLenWoAccept, PeerStateLen, TileNum}

import scala.util.Random

object TestSupervisedCnn  {
  def getRandomParam[T](params: Array[T]): T = {
    params(Random.nextInt(params.length))
  }

  def createRandomCnnModel(outputLen: Int): MultiLayerNetwork = {
    val paramStr = new StringBuffer()
    paramStr.append("outputLen: " + outputLen + ", ")

    val learningRates = Array[Double](0.01, 0.02, 0.05, 0.1, 0.5, 1)
    val learningRate = getRandomParam(learningRates)
    paramStr.append("learningRate: " + learningRate + ", ")

    val listBuilder = new NeuralNetConfiguration.Builder()
      .learningRate(learningRate)
      .iterations(10)
      .seed(47)
      .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .updater(Updater.ADAGRAD)
      .weightInit(WeightInit.XAVIER)
      .regularization(true)
      .l2(0.0005)
      .list()

    val denseLayerNums = Array[Int](1, 2)
    val cnnLayerNums = Array[Int](0, 1, 2)

    val cnnHiddenNodes = Array[Int](64, 128, 256, 512)
    val denseHiddenNodes = Array[Int](64, 128, 256, 512) //TODO: The rule to set these sequence?
    val subsampleFuncs = Array(SubsamplingLayer.PoolingType.MAX, SubsamplingLayer.PoolingType.AVG)

    var layerIndex: Int = 0
    val subsampleExists = Array[Boolean](true, false)
    val kernelSizes = Array[Int](3)

    val cnnLayerNum = getRandomParam(cnnLayerNums)
    paramStr.append("cnnLayerNum " + cnnLayerNum + ", ")

    for (i <- 0 until cnnLayerNum) {
      val hiddenNode = getRandomParam(cnnHiddenNodes)
      paramStr.append("cnnNode" + layerIndex+ ": " + hiddenNode + ", ")
      var kernelSize = getRandomParam(kernelSizes)

      if (i == 0) {
        kernelSize = 3
      }else if (i == 1) {
        kernelSize = 9
      }

      paramStr.append("kernelSize" + layerIndex + ": " + kernelSize + ", ")

      var layer: ConvolutionLayer = null

      if (i == 0) {
        layer = new ConvolutionLayer.Builder(1, kernelSize)
          //                            .padding(0, 1)
          .nIn(1)
          .nOut(hiddenNode)
          .activation(Activation.RELU)
          .build()
      }else {
        layer = new ConvolutionLayer.Builder(1, kernelSize)
          //                            .padding(0, 1)
          .nOut(hiddenNode)
          .stride(1,9)
          .activation(Activation.RELU)
          .build()
      }

      listBuilder.layer(layerIndex, layer)
      layerIndex += 1

      if (getRandomParam(subsampleExists)) {
        val subSampleFuncIndex = Random.nextInt(subsampleFuncs.length)
        val subsampleFunc = subsampleFuncs(subSampleFuncIndex)
//        var subKernelSize: Int = 0
        val subKernelSize = getRandomParam(kernelSizes)

        paramStr.append("subsampleFunc" + layerIndex + ": " + subSampleFuncIndex + ", ")
        paramStr.append("kernelSize" + layerIndex + ": " + subKernelSize + ", ")

        val subLayer = new SubsamplingLayer.Builder(subsampleFunc)
              .kernelSize(1, subKernelSize)
              .build()

        listBuilder.layer(layerIndex, subLayer)
        layerIndex += 1
      }
    }

    val denseLayerNum = getRandomParam(denseLayerNums)
    paramStr.append("denseLayerNum" + layerIndex + ": " + denseLayerNum + ", ")

    for (i <- 0 until denseLayerNum) {
      val hiddenNode = getRandomParam(denseHiddenNodes)
      paramStr.append("hiddenNode" + layerIndex + ": " + hiddenNode + ", ")

      var layer: DenseLayer = null
      if (i == 0 && cnnLayerNum == 0) {
        layer = new DenseLayer.Builder().nIn(PeerStateLen).nOut(hiddenNode).activation(Activation.RELU).build()
      }else {
        layer = new DenseLayer.Builder().nOut(hiddenNode).activation(Activation.RELU).build()
      }
      listBuilder.layer(layerIndex, layer)
      layerIndex += 1
    }

    val outputLayer = new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD).nOut(outputLen).activation(Activation.SOFTMAX).build()
    listBuilder.layer(layerIndex, outputLayer)

    var mlnConf: MultiLayerConfiguration = null
    if (cnnLayerNum > 0) {
      mlnConf = listBuilder.setInputType(InputType.convolutionalFlat(1, PeerStateLen, 1))
        .pretrain(false).backprop(true).build
    }else {
      mlnConf = listBuilder.pretrain(false).backprop(true).build
    }
    SupervisedLogger.writeLog(paramStr.toString)

    mlnConf.setTrainingWorkspaceMode(WorkspaceMode.SEPARATE)
    val model = new MultiLayerNetwork(mlnConf)
    model.init()

    model
  }





  def createCnnModel(outputLen: Int): MultiLayerNetwork = {

    val hiddenNode: Int = 256

    val startLr: Double = 0.01
    //    val lastDnnAct = Activation.TANH
    //    val lossFunc = LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD

    //    println("" + hiddenNode + ", " + denseLayerNum + ", " + lstmSize + ", " + startLr + ", " + lastDnnAct + ", " + lossFunc)

    val lrShedule: java.util.Map[Integer, java.lang.Double] = new java.util.HashMap[Integer, java.lang.Double]()
    lrShedule.put(0, startLr)
    lrShedule.put(40000, startLr / 2)
    lrShedule.put(100000, startLr / 4)

    val listBuilder = new NeuralNetConfiguration.Builder()
      .learningRateDecayPolicy(LearningRatePolicy.Schedule)
      .learningRateSchedule(lrShedule)
      //      .learningRate(0.05)
      .iterations(1)
      .seed(47)
      .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .updater(Updater.ADAGRAD)
      .weightInit(WeightInit.XAVIER)
      .regularization(true)
      .l2(0.0005)
      .list()

    listBuilder.layer(0, new ConvolutionLayer.Builder(1, 3)
      //                            .padding(0, 1)
      .nIn(1)
      .nOut(hiddenNode)
      .activation(Activation.RELU)
      .build())
    //    listBuilder.layer(1, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
    //      .kernelSize(1, 3)
    //      .build())
    //
    //    listBuilder.layer(2, new ConvolutionLayer.Builder(1, 2)
    //          .nOut(256)
    //          .activation(Activation.RELU)
    //          .build())
    //    listBuilder.layer(3, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
    //          .kernelSize(1, 2)
    //          .build())

    //    val denseLayer = new DenseLayer.Builder().nOut(hiddenNode).activation(Activation.RELU).build()
    listBuilder.layer(1, new DenseLayer.Builder().nOut(hiddenNode).activation(Activation.RELU).build())
    listBuilder.layer(2,
      new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD).nIn(hiddenNode).nOut(outputLen).activation(Activation.SOFTMAX).build())

    val mlnConf = listBuilder.setInputType(InputType.convolutionalFlat(1, PeerStateLen, 1))
      .pretrain(false).backprop(true).build
    mlnConf.setTrainingWorkspaceMode(WorkspaceMode.SEPARATE)
    val model = new MultiLayerNetwork(mlnConf)
    model.init()

    model
  }


  var trainPath: String = ""
  var validPath: String = ""
  var modelPath: String = ""
  var logFile: PrintWriter = null;

  def initLocalPath(): Unit = {
    trainPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/train/"
    validPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/validation/"
    modelPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/models/model"
    logFile = new PrintWriter(new File("/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/output.txt"))
  }

  def initCloudPath(): Unit = {
    trainPath = "/home/ec2-user/tenhoulogs/xmlfiles/trainwrapper/"
    validPath = "/home/ec2-user/tenhoulogs/xmlfiles/validwrapper/"
    modelPath = "/home/ec2-user/tenhoulogs/xmlfiles/models/"
    logFile = new PrintWriter(new File("/home/ec2-user/tenhoulogs/xmlfiles/output.txt"))
  }


//  def writeLog(content: String): Unit = {
//    logFile.write(content + "\n")
//    logFile.flush()
//  }

  def train(model: MultiLayerNetwork, trainFetcher: BaseDataFetcher, validFetcher: BaseDataFetcher): Unit = {
    Nd4j.zeros(2)
    println("----------------------------------------> " + trainPath)
    println("----------------------------------------> " + validPath)

    val batchSize = 64
    val numExamples = 1
    val epochNum: Int = 4

    //    val trainFetcher = new TenhouXmlFectcher(trainPath, toRandom)
    val trainIte = new BaseDatasetIterator(batchSize, numExamples, trainFetcher)

    //    val validFetcher = new TenhouXmlFectcher(validPath, toRandom)
    val validIte = new BaseDatasetIterator(batchSize, numExamples, validFetcher)


    //    val model = createModel()

    val uiServer = UIServer.getInstance
    val statsStorage = new InMemoryStatsStorage
    uiServer.attach(statsStorage)
    model.setListeners(new StatsListener(statsStorage))

    for (i <- 0 until epochNum) {
      trainIte.reset()
      model.fit(trainIte)

      validIte.reset()
      val eval = model.evaluate(validIte)
      //      val eval = new Evaluation()
      //      model.doEvaluation(validIte, eval)


      val stat = eval.stats()
      SupervisedLogger.writeLog("=========================================> Evaluation")
      SupervisedLogger.writeLog(stat)
      println(stat)

//      val MJModelFile = new File(modelPath + "_" + System.currentTimeMillis() + ".xml")
//      val fos = new FileOutputStream(MJModelFile)
//      ModelSerializer.writeModel(model, fos, true)
    }

    SupervisedLogger.writeLog("::::::::::::::::::::::::::::::::::::::::: End of training")
  }

  def main(args: Array[String]): Unit = {
//    initLocalPath()
          initCloudPath()
    val outputLen: Int = TileNum
    val trainFetcher = new TenhouXmlCnnFetcher(trainPath, outputLen)
    val validFetcher = new TenhouXmlCnnFetcher(validPath, outputLen)
//    train(createCnnModel(outputLen), trainFetcher, validFetcher)
    for (i <- 0 until 20) {
      train(createRandomCnnModel(outputLen), trainFetcher, validFetcher)
    }

    System.exit(0)
  }
}
