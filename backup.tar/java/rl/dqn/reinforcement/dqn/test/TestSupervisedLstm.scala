package rl.dqn.reinforcement.dqn.test

import java.io.{File, PrintWriter}
import java.util

import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import rl.dqn.reinforcement.dqn.nn.datapocess.TenhouLstmIterator
import org.deeplearning4j.nn.api.OptimizationAlgorithm
import org.deeplearning4j.nn.conf._
import org.deeplearning4j.nn.conf.layers._
import org.deeplearning4j.nn.conf.preprocessor.RnnToFeedForwardPreProcessor
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import org.deeplearning4j.nn.weights.WeightInit
import org.deeplearning4j.ui.api.UIServer
import org.deeplearning4j.ui.stats.StatsListener
import org.deeplearning4j.ui.storage.InMemoryStatsStorage
import org.deeplearning4j.util.ModelSerializer
import org.nd4j.linalg.activations.Activation
import org.nd4j.linalg.lossfunctions.LossFunctions.LossFunction
import rl.dqn.supervised._


object TestSupervisedLstm extends  App{
  var trainPath: String = ""
  var validPath: String = ""
  var modelPath: String = ""
  var logFile: PrintWriter = null;

  def initLocalPath(): Unit = {
    trainPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/train/"
    validPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/validation/"
    modelPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/model"
    logFile = new PrintWriter(new File("/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/output.txt"))
  }

  def initCloudPath(): Unit = {
    trainPath = "/home/ec2-user/tenhoulogs/xmlfiles/trainwrapper/"
    validPath = "/home/ec2-user/tenhoulogs/xmlfiles/validwrapper/"
    modelPath = "/home/ec2-user/tenhoulogs/xmlfiles/models/bilstmmodel"
    logFile = new PrintWriter(new File("/home/ec2-user/tenhoulogs/xmlfiles/output.txt"))
  }

  def testIterator(): Unit = {
    val iterator = new TenhouLstmIterator(trainPath, 16)

    var count: Int = 0
    while (iterator.hasNext) {
//      println("" + count)
      count += 1
      iterator.next()
    }
  }

  def createSimpleModel(): MultiLayerNetwork = {
    val lstmLayerSize: Int = 256
    val tbpttLength: Int = 1

    val conf = new NeuralNetConfiguration.Builder().
      optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .iterations(1).learningRate(0.05)
      .seed(12345).regularization(true)
      .l2(0.001)
      .weightInit(WeightInit.DISTRIBUTION)
      .updater(Updater.RMSPROP)
      .list
      .layer(0, new GravesBidirectionalLSTM.Builder().nIn(PeerStateLen).nOut(lstmLayerSize).activation(Activation.TANH).build)
//      .layer(1, new GravesLSTM.Builder().nIn(lstmLayerSize).nOut(lstmLayerSize).activation(Activation.TANH).build)
      .layer(1, new RnnOutputLayer.Builder(LossFunction.MSE).activation(Activation.SOFTMAX)        //MCXENT + softmax for classification
        .nIn(lstmLayerSize).nOut(ActionLenWoAccept).build())
//      .layer(1, new DenseLayer.Builder().nOut(lstmLayerSize).activation(Activation.RELU).build())
//      .layer(2, new OutputLayer.Builder(LossFunction.NEGATIVELOGLIKELIHOOD).activation(Activation.SOFTMAX)
//        .nIn(lstmLayerSize)
//      .nOut(ActionLenWoAccept).build)
//      .backpropType(BackpropType.TruncatedBPTT)
//      .tBPTTForwardLength(tbpttLength)
//      .tBPTTBackwardLength(tbpttLength)
      .pretrain(false)
      .backprop(true).build

//    val testProcessor: InputPreProcessor = new RnnToFeedForwardPreProcessor()
//    val preMap = new util.HashMap[Integer, InputPreProcessor]()
//    preMap.put(new Integer(1), testProcessor)
//    conf.setInputPreProcessors(preMap)

    val model = new MultiLayerNetwork(conf)
    model.init()

    model
  }

  def train(model: MultiLayerNetwork): Unit = {
    val uiServer = UIServer.getInstance
    val statsStorage = new InMemoryStatsStorage
    uiServer.attach(statsStorage)
    model.setListeners(new StatsListener(statsStorage))

    val batchSize = 16
    val trainIte = new TenhouLstmIterator(trainPath, batchSize)
    val validIte = new TenhouLstmIterator(validPath, batchSize)

    //Test path
    val modelFileName = modelPath + System.currentTimeMillis() + ".txt"
    ModelSerializer.writeModel(model, modelFileName, true)

    val epochNum = 8

    for (i <- 0 until epochNum) {
      trainIte.reset()
      while (trainIte.hasNext) {
        val ds = trainIte.next()
        model.fit(ds)
      }

      validIte.reset()
      val eval = model.evaluate(validIte)
      println(eval)
      logFile.write(eval + "\n")

      val modelFileName = modelPath + System.currentTimeMillis() + ".txt"
      ModelSerializer.writeModel(model, modelFileName, true)
    }


  }

  def testSavedModel(): Unit = {
    val testFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/smalltest/"
    val modelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/bilstmmodel_bestsofar.txt"

    val model = createSimpleModel()
    val loadedeModel = ModelSerializer.restoreMultiLayerNetwork(modelFileName)
    val paramTable = loadedeModel.paramTable()
    model.setParamTable(paramTable)

    val testIterator = new TenhouLstmIterator(testFileName, 16)
    testIterator.reset()

    val eval = model.evaluate(testIterator)
    println(eval)
  }

//  initLocalPath()
//  initCloudPath()
//  train(createSimpleModel())


//  testIterator()

  testSavedModel()
}
