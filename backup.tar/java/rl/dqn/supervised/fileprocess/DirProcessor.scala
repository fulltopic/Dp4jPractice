package rl.dqn.supervised.fileprocess

class DirProcessor(path: String) {
  def convertFiles(): Unit = {

  }

  def convertFile(fileName: String): Unit = {
    // insert <Scene> tag
  }
}
