package rl.dqn.supervised.fileprocess.withpeers

import rl.dqn.supervised._


object TestFileProcessorWithPeers {
  val dir = "/home/zf/workspaces/workspace_java/mjconv2/datasets/tenhoulogs/xmls/"
  //TODO: Why can not be defined as Array[Any]?
  def printArray(a: Array[Int]): Unit = {
    a.foreach(i => print(i + ", "))
    println
  }

  def createTester(fileName: String): FileProcessorWithPeers = {
    val tester = new FileProcessorWithPeers(fileName)
    tester.readFile()

    tester
  }

  def testInit(): Unit = {
    val fileName = dir + "testinit.xml"
    val tester = createTester(fileName)


    println("dora ")
    println(tester.doraValue(28) == DoraValue)
    println(tester.doraValue(27) == 0)

    println("oya")
    println(tester.oya == 1)

    println("States")
    val expectedStates = new Array[Array[Int]](PlayerNum)
    for(i <- expectedStates.indices) {
      expectedStates(i) = new Array[Int](PeerStateLen)
    }

    val index0 = Array[Int](27, 31, 6, 7, 17, 20, 15, 3, 28, 21, 4, 9, 17)
    index0.foreach(i => expectedStates(0)(i) += 1)
    expectedStates(0)(28) += DoraValue
    println(tester.currentStats(0).deep == expectedStates(0).deep)

    val index1 = Array[Int](12, 29, 13, 30, 8, 9, 4, 3, 15, 5, 6, 18, 20)
    index1.foreach(i => expectedStates(1)(i) += 1)
    expectedStates(1)(4) += DoraValue
    expectedStates(1)(PeerOyaIndex) = 1
    println(tester.currentStats(1).deep == expectedStates(1).deep)

    val index2 = Array[Int](9, 24, 6, 27, 4, 0, 26, 32, 32, 5, 11, 33, 7)
    index2.foreach(i => expectedStates(2)(i) += 1)
    println(tester.currentStats(2).deep == expectedStates(2).deep)


    val index3 = Array[Int](25, 25, 1, 29, 22, 27, 29, 29, 10, 2, 7, 30, 14)
    index3.foreach(i => expectedStates(3)(i) += 1)
    println(tester.currentStats(3).deep == expectedStates(3).deep)

    println("ten")
    val expectedTen = Array[Int](254, 288, 229, 229)
    println(expectedTen.deep == tester.tens.deep)
  }

  def testAgari(): Unit = {
    val tester = createTester(dir + "testagari.xml")
    val trans = tester.trans
    val expectedRewards = Array[Double](0, -32, 52, 0)

    for (i <- trans.indices) {
      println(expectedRewards(i) == trans(i).getReward)
    }

    println("Who")
    for (i <- trans.indices) {
      if (i == 2) {
        println(trans(i).getAction == Ron)
      }else {
        println(trans(i).getAction == NOOP)
      }
    }
  }

  def testR(): Unit = {
    val tester = createTester(dir + "testryuukyoku.xml")
    val trans = tester.trans
    val expectedRewards = Array[Double](15, 15, -15, -15)

    for (i <- trans.indices) {
      println(expectedRewards(i) == trans(i).getReward)
    }

    trans.foreach(tran => {
      println(tran.getAction == NOOP)
    })
  }

  def testReach(): Unit = {
    val tester = createTester(dir + "testreachstep1.xml")
    val trans = tester.trans

    println("Reward")
    println(trans.head.getReward == ReachReward)

    tester.currentStats.foreach(state => {
      println(state(PeerCommonReach + 2) == ReachStep1)
    })
    println(tester.currentStats(2)(PeerReachIndex) == ReachStep1)

    println("Read flag")
    val tester2 = createTester(dir + "testreach.xml")
    tester2.currentStats.foreach(state => {
      println(state(PeerCommonReach + 2) == ReachStep2)
    })
    println(tester2.currentStats(2)(PeerReachIndex) == ReachStep2)
  }

  def testPlayer(): Unit = {
    val tester = createTester(dir + "testplayer.xml")
    val winnerTrans = tester.trans(tester.trans.length - 2)
    val state = winnerTrans.getNextObservation

    // dora = 0
    //  hai="12,17,18,22,23,27,44,51,54,57,60,66,96,97"
    val expectedTile = Array[Int](3, 4, 4, 5, 5, 6, 11, 12, 13, 14, 15, 16, 24, 24)
    val expectedState = Array.fill[Double](PeerStateLen)(0)
    expectedTile.foreach(t => {
      expectedState(t) += 1
    })
    expectedState(PeerReachIndex) = ReachStep2
    expectedState(PeerCommonReach + 3) = ReachStep2
    expectedState(PeerCommonReach + 2) = ReachStep2

    val dropTiles = Array[Int](115, 113, 67, 34, 126, 75, 98, 118, 76, 43, 61, 120, 102, 65, 69, 108, 39, 40, 64, 103, 41, 1, 58, 37, 14, 110, 94, 133, 4, 42, 122, 3, 128, 63, 46, 83, 35, 107, 123, 10, 32, 11, 132, 26, 114, 8, 15, 134, 112, 82, 117, 2, 87, 86, 135, 89, 9, 90, 59)
    dropTiles.map(_ / 4).foreach(tile => {
      expectedState(TileNum + tile) += 1
    })

    for (i <- expectedState.indices) {
      println(expectedState(i) + " == " + state.getDouble(i) + "? " + (expectedState(i) == state.getDouble(i)))
    }
  }

  def testPlayerStep(): Unit = {
    val tester = createTester(dir + "testplayerstep.xml")
    val expectedStates = new Array[Array[Int]](PlayerNum)
    for(i <- expectedStates.indices) {
      expectedStates(i) = Array.fill[Int](PeerStateLen)(0)
    }
    val expectedTile = new Array[Array[Int]](PlayerNum)
    expectedTile(0) = Array[Int](7,0,10,22,20,2,13,2,18,6,18,19,16)
    expectedTile(1) = Array[Int](32,19,3,20,25,29,19,1,9,7,20,11,23)
    expectedTile(2) = Array[Int](27,24,20,15,5,12,13,4,25,5,29,24,14)
    expectedTile(3) = Array[Int](17,31,14,5,22,15,19,17,10,21,17,9,6)

    // oya = 3, dora = 1
    for (i <- expectedTile.indices) {
      expectedTile(i).foreach(tile => {
        expectedStates(i)(tile) += 1
      })
    }
    expectedStates(3)(PeerOyaIndex) = 1
    expectedStates(1)(1) += expectedStates(1)(1) * DoraValue

    val dropTiles = Array[Int](115, 113, 67, 34)
    dropTiles.map(_ / 4).foreach(tile => {
      expectedStates.foreach(state => state(TileNum + tile) += 1)
    })

    val states = tester.currentStats
    for (i <- states.indices) {
      println(states(i).deep == expectedStates(i).deep)
    }

    printArray(states(3))
    printArray(expectedStates(3))
  }


  def testDora(): Unit = {
    val tester = createTester(dir + "testdora.xml")

    val expectedStates = new Array[Array[Int]](PlayerNum)
    for(i <- expectedStates.indices) {
      expectedStates(i) = new Array[Int](PeerStateLen)
    }

    // dora = 109, 13, 16, 52, 88
    val index0 = Array[Int](27, 31, 6, 7, 17, 20, 15, 3, 28, 21, 4, 9, 17)
    index0.foreach(i => expectedStates(0)(i) += 1)
    expectedStates(0)(28) += DoraValue
    expectedStates(0)(4) += DoraValue
    printArray(expectedStates(0))
    printArray(tester.currentStats(0))
    println(tester.currentStats(0).deep == expectedStates(0).deep)

    val index1 = Array[Int](12, 29, 13, 30, 8, 9, 4, 3, 15, 5, 6, 18, 20)
    index1.foreach(i => expectedStates(1)(i) += 1)
    expectedStates(1)(4) += DoraValue * 2
    expectedStates(1)(PeerOyaIndex) = 1
    printArray(expectedStates(1))
    printArray(tester.currentStats(1))
    println(tester.currentStats(1).deep == expectedStates(1).deep)


    val index2 = Array[Int](9, 24, 6, 27, 4, 0, 26, 32, 32, 5, 11, 33, 7)
    index2.foreach(i => expectedStates(2)(i) += 1)
    expectedStates(2)(4) += DoraValue
    printArray(expectedStates(2))
    printArray(tester.currentStats(2))
    println(tester.currentStats(2).deep == expectedStates(2).deep)


    val index3 = Array[Int](25, 25, 1, 29, 22, 27, 29, 29, 10, 2, 7, 30, 14)
    index3.foreach(i => expectedStates(3)(i) += 1)
    printArray(expectedStates(3))
    printArray(tester.currentStats(3))
    println(tester.currentStats(3).deep == expectedStates(3).deep)


    val tester2 = createTester(dir + "testdoradrop.xml")
    expectedStates(1)(4) = 0
    expectedStates.foreach(state => state(4 + TileNum) += 1)
    for (i <- expectedStates.indices) {
      println(tester2.currentStats(i).deep == expectedStates(i).deep)
    }
  }

  def getDefaultState(expectedTile: Array[Int]): Array[Int] = {
    val expectedState = Array.fill[Int](PeerStateLen)(0)
    expectedTile.foreach(tile => expectedState(tile) += 1)

    expectedState
  }

  def getDefaultState(expectedTile: Array[Array[Int]]): Array[Array[Int]] = {
    val expectedStates = new Array[Array[Int]](PlayerNum)
    for(i <- expectedTile.indices) {
      expectedStates(i) = getDefaultState(expectedTile(i))
    }

    expectedStates
  }

  def testPong(): Unit = {
    val tester = createTester(dir + "testpong.xml")

    //dora = 20, 16, 88, 52 original
    //    expectedTile(0) = Array[Int](20, 23, 23, 9, 9, 30, 9, 27, 20, 6, 24, 11, 11)
    //    expectedTile(1) = Array[Int](27, 28, 32, 26, 24, 33, 15, 2, 22, 17, 11, 8, 14)
    //    expectedTile(2) = Array[Int](22, 14, 7, 27, 4, 27, 13, 2, 0, 20, 0, 13, 6)
    //    expectedTile(3) = Array[Int](16, 19, 4, 26, 32, 1, 32, 6, 31, 4, 29, 7, 16)
    val expectedTile = new Array[Array[Int]](PlayerNum)

    expectedTile(0) = Array[Int](20, 23, 23, 9, 9, 25, 9, 12, 20, 6, 24, 11, 11)
    expectedTile(1) = Array[Int](28, 28, 32, 26, 24, 33, 15, 2, 22, 17, 11, 11, 14)
    expectedTile(2) = Array[Int](22, 14, 7, 27, 4, 27, 15, 2, 0, 20, 0, 13, 6, 27)
    expectedTile(3) = Array[Int](16, 19, 4, 10, 32, 1, 32, 6, 31, 4, 29, 7, 16)

    val dropTiles = Array[Int](120, 35, 53, 107, 110, 108)
    val pongTile = 108

    val expectedStates = getDefaultState(expectedTile)
    expectedStates(0)(PeerOyaIndex) = 1
    expectedStates(0)(20) += 2 * DoraValue
    expectedStates(1)(22) += DoraValue
    expectedStates(2)(13) += DoraValue
    expectedStates(2)(4) += DoraValue
    expectedStates(2)(20) += DoraValue
    expectedStates(2)(27) = 3 * MValue
    expectedStates.foreach(state => {
      dropTiles.foreach(tile => state(TileNum + tile / NumPerTile) += 1)
      state(TileNum + pongTile / NumPerTile) += 2
    })


    for (i <- expectedStates.indices) {
      println(tester.currentStats(i).deep == expectedStates(i).deep)
      printArray(tester.currentStats(i))
      printArray(expectedStates(i))
    }

    val tran = tester.trans.last
    println(tran.getReward == DefaultReward)
    println(tran.getAction == Pong)
    println("Next")
    for (i <- expectedStates(2).indices) {
      if(expectedStates(2)(i) != tran.getNextObservation.getDouble(i)) {
        print(false)
      }
    }
    println("")
    println("Observation")
    expectedStates(2)(27) = 2
    expectedStates(2)(TileNum + 27) -= 2
    for (i <- expectedStates(2).indices) {
      if (expectedStates(2)(i) != tran.getObservation.head.getDouble(i)) {
        print(false)
      }
    }
    println("")
  }


  // 18, 23, 27
  def testChow(): Unit = {
    val tester = createTester(dir + "testchow.xml")

    val expectedTile = new Array[Array[Int]](PlayerNum)

    // initial value
    //    expectedTile(0) = Array[Int](11, 4, 14, 17, 22, 25, 4, 3, 15, 6, 19, 30, 3)
    //    expectedTile(1) = Array[Int](0, 12, 8, 18, 22, 1, 9, 9, 18, 17, 33, 24, 21)
    //    expectedTile(2) = Array[Int](33, 11, 10, 5, 22, 4, 10, 27, 20, 32, 16, 12, 21)
    //    expectedTile(3) = Array[Int](18, 14, 17, 20, 13, 29, 30, 29, 29, 27, 26, 33, 25)

    expectedTile(0) = Array[Int](11, 4, 14, 5, 22, 23, 4, 3, 15, 6, 13, 30, 3)
    expectedTile(1) = Array[Int](0, 8, 8, 18, 22, 1, 9, 9, 18, 17, 16, 24, 23)
    expectedTile(2) = Array[Int](16, 11, 10, 5, 22, 4, 10, 28, 20, 10, 16, 12, 21, 6)
    expectedTile(3) = Array[Int](18, 14, 20, 20, 13, 29, 19, 29, 29, 21, 26, 26, 25)

    val dropTiles = Array[Int](135, 111, 71, 69, 49, 133, 110, 78, 85, 72, 134, 119, 31, 128, 120, 102, 27)

    //oya = 1, 24, 16, 88, 52
    val expectedStates = getDefaultState(expectedTile)
    expectedStates(0)(4) += DoraValue
    expectedStates(0)(22) += DoraValue
    expectedStates(1)(24) += DoraValue
    expectedStates(1)(PeerOyaIndex) = 1
    //    expectedStates(2)(20) += DoraValue
    expectedStates(2)(4) += MValue - 1
    expectedStates(2)(5) += MValue - 1
    expectedStates(2)(6) += MValue - 1
    expectedStates(3)(13) += DoraValue

    expectedStates.foreach(state => {
      dropTiles.foreach(tile => state(TileNum + tile / NumPerTile) += 1)
      state(TileNum + 4) += 1
      state(TileNum + 5) += 1
    })

    for (i <- expectedStates.indices) {
      println(tester.currentStats(i).deep == expectedStates(i).deep)
      printArray(tester.currentStats(i))
      printArray(expectedStates(i))
    }


    val tran = tester.trans.last
    println(tran.getReward == DefaultReward)
    println(tran.getAction == Chow)
    println("Next")
    for (i <- expectedStates(2).indices) {
      if(expectedStates(2)(i) != tran.getNextObservation.getDouble(i)) {
        print(false)
      }
    }
    println("")
    println("Observation")
    expectedStates(2)(4) -= MValue - 1
    expectedStates(2)(5) -= MValue - 1
    expectedStates(2)(6) = 0
    expectedStates(2)(TileNum + 4) -= 1
    expectedStates(2)(TileNum + 5) -= 1
    for (i <- expectedStates(2).indices) {
      if (expectedStates(2)(i) != tran.getObservation.head.getDouble(i)) {
        print(false)
      }
    }
    println("")
  }


  def testScene1(): Unit = {
    val tester = createTester(dir + "testscene1.xml")

    //dora = 24, 16, 52, 88
    //oya = 1
    //chow 18, 23, 27
    val dropTiles = Array[Int](135, 111, 71, 69, 49, 133, 110, 78, 85, 72, 134, 119, 31, 128, 120, 102, 27, 115, 52)
    val expectedTile = Array[Int](10, 10, 10, 11, 12, 13, 16, 16, 20, 21, 22, 4, 5, 6)
    val expectedStates = getDefaultState(expectedTile)
    expectedStates(13) += DoraValue
    expectedStates(4) = MValue
    expectedStates(5) = MValue
    expectedStates(6) = MValue

    dropTiles.foreach(tile => expectedStates(TileNum + tile / NumPerTile) += 1)
    expectedStates(TileNum + 4) += 1
    expectedStates(TileNum + 5) += 1

    val trans = tester.trans
    val tran = tester.trans.init.last
    println(tran.getReward == 20)
    println(tran.getAction == Ron)
    println("Next")

    for (i <- expectedStates.indices) {
      println(expectedStates(i) + " == " + tran.getNextObservation.getDouble(i) + "? " + (expectedStates(i) == tran.getNextObservation.getDouble(i)))
    }
    println("")
    println("Number ==========================> " + trans.length + " == " + 24 + "? " + (trans.length == 24))

    println("Get transition type chow: " + (trans.count(_.getAction == Chow) == 1))
    println("Get transition type ron: " + (trans.count(_.getAction == Ron) == 1))
    println("Get transition type noop: " + (trans.count(_.getAction == NOOP) == 3))
    println("Get transition type pong: " + (trans.count(_.getAction == Pong) == 0))
    println("Get transition type reach: " + (trans.count(_.getAction == ReachStep1) == 0))

  }

  def testScene(): Unit = {
    val tester = createTester(dir + "testscene.xml")
    //dora = 28, 16, 52, 88
    //oya = 1
    //chow 52, 62: 56
    val dropTiles = Array[Int](116, 2, 120, 38, 122, 105, 110, 108, 39, 111, 29, 97, 74, 98, 107, 125, 63, 80, 127, 114, 33, 133, 124, 71, 126, 58, 56, 68, 83, 70, 130, 67, 96, 30, 41, 65, 64, 5, 0, 28, 66, 112, 6, 69, 35)
    val expectedTile = Array[Int](3, 4, 5, 6, 7, 8, 9, 9, 11, 11, 11, 32, 32, 32)
    val expectedStates = getDefaultState(expectedTile)
    expectedStates(PeerReachIndex) = 2
    expectedStates(PeerCommonReach + 2) = ReachStep2
    expectedStates(PeerCommonReach + 3) = ReachStep2
    expectedStates(TileNum + 52 / NumPerTile) += 1
    expectedStates(TileNum + 62 / NumPerTile) += 1

    dropTiles.foreach(tile => expectedStates(TileNum + tile / NumPerTile) += 1)

    val trans = tester.trans
    val tran = tester.trans.init.last
    println(tran.getReward == 52)
    println(tran.getAction == Ron)
    println("Next")
    for (i <- expectedStates.indices) {
      if (expectedStates(i) != tran.getNextObservation.getDouble(i)) {
        print(false)
      }
    }
    println("")

    // 45 + 2 + 1 + 1 + 3
    println("Number ==========================> " + trans.length + " == " + 52 + "? " + (trans.length == 52))

    println("Get transition type chow: " + (trans.count(_.getAction == Chow) == 1))
    println("Get transition type ron: " + (trans.count(_.getAction == Ron) == 1))
    println("Get transition type noop: " + (trans.count(_.getAction == NOOP) == 3))
    println("Get transition type pong: " + (trans.count(_.getAction == Pong) == 0))
    println("Get transition type reach: " + (trans.count(_.getAction == ReachStep1) == 2))

  }

  def testFile(): Unit = {
    // Just to see if any exception
    // test.xml and test2.xml are good test objects
    createTester(dir + "test.xml")
  }

  def testFile2(): Unit = {
    createTester(dir + "test2.xml")
  }

  def testGenerateFile(): Unit = {
//    val fileName = "/home/zf/workspaces/workspace_java/mjconv2/datasets/tenhoulogs/logs/db1/xmls/mjlog_pf4-20_n1/2011020417gm-00a9-0000-b67fcaa3&tw=1.xml"
    val fileName = "/home/zf/workspaces/workspace_java/mjconv2/datasets/tenhoulogs/logs/db1/xmls/mjlog_pf4-20_n2/2010033123gm-0029-0000-53c6c5e8&tw=0.xml"

    createTester(fileName)
  }

  def main(args: Array[String]): Unit = {
//    testPong()
    testGenerateFile()
//    testFile()
  }
}
