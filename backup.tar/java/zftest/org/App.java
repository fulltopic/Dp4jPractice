package zftest.org;

import zftest.org.tests.TestDataVec;
import zftest.org.tests.TestNN;
import zftest.org.tests.TestUtils;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//        TestDataVec.TestMjDataVec();
//        TestUtils.TestConvertLabels();
//        TestUtils.TestProcessImages();
        try {
//            TestNN.Test1w();
            TestNN.InitTest();
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
}
