package zftest.org.dataprocess;

import org.deeplearning4j.datasets.fetchers.BaseDataFetcher;
import org.deeplearning4j.util.MathUtils;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.factory.Nd4j;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

public class MjDataFetcher extends BaseDataFetcher {
    private String dirPath = "";
    private int width = 400;
    private int height = 300;
    private long rngSeed = 0;
    private int labelClassNum = 34;
    private File[] imageFiles = null;

    protected boolean train;
    protected int[] order;
    protected Random rng;
    protected boolean shuffle;
    protected boolean oneIndexed = false;

    private String imageSubDir = "images";
    private String labelSubDir = "tiles_old";

    public MjDataFetcher(String dirPath, boolean train, int labelClassNum) throws IOException{
        this.dirPath = dirPath;
        this.train = train;
        this.rngSeed = System.currentTimeMillis();
        this.shuffle = true;
        this.labelClassNum = labelClassNum;
        init();
    }

    private void init() throws IOException {
        File dir = new File(dirPath + "/" + imageSubDir);
        imageFiles = dir.listFiles();
        totalExamples = imageFiles.length;
        cursor = 0;
        this.order = new int[totalExamples];
        for(int i = 0; i < totalExamples; i ++) {
            order[i] = i;
        }
        rng = new Random(rngSeed);
        reset();
    }

    public void reset() {
        cursor = 0;
        curr = null;
        if (shuffle)
            MathUtils.shuffleArray(order, rng);
    }

    public DataSet next() {
        DataSet next = super.next();
        return next;
    }

    private float[] zeros(int length) {
        float[] data = new float[length];
        for(int i = 0; i < data.length; i ++) {
            data[i] = 0;
        }

        return data;
    }

    protected void parseLabel(String tiles, float[] labels) {
        for(int i = 0; i < tiles.length(); i ++) {
            int num = tiles.charAt(i) - '0';
                labels[i] = num;
        }
    }

    private float[] getLabels(int imageFileIndex) {
        String imageFilePath = imageFiles[imageFileIndex].getName();
        int pngIndex = imageFilePath.indexOf("png");
        String imageBaseName = imageFilePath.substring(0, pngIndex - 1);

        String labelFileName = dirPath + "/" + labelSubDir + "/" + imageBaseName + ".txt";
        BufferedReader reader = null;
        float[] labels = zeros(labelClassNum);

        try {
            reader = new BufferedReader(new FileReader(labelFileName));
            String tiles = reader.readLine();
            parseLabel(tiles, labels);
        }catch(IOException ie) {
            ie.printStackTrace();
        }finally {
            if(reader != null) {
                try {
                    reader.close();
                }catch (IOException ie) {
                    ie.printStackTrace();
                }
            }
        }

        return labels;
    }

    //Base class bad design?
    public void fetch(int numExamples) {
        if (!hasMore()) {
            throw new IllegalStateException("No more examples");
        }

        float[][] featureData = new float[numExamples][0];
        float[][] labelData = new float[numExamples][0];
//        float[] floatSig = new float[width * height];

        int actualNum = totalExamples - cursor;
        actualNum = Math.min(actualNum, numExamples);
        for (int i = 0; i < actualNum; i ++, cursor ++) {
            try {
                File imageFile = imageFiles[order[cursor]];
//                System.out.println("-------------------->Load image " + imageFile.getName());

                BufferedImage image = ImageIO.read(imageFiles[order[cursor]]);
                Raster raster = image.getRaster();
                int w = raster.getWidth();
                int h = raster.getHeight();

                float[] featureVec = new float[width * height];
                featureVec = raster.getPixels(0, 0, w, h, featureVec);
//                System.out.println("------------------_> Get image: " + w + ", " + h);
                featureData[i] = featureVec;
                labelData[i] = getLabels(order[cursor]);
            }catch(Exception e) {
                e.printStackTrace();
                featureData[i] = zeros(width * height);
                labelData[i] = zeros(labelClassNum);
            }
        }

        for(int i = actualNum; i < numExamples; i ++) {
            featureData[i] = zeros(width * height);
            labelData[i] = zeros(labelClassNum);
        }

        INDArray features = Nd4j.create(featureData);
        INDArray labels = Nd4j.create(labelData);

        curr = new DataSet(features, labels);
    }
}
