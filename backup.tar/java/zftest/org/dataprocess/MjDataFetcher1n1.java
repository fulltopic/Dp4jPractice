package zftest.org.dataprocess;

import java.io.IOException;

public class MjDataFetcher1n1 extends MjDataFetcher {
    public MjDataFetcher1n1(String dirPath, boolean train, int labelClassNum) throws IOException {
        super(dirPath, train, labelClassNum);
    }

    protected void parseLabel(String tiles, float[] labels) {
        for(int i = 0; i < tiles.length(); i ++) {
            int num = tiles.charAt(i) - '0';
            if(num == 0) {
                labels[i] = -1;
            }else {
                labels[i] = 1;
            }
        }
    }
}
