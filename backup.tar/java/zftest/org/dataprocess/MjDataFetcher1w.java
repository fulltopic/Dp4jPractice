package zftest.org.dataprocess;

import java.io.IOException;

public class MjDataFetcher1w extends MjDataFetcher {
    public MjDataFetcher1w(String dirPath, boolean train, int labelClassNum) throws IOException {
        super(dirPath, train, labelClassNum);
    }

    protected void parseLabel(String tiles, float[] labels) {
        int v = tiles.charAt(0) - '0';
        if(v <= 0) {
            labels[0] = 0;
            labels[1] = 1;
        }else {
            labels[0] = 1;
            labels[1] = 0;
        }
    }
}
