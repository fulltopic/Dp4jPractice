package zftest.org.dataprocess;

import org.deeplearning4j.datasets.iterator.BaseDatasetIterator;

import java.io.IOException;

public class MjDataSetIterator extends BaseDatasetIterator {
    public MjDataSetIterator(int batch, int numExamples, boolean train, String path, int labelClassNum) throws IOException {
        super(batch, numExamples, new MjDataFetcher(path, train, labelClassNum));
    }

    public MjDataSetIterator(int batch, int numExamples, MjDataFetcher fetcher) throws IOException {
        super(batch, numExamples, fetcher);
    }
}
