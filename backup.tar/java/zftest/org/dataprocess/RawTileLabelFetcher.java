package zftest.org.dataprocess;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;

public class RawTileLabelFetcher {
    public static final int TileNum = 27;
    public static final int NumPerTile = 4;
    public static final int HaiLen = 13;

    public static int[] GetLabel(String fileName) {
        int[] tiles = new int[HaiLen];
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String content = reader.readLine();
            String[] parts = content.split("\"");
            String[] tilesString = parts[parts.length - 2].split(",");

            for(int i = 0; i < tilesString.length; i ++) {
                int tileValue = Integer.parseInt(tilesString[i]);
                tiles[i] = tileValue / NumPerTile;
            }
            Arrays.sort(tiles);
            reader.close();
        }catch(Exception e) {
            e.printStackTrace();
        }

        return tiles;
    }
}
