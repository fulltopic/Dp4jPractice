package zftest.org.dataprocess;

import org.apache.commons.io.FilenameUtils;
import org.datavec.api.io.labels.PathLabelGenerator;
import org.datavec.api.writable.Text;
import org.datavec.api.writable.Writable;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.URI;

public class TileLabelGenerator implements PathLabelGenerator {
    private static String Extension = ".txt";
    private static String SubParent = "tiles_old";

    public TileLabelGenerator() {}

    @Override
    public Writable getLabelForPath(String path) {
        // Label is in the directory

        String baseName = FilenameUtils.getBaseName(path);
        String fileName = baseName + Extension;
        String[] pathes = path.split("/");
//        for(int i = 0; i < pathes.length; i ++) {
//            System.out.println(pathes[i]);
//        }

        pathes[pathes.length - 1] = fileName;
        pathes[pathes.length - 2] = SubParent;

//        @since 1.8
        String newPath = String.join("/", pathes);
        String tiles = "";

        try {
            BufferedReader reader = new BufferedReader(new FileReader(newPath));
            tiles = reader.readLine();
        }catch(Exception e) {
            e.printStackTrace();
        }

        return new Text(tiles);
    }

    @Override
    public Writable getLabelForPath(URI uri) {
        return getLabelForPath(new File(uri).toString());
    }
}
