package zftest.org.dataprocess;

import org.deeplearning4j.datasets.fetchers.BaseDataFetcher;
import org.deeplearning4j.util.MathUtils;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.factory.Nd4j;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;

public class TilesDataFetcher extends BaseDataFetcher {
    private static final int ChannelNum = 4;

    private String dirPath;
    private static final int Height = 50;
    private static final int Width = 544 / RawTileLabelFetcher.HaiLen;
    private long rngSeed = 0;
//    private int labelClassNum = 34;
    private File[] imageFiles = null;
    private int fileCount = 0;
    private int tileCount = 0;
    private String currFileName = "";
    private BufferedImage[] currSubImages = null;
    private int[] currLabels = null;


    private HashMap<String, int[]> labelMap;

    protected boolean train;
    protected int[] order;
    protected Random rng;
    protected boolean shuffle;
    protected boolean oneIndexed = false;

    private String imageSubDir = "images";
    private String labelSubDir = "texts";

    public TilesDataFetcher(String dirPath, boolean train) throws IOException {
        this.dirPath = dirPath;
        this.train = train;
        this.rngSeed = System.currentTimeMillis();
        this.shuffle = true;
//        this.labelClassNum = labelClassNum;
        this.labelMap = new HashMap<>();
        this.currSubImages = new BufferedImage[RawTileLabelFetcher.HaiLen];
        init();
    }

    private void init() throws IOException {
        File dir = new File(dirPath + "/" + imageSubDir);
        imageFiles = dir.listFiles();
        totalExamples = imageFiles.length;
        fileCount = 0;
        tileCount = 0;
        this.order = new int[totalExamples];
        for (int i = 0; i < totalExamples; i++) {
            order[i] = i;
        }
        rng = new Random(rngSeed);
        loadLabels();
        reset();
    }

    public void printLabels() {
        Set<String> keys = labelMap.keySet();
        for (String key: keys) {
            int[] values = labelMap.get(key);
            System.out.print(key + ": ");
            for(int value: values) {
                System.out.print("" + value + ", ");
            }
            System.out.println("");
        }
    }

    public void loadLabels() {
        File dir = new File(dirPath + "/" + labelSubDir);
        File[] labelFiles = dir.listFiles();

        for (File labelFile : labelFiles) {
            String fileName = labelFile.getName();
            int[] labels = RawTileLabelFetcher.GetLabel(labelFile.getAbsolutePath());
            labelMap.put(fileName.substring(0, fileName.length() - ".txt".length()), labels);
        }
    }

    public void reset() {
        fileCount = 0;
        tileCount = RawTileLabelFetcher.HaiLen;
        curr = null;
        if (shuffle)
            MathUtils.shuffleArray(order, rng);
    }

    public DataSet next() {
        DataSet next = super.next();
        return next;
    }

    public boolean hasMore() {
        return (fileCount < totalExamples);
    }

    private void loadNewFile() throws Exception {
        File imageFile = imageFiles[order[fileCount]];
        BufferedImage image = ImageIO.read(imageFile);
//        int h = Height;
//        int w = Width / RawTileLabelFetcher.HaiLen;
        for(int i = 0; i < RawTileLabelFetcher.HaiLen; i ++) {
            currSubImages[i] = image.getSubimage(i * Width, 0, Width, Height);
        }
        String fileName = imageFile.getName();
        String labelFileName = fileName.substring(0, fileName.length() - ".png".length());
        currLabels = labelMap.get(labelFileName);
        fileCount ++;
        tileCount = 0;
    }

    private float[] createLabelVec(int hotIndex) {
        float[] labels = new float[RawTileLabelFetcher.TileNum];
        for(int i = 0; i < labels.length; i ++) {
            labels[i] = 0;
        }
        labels[hotIndex] = 1;

        return labels;
    }

    private float[] zeros(int length) {
        float[] data = new float[length];
        for(int i = 0; i < data.length; i ++) {
            data[i] = 0;
        }

        return data;
    }

    public void fetch(int numExamples) {
        if (!hasMore()) {
            throw new IllegalStateException("No more examples");
        }

        float[][] featureData = new float[numExamples][0];
        float[][] labelData = new float[numExamples][0];

        int featureIndex = 0;
        for(featureIndex = 0; featureIndex < numExamples; featureIndex ++) {
            while(tileCount < RawTileLabelFetcher.HaiLen && currLabels[tileCount] >= RawTileLabelFetcher.TileNum) {
                tileCount ++;
            }

            if(tileCount >= RawTileLabelFetcher.HaiLen) {
                if(hasMore()) {
                    try {
                        loadNewFile();
                    }catch(Exception e) {
                        e.printStackTrace();
                        break;
                    }
                }else {
                    break;
                }
            }

            Raster raster = currSubImages[tileCount].getRaster();
//            System.out.println("Expected " + Width + ", " + Height + ", " + ChannelNum + " actual: " + raster.getWidth() + ", " + raster.getHeight() + ", " + raster.getNumBands());
            float[] featureVec = new float[Width * Height * ChannelNum];
            featureVec = raster.getPixels(0, 0, Width, Height, featureVec);
//            if(currLabels == null) {
//                System.out.println("currLabels = null");
//            }else{
//                System.out.println("" + tileCount);
//            }
            float[] labelVec = createLabelVec(currLabels[tileCount]);
            featureData[featureIndex] = featureVec;
            labelData[featureIndex] = labelVec;
            tileCount ++;
        }

        for(; featureIndex < numExamples; featureIndex ++) {
            featureData[featureIndex] = zeros(Width * Height);
            labelData[featureIndex] = zeros(RawTileLabelFetcher.TileNum);
        }

        INDArray features = Nd4j.create(featureData);
        INDArray labels = Nd4j.create(labelData);

        curr = new DataSet(features, labels);
    }

    public static int GetChanNum() {
        return ChannelNum;
    }

    public static int GetWidth() {
        return Width;
    }

    public static int GetHeight() {
        return Height;
    }

    public static void main(String[] args) {
        String path = "/home/zf/workspaces/workspace_java/mjconv2/datasets/tiles";

        try {
            TilesDataFetcher fetcher = new TilesDataFetcher(path, false);
            fetcher.loadLabels();
            fetcher.printLabels();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }
}
