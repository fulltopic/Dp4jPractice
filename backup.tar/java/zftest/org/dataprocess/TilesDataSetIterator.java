package zftest.org.dataprocess;

import org.deeplearning4j.datasets.iterator.BaseDatasetIterator;

import java.io.IOException;

public class TilesDataSetIterator extends BaseDatasetIterator {
    public TilesDataSetIterator(int batch, int numExamples, boolean train, String path) throws IOException {
        super(batch, numExamples, new TilesDataFetcher(path, train));
    }

    public TilesDataSetIterator(int batch, int numExamples, TilesDataFetcher fetcher) throws IOException {
        super(batch, numExamples, fetcher);
    }
}