package zftest.org.preprocessor;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class FormatImages {
    private String srcPath;
    private String dstPath;

    public FormatImages(String srcPath, String dstPath) {
        this.srcPath = srcPath;
        this.dstPath = dstPath;
    }

    public void format(int num, int w, int h) {
        File srcDir = new File(srcPath);
        File[] srcFiles = srcDir.listFiles();

        for(int i = 0; i < num; i ++) {
            File srcFile = srcFiles[i];
            String baseFileName = srcFile.getName();
            String dstFileName = dstPath + "/" + baseFileName;

            try {
                BufferedImage srcImage = ImageIO.read(srcFile);
//                Image dstImage = srcImage.getScaledInstance(w, h, Image.SCALE_DEFAULT);
                BufferedImage dstImage = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
                Graphics2D graph = dstImage.createGraphics();
                graph.drawImage(srcImage, 0, 0, w, h, null);
                graph.dispose();
                ImageIO.write(dstImage, "png", new File(dstFileName));
                System.out.println("Converted " + dstFileName);
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void readImage(String filePath) {
        try {
            BufferedImage image = ImageIO.read(new File(filePath));
            int w = image.getWidth();
            int h = image.getHeight();
            System.out.println("Get " + w + ", " + h);

            int[] pixels = new int[w * h];
            int[] inputPixels = new int[w * h];
            pixels = image.getRaster().getPixels(0, 0, w, h, pixels);
            System.out.println(pixels[pixels.length / 2]);
//            System.out.println(inputPixels[inputPixels.length / 2]);
//            for(int i = 0; i < pixels.length; i ++) {
//                if(pixels[i] != inputPixels[i]) {
//                    System.out.println("They are not the same at " + i);
//                }
//            }
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}
