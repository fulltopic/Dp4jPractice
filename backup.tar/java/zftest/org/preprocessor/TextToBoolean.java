package zftest.org.preprocessor;

import org.apache.commons.io.FilenameUtils;

import java.io.*;
import java.util.Vector;

public class TextToBoolean {
    public TextToBoolean() {}
    private static int TileNum = 34;

    private static int GetTile(String c) {
        return  Integer.parseInt(c) / 4;
    }

    private static String ParseContent(String content) throws  Exception{
//        String tileString = "";
        if (!content.contains("INIT") || content.contains("REINIT")) {
            throw new Exception("Not valid init log " + content);
        }

        //<INIT seed="0,0,0,0,0,104" ten="250,250,250,250" oya="0" hai="49,13,119,53,106,38,109,44,36,54,14,27,60"/>
        char[] tiles = new char[TileNum];
        for(int i = 0; i < tiles.length; i ++) {
            tiles[i] = '0';
        }

        String[] parts = content.split("\"");
        String[] tilesString = parts[parts.length - 2].split(",");
        for(String tile: tilesString) {
            int tileSeq = GetTile(tile);
            tiles[tileSeq] = '1';
        }

        return new String(tiles);
    }

    public static void ConvertDir(String srcPath, String dstPath) {
        Vector<String> errorFiles = new Vector<String>();

        File dir = new File(srcPath);
        File[] files = dir.listFiles();

        if(files != null) {
            for (File file: files) {
                BufferedWriter writer = null;
                BufferedReader reader = null;

                try {
                    String srcFilePath = file.getPath();
                    String fileName = FilenameUtils.getName(srcFilePath);
                    reader = new BufferedReader(new FileReader(srcFilePath));
                    String content = reader.readLine();
                    reader.close();

                    String dstFileName = dstPath + "/" + fileName;
                    writer = new BufferedWriter(new FileWriter(dstFileName));
                    String tiles = ParseContent(content);
                    writer.write(tiles);
                    writer.close();

                }catch(Exception e) {
                    e.printStackTrace();
                    errorFiles.add(file.getPath());
                }finally {
                    try {
                        if (writer != null) {
                            writer.close();
                        }
                    }catch (Exception ce) {
                        ce.printStackTrace();
                    }
                    try {
                        if (reader != null) {
                            reader.close();
                        }
                    }catch (Exception ce) {
                        ce.printStackTrace();
                    }
                }
            }
        }else {
            System.out.println("Failed to open directory " + srcPath);
        }

        System.out.println("Failed to get parse these files: ");
        for (String errPath: errorFiles) {
            System.out.println(errPath);
        }
    }


    public static void Convert1n1Tiles(String srcPath, String dstPath) {
        Vector<String> errorFiles = new Vector<String>();

        File dir = new File(srcPath);
        File[] files = dir.listFiles();

        if(files != null) {
            for (File file: files) {
                BufferedWriter writer = null;
                BufferedReader reader = null;

                try {
                    String srcFilePath = file.getPath();
                    String fileName = FilenameUtils.getName(srcFilePath);
                    reader = new BufferedReader(new FileReader(srcFilePath));
                    String content = reader.readLine();
                    reader.close();

                    String dstFileName = dstPath + "/" + fileName;
                    writer = new BufferedWriter(new FileWriter(dstFileName));
                    String tiles = ParseContent(content);
                    writer.write(tiles);
                    writer.close();

                }catch(Exception e) {
                    e.printStackTrace();
                    errorFiles.add(file.getPath());
                }finally {
                    try {
                        if (writer != null) {
                            writer.close();
                        }
                    }catch (Exception ce) {
                        ce.printStackTrace();
                    }
                    try {
                        if (reader != null) {
                            reader.close();
                        }
                    }catch (Exception ce) {
                        ce.printStackTrace();
                    }
                }
            }
        }else {
            System.out.println("Failed to open directory " + srcPath);
        }

        System.out.println("Failed to get parse these files: ");
        for (String errPath: errorFiles) {
            System.out.println(errPath);
        }
    }
}
