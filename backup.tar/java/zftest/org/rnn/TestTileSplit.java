package zftest.org.rnn;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

public class TestTileSplit {
    private static final String imageDir = "/home/zf/workspaces/workspace_java/mjconv2/datasets/tiles/images/";
    private static final String imageName = "1.png";
    public static final int TileNum = 13;

    public void testSplitImage() {
        String fileName = imageDir + imageName;
//        int i = 0;
        try {
            BufferedImage image = ImageIO.read(new File(fileName));
            int h = image.getHeight();
            int w = image.getWidth() / TileNum;
            System.out.println("Get infor from raw image: " + image.getHeight() + ", " + image.getWidth());

            for(int i = 0; i < TileNum; i ++) {
                String outFileName = imageDir + "1" + "-" + i;
                BufferedImage subImage = image.getSubimage(i * w, 0, w, h);
                ImageIO.write(subImage, "png", new File(outFileName));
            }
        }catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        TestTileSplit spliter = new TestTileSplit();
        spliter.testSplitImage();
    }
}
