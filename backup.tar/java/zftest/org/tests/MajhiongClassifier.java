package zftest.org.tests;

import org.datavec.api.io.filters.BalancedPathFilter;
import org.datavec.api.io.labels.ParentPathLabelGenerator;
import org.datavec.api.split.FileSplit;
import org.datavec.api.split.InputSplit;
import org.datavec.image.loader.NativeImageLoader;
import org.datavec.image.recordreader.ImageRecordReader;
import org.datavec.image.transform.CropImageTransform;
import org.datavec.image.transform.FlipImageTransform;
import org.datavec.image.transform.ImageTransform;
import org.datavec.image.transform.WarpImageTransform;
import org.deeplearning4j.api.storage.StatsStorage;
import org.deeplearning4j.datasets.datavec.RecordReaderDataSetIterator;
import org.deeplearning4j.datasets.iterator.MultipleEpochsIterator;
import org.deeplearning4j.eval.Evaluation;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;
import org.deeplearning4j.nn.conf.*;
import org.deeplearning4j.nn.conf.inputs.InputType;
import org.deeplearning4j.nn.conf.layers.ConvolutionLayer;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.conf.layers.SubsamplingLayer;
import org.deeplearning4j.nn.graph.ComputationGraph;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.transferlearning.FineTuneConfiguration;
import org.deeplearning4j.nn.transferlearning.TransferLearning;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.ui.api.UIServer;
import org.deeplearning4j.ui.stats.StatsListener;
import org.deeplearning4j.ui.storage.InMemoryStatsStorage;
import org.deeplearning4j.util.ModelSerializer;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.api.preprocessor.DataNormalization;
import org.nd4j.linalg.dataset.api.preprocessor.ImagePreProcessingScaler;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.*;

public class MajhiongClassifier {
    private static final Logger log = LoggerFactory.getLogger(MajhiongClassifier.class);
    private static final int exampleNum = 202 * 3;
    private static final int classNum = 3;
    private static final int batchSize = 16;
    private static final int testBatchSize = 9;
    private static final int epochNum = 25;
    private static final int height = 30;
    private static final int width = 20;
    //    private static final int height = 20;
//    private static final int width = 20;
    private static final int channelNum = 1;
    private static double splitTrainTest = 0.8;
    private static int iterations = 4;
    private static double learningRate = 0.01;

    private static final int seed = 71;
    private static Random random = new Random(seed);
    private static int listenerFreq = 1;
    private static boolean save = false;
    double l2NormBeta = 0.0005;

    private static final String mainPath = "/home/zf/books/DeepLearning-master/majiong/datasets/dataset6";
    private static final String testPath = "/home/zf/books/DeepLearning-master/majiong/datasets/datasettest";

    //test compile
    private MultiLayerNetwork createModel() {
        Map<Integer, Double> lrSchedule = new HashMap<>();
        lrSchedule.put(0, 0.01);
//        lrSchedule.put(1000, 0.005);
//        lrSchedule.put(3000, 0.001);
        lrSchedule.put(3000, 0.005);
//        lrSchedule.put((int)(splitTrainTest * exampleNum * epochNum * iterations / batchSize + 20), 0.005);
//        lrSchedule.put(2000, 0.005);

        MultiLayerConfiguration config = new NeuralNetConfiguration.Builder()
                .seed(seed)
//                .learningRate(learningRate)
                .learningRateDecayPolicy(LearningRatePolicy.Schedule)
                .learningRateSchedule(lrSchedule)
                .iterations(iterations)
                .regularization(true).l2(l2NormBeta)
                .weightInit(WeightInit.XAVIER)
                .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
                .updater(Updater.ADAM)
                .list()
                //Layers
                .layer(0, new ConvolutionLayer.Builder(2, 2)
                        .padding(1, 1)
                        .stride(1, 1)
                        .nIn(channelNum)
                        .nOut(20)
                        .activation(Activation.RELU)
                        .build())
                .layer(1, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(2, 2)
                        .build())
                .layer(2, new ConvolutionLayer.Builder(5, 5)
                        .stride(1, 1)
                        .nOut(50)
                        .activation(Activation.RELU)
                        .build())
                .layer(3, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(2, 2)
                        .build())
                .layer(4, new DenseLayer.Builder().activation(Activation.RELU)
                        .nOut(500).build())
                .layer(5, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                        .nOut(classNum)
                        .activation(Activation.SOFTMAX)
                        .build())
                //Input
                .setInputType(InputType.convolutionalFlat(height, width, channelNum))
                .backprop(true)
                .pretrain(false)
                .build();
        config.setTrainingWorkspaceMode(WorkspaceMode.SEPARATE);


        MultiLayerNetwork model = new MultiLayerNetwork(config);
        model.init();

        return model;
    }

    private MultiLayerNetwork createComplexModel() {
        MultiLayerConfiguration config = new NeuralNetConfiguration.Builder()
                .seed(seed)
                .learningRate(learningRate)
                .iterations(iterations)
                .regularization(true).l2(l2NormBeta)
                .weightInit(WeightInit.XAVIER)
                .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
                .updater(Updater.ADAGRAD)
                .list()
                //Layers
                .layer(0, new ConvolutionLayer.Builder(5, 5)
                        .stride(1, 1)
                        .nIn(channelNum)
                        .nOut(20)
                        .activation(Activation.RELU)
                        .build())
                .layer(1, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(1, 1)
                        .build())
                .layer(2, new ConvolutionLayer.Builder(5, 5)
                        .stride(1, 1)
                        .nOut(50)
                        .activation(Activation.RELU)
                        .build())
                .layer(3, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(1, 1)
                        .build())
                .layer(4, new ConvolutionLayer.Builder(3, 3)
                        .stride(1, 1)
                        .nOut(100)
                        .activation(Activation.RELU)
                        .build())
                .layer(5, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.AVG)
                        .kernelSize(2, 2)
                        .stride(2, 2)
                        .build())
                .layer(6, new DenseLayer.Builder().activation(Activation.RELU)
                        .nOut(500).build())
                .layer(7, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                        .nOut(classNum)
                        .activation(Activation.SOFTMAX)
                        .build())
                //Input
                .setInputType(InputType.convolutionalFlat(height, width, channelNum))
                .backprop(true)
                .pretrain(false)
                .build();

        MultiLayerNetwork model = new MultiLayerNetwork(config);
        model.init();

        return model;
    }

    private MultiLayerNetwork createSimpleModel() {
        MultiLayerConfiguration config = new NeuralNetConfiguration.Builder()
                .seed(seed)
                .learningRate(learningRate)
                .iterations(iterations)
                .regularization(true).l2(l2NormBeta)
                .weightInit(WeightInit.XAVIER)
                .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
                .updater(Updater.SGD)
                .list()
                //Layers
                .layer(0, new ConvolutionLayer.Builder(5, 5)
                        .stride(1, 1)
                        .nIn(channelNum)
                        .nOut(20)
                        .activation(Activation.RELU)
                        .build())
                .layer(1, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(2, 2)
                        .build())
                .layer(2, new DenseLayer.Builder().activation(Activation.RELU)
                        .nOut(500).build())
                .layer(3, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                        .nOut(classNum)
                        .activation(Activation.SOFTMAX)
                        .build())
                //Input
                .setInputType(InputType.convolutionalFlat(height, width, channelNum))
                .backprop(true)
                .pretrain(false)
                .build();

        MultiLayerNetwork model = new MultiLayerNetwork(config);
        model.init();

        return model;
    }


    public void run() throws Exception {

        log.info("Prepare dataset");
        ParentPathLabelGenerator labelGenerator = new ParentPathLabelGenerator();
        File parentFile = new File(mainPath);
        FileSplit split = new FileSplit(parentFile, NativeImageLoader.ALLOWED_FORMATS, random);
        BalancedPathFilter pathFilter = new BalancedPathFilter(random, labelGenerator, exampleNum, classNum, exampleNum);
        log.info("Get split locations " + split.locations().length + " " + split.locations()[0]);


        InputSplit[] inputSplit = split.sample(pathFilter, splitTrainTest, 1 - splitTrainTest);
        InputSplit trainInput = inputSplit[0];
        InputSplit testInput = inputSplit[1];
//        log.info("Get trainInput length " + trainInput.length() + " " + trainInput.locations()[2]);
//        log.info("Get testInput length " + testInput.length() + " " + testInput.locations()[2]);

        DataNormalization normalizer = new ImagePreProcessingScaler(0, 1);


        ImageRecordReader recordReader = new ImageRecordReader(height, width, channelNum, labelGenerator);
        recordReader.initialize(trainInput);
        DataSetIterator dataIter = new RecordReaderDataSetIterator(recordReader, batchSize, 1, classNum);
        dataIter.setPreProcessor(normalizer);
        normalizer.fit(dataIter);
        DataSetIterator trainIte = new MultipleEpochsIterator(epochNum, dataIter);

        MultiLayerNetwork model = createModel();

        UIServer uiServer = UIServer.getInstance();
        StatsStorage statsStorage = new InMemoryStatsStorage();
        uiServer.attach(statsStorage);
        model.setListeners(new StatsListener(statsStorage));
//        model.setListeners((IterationListener)new StatsListener( statsStorage),new ScoreIterationListener(iterations));
//        model.setListeners(new ScoreIterationListener(listenerFreq));
        model.fit(trainIte);

        ImageTransform flipTransform = new FlipImageTransform(new Random(123));
        ImageTransform flipTransform1 = new FlipImageTransform(seed);
        ImageTransform cropTransform = new CropImageTransform(61);
//        ImageTransform flipTransform2 = new FlipImageTransform(37);
//        ImageTransform warpTransform = new WarpImageTransform(random, 42);

        List<ImageTransform> transforms = Arrays.asList(
                new ImageTransform[]{
                        flipTransform,
                        flipTransform1,
                });



        for (ImageTransform transform: transforms) {
            recordReader.initialize(trainInput, transform);
            dataIter = new RecordReaderDataSetIterator(recordReader, batchSize, 1, classNum);
            dataIter.setPreProcessor(normalizer);
            normalizer.fit(dataIter);
            trainIte = new MultipleEpochsIterator(epochNum, dataIter);
            model.fit(trainIte);
        }

        ImageRecordReader testReader = new ImageRecordReader(height, width, channelNum, labelGenerator);
        testReader.initialize(testInput);
        DataSetIterator testIter = new RecordReaderDataSetIterator(testReader, batchSize, 1, classNum);
        testIter.setPreProcessor(normalizer);
        normalizer.fit(testIter);
        DataSetIterator testEpochIte = new MultipleEpochsIterator(1, testIter);
        Evaluation eval = model.evaluate(testEpochIte);
        log.info("-------------> " + eval.stats());


        log.info("End of test");
    }

    public MultiLayerNetwork run2() throws Exception {

        DataNormalization normalizer = new ImagePreProcessingScaler(0, 1);

        log.info("Prepare dataset");
        ParentPathLabelGenerator trainLabelGenerator = new ParentPathLabelGenerator();
        File trainParentFile = new File(mainPath);
        FileSplit trainSplit = new FileSplit(trainParentFile, NativeImageLoader.ALLOWED_FORMATS, random);

        ImageRecordReader trainRecordReader = new ImageRecordReader(height, width, channelNum, trainLabelGenerator);
        trainRecordReader.initialize(trainSplit);
        DataSetIterator trainDataIter = new RecordReaderDataSetIterator(trainRecordReader, batchSize, 1, classNum);
        trainDataIter.setPreProcessor(normalizer);
        normalizer.fit(trainDataIter);
        DataSetIterator trainEpochIte = new MultipleEpochsIterator(epochNum, trainDataIter);


        MultiLayerNetwork model = createModel();

        UIServer uiServer = UIServer.getInstance();
        StatsStorage statsStorage = new InMemoryStatsStorage();
        uiServer.attach(statsStorage);
        model.setListeners(new StatsListener(statsStorage));

//        int count = 0;
//        while(trainDataIter.hasNext()) {
//            DataSet next = trainDataIter.next();
//            count += next.asList().size();
//            INDArray labels = next.getLabels();
//            log.info("Labels " + labels);
//        }
//        log.info("# of examples: " + count);

        model.fit(trainEpochIte);

        ImageTransform flipTransform = new FlipImageTransform(new Random(123));
        ImageTransform flipTransform1 = new FlipImageTransform(seed);

        List<ImageTransform> transforms = Arrays.asList(
                new ImageTransform[]{
                        flipTransform,
                        flipTransform1,
                });



        for (ImageTransform transform: transforms) {
            trainRecordReader.initialize(trainSplit, transform);
            trainDataIter = new RecordReaderDataSetIterator(trainRecordReader, batchSize, 1, classNum);
            trainDataIter.setPreProcessor(normalizer);
            normalizer.fit(trainDataIter);
            trainEpochIte = new MultipleEpochsIterator(epochNum, trainDataIter);
            model.fit(trainEpochIte);
        }


        ParentPathLabelGenerator testLabelGenerator = new ParentPathLabelGenerator();
        File testParentFile = new File(testPath);
        FileSplit testSplit = new FileSplit(testParentFile, NativeImageLoader.ALLOWED_FORMATS, random);
        ImageRecordReader testRecordReader = new ImageRecordReader(height, width, channelNum, testLabelGenerator);
        testRecordReader.initialize(testSplit);
        DataSetIterator testDataIter = new RecordReaderDataSetIterator(testRecordReader, testBatchSize, 1, classNum);
        testDataIter.setPreProcessor(normalizer);
        normalizer.fit(testDataIter);
        DataSetIterator testEpochIte = new MultipleEpochsIterator(1, testDataIter);


        Evaluation eval = model.evaluate(testEpochIte);
        log.info("-------------> " + eval.stats());


        log.info("End of test");

        return model;
    }

    private void saveModel(MultiLayerNetwork model, DataNormalization normalizer, String fileName) throws Exception {
        File MJModelFile = new File(fileName);
        FileOutputStream fos = new FileOutputStream(MJModelFile);
        ModelSerializer.writeModel(model, fos, true);
//        ModelSerializer.addNormalizerToModel(MJModelFile, normalizer);
    }

    public void runSave() throws  Exception {
        log.info("Prepare dataset");
        ParentPathLabelGenerator labelGenerator = new ParentPathLabelGenerator();
        File parentFile = new File(mainPath);
        FileSplit split = new FileSplit(parentFile, NativeImageLoader.ALLOWED_FORMATS, random);
        BalancedPathFilter pathFilter = new BalancedPathFilter(random, labelGenerator, exampleNum, classNum, exampleNum);
        log.info("Get split locations " + split.locations().length + " " + split.locations()[0]);


        InputSplit[] inputSplit = split.sample(pathFilter, splitTrainTest, 1 - splitTrainTest);
        InputSplit trainInput = inputSplit[0];
        InputSplit testInput = inputSplit[1];
//        log.info("Get trainInput length " + trainInput.length() + " " + trainInput.locations()[2]);
//        log.info("Get testInput length " + testInput.length() + " " + testInput.locations()[2]);

        DataNormalization normalizer = new ImagePreProcessingScaler(0, 1);


        ImageRecordReader recordReader = new ImageRecordReader(height, width, channelNum, labelGenerator);
        recordReader.initialize(trainInput);
        DataSetIterator dataIter = new RecordReaderDataSetIterator(recordReader, batchSize, 1, classNum);
        dataIter.setPreProcessor(normalizer);
        normalizer.fit(dataIter);
        DataSetIterator trainIte = new MultipleEpochsIterator(epochNum, dataIter);

        MultiLayerNetwork model = createModel();

        UIServer uiServer = UIServer.getInstance();
        StatsStorage statsStorage = new InMemoryStatsStorage();
        uiServer.attach(statsStorage);
        model.setListeners(new StatsListener(statsStorage));
//        model.setListeners((IterationListener)new StatsListener( statsStorage),new ScoreIterationListener(iterations));
//        model.setListeners(new ScoreIterationListener(listenerFreq));
        model.fit(trainIte);

        ImageTransform flipTransform = new FlipImageTransform(new Random(123));
        ImageTransform flipTransform1 = new FlipImageTransform(seed);
        ImageTransform cropTransform = new CropImageTransform(61);
//        ImageTransform flipTransform2 = new FlipImageTransform(37);
//        ImageTransform warpTransform = new WarpImageTransform(random, 42);

        List<ImageTransform> transforms = Arrays.asList(
                new ImageTransform[]{
                        flipTransform,
                        flipTransform1,
                });



        for (ImageTransform transform: transforms) {
            recordReader.initialize(trainInput, transform);
            dataIter = new RecordReaderDataSetIterator(recordReader, batchSize, 1, classNum);
            dataIter.setPreProcessor(normalizer);
            normalizer.fit(dataIter);
            trainIte = new MultipleEpochsIterator(epochNum, dataIter);
            model.fit(trainIte);
        }

        ImageRecordReader testReader = new ImageRecordReader(height, width, channelNum, labelGenerator);
        testReader.initialize(testInput);
        DataSetIterator testIter = new RecordReaderDataSetIterator(testReader, batchSize, 1, classNum);
        testIter.setPreProcessor(normalizer);
        normalizer.fit(testIter);
        DataSetIterator testEpochIte = new MultipleEpochsIterator(1, testIter);
        Evaluation eval = model.evaluate(testEpochIte);
        log.info("-------------> " + eval.stats());

        saveModel(model, normalizer, "/home/zf/books/DeepLearning-master/majiong/datasets/models/test.json");

        log.info("End of test");
    }

    public void run2Save() throws  Exception{
        MultiLayerNetwork model = run2();
        String fileName = "/home/zf/books/DeepLearning-master/majiong/datasets/models/tests.json";
        saveModel(model, null, fileName);
    }

    public void runLoad() throws  Exception {
        String testModelFileName = "/home/zf/books/DeepLearning-master/majiong/datasets/models/test.json";
        FileInputStream fis = new FileInputStream(new File(testModelFileName));
        MultiLayerNetwork model = ModelSerializer.restoreMultiLayerNetwork(fis);

        DataNormalization normalizer = new ImagePreProcessingScaler(0, 1);
        ParentPathLabelGenerator testLabelGenerator = new ParentPathLabelGenerator();
        File testParentFile = new File(testPath);
        FileSplit testSplit = new FileSplit(testParentFile, NativeImageLoader.ALLOWED_FORMATS, random);
        ImageRecordReader testRecordReader = new ImageRecordReader(height, width, channelNum, testLabelGenerator);
        testRecordReader.initialize(testSplit);
        DataSetIterator testDataIter = new RecordReaderDataSetIterator(testRecordReader, testBatchSize, 1, classNum);
        testDataIter.setPreProcessor(normalizer);
        normalizer.fit(testDataIter);
        DataSetIterator testEpochIte = new MultipleEpochsIterator(1, testDataIter);


        Evaluation eval = model.evaluate(testEpochIte);
        log.info("-------------> " + eval.stats());

    }

    public void runTransfer() throws Exception {
//        ZooModel lenetModel = new LeNet();

//        Map<Integer, Double> lrSchedule = new HashMap<>();
//        lrSchedule.put(0, 0.02);
//        lrSchedule.put(2000, 0.01);
//        lrSchedule.put(4000, 0.005);

        ComputationGraph pretrainedNet = (ComputationGraph) ModelSerializer.restoreComputationGraph(
                                            new File("/home/zf/books/DeepLearning-master/majiong/datasets/models/lenet.zip"));


        FineTuneConfiguration fineTuneConf = new FineTuneConfiguration.Builder()
                                                .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
                                                .updater(Updater.ADAGRAD)
                                                .seed(seed)
//                                                .learningRatePolicy(LearningRatePolicy.Schedule)
//                                                .learningRateSchedule(lrSchedule)
                                                .learningRate(0.01)
                                                .build();

        ComputationGraph lenetTransfer = new TransferLearning.GraphBuilder(pretrainedNet)
                                            .fineTuneConfiguration(fineTuneConf)
                                            .setFeatureExtractor("fc")
                                            .removeVertexAndConnections("output")
                                            .addLayer("output",
                                                    new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                                                        .nIn(500)
                                                        .nOut(classNum)
                                                        .weightInit(WeightInit.XAVIER)
                                                        .activation(Activation.SOFTMAX).build(), "fc")
                                            .setOutputs("output")
                                                    .build();

        UIServer uiServer = UIServer.getInstance();
        StatsStorage statsStorage = new InMemoryStatsStorage();
        uiServer.attach(statsStorage);
        lenetTransfer.setListeners(new StatsListener(statsStorage));

        DataNormalization normalizer = new ImagePreProcessingScaler(0, 1);

        log.info("Prepare dataset");
        int transferHeight = 28;
        int transferWeight = 28;
        int transferBatchSize = 16;
        int myEpochNum = epochNum * iterations;
        ParentPathLabelGenerator trainLabelGenerator = new ParentPathLabelGenerator();
        File trainParentFile = new File(mainPath);
        FileSplit trainSplit = new FileSplit(trainParentFile, NativeImageLoader.ALLOWED_FORMATS, random);

        ImageRecordReader trainRecordReader = new ImageRecordReader(transferHeight, transferWeight, channelNum, trainLabelGenerator);
        trainRecordReader.initialize(trainSplit);
        DataSetIterator trainDataIter = new RecordReaderDataSetIterator(trainRecordReader, transferBatchSize, 1, classNum);
        trainDataIter.setPreProcessor(normalizer);
        normalizer.fit(trainDataIter);
        DataSetIterator trainEpochIte = new MultipleEpochsIterator(myEpochNum, trainDataIter);

        lenetTransfer.fit(trainEpochIte);

        ImageTransform flipTransform = new FlipImageTransform(new Random(123));
        ImageTransform flipTransform1 = new FlipImageTransform(seed);
        ImageTransform cropTransform = new CropImageTransform(61);
        ImageTransform flipTransform2 = new FlipImageTransform(37);
        ImageTransform warpTransform = new WarpImageTransform(random, 42);

        List<ImageTransform> transforms = Arrays.asList(
                new ImageTransform[]{
//                        flipTransform,
                        flipTransform1,
                        flipTransform2,
//                        warpTransform,
                });



        for (ImageTransform transform: transforms) {
            trainRecordReader.initialize(trainSplit, transform);
            trainDataIter = new RecordReaderDataSetIterator(trainRecordReader, batchSize, 1, classNum);
            trainDataIter.setPreProcessor(normalizer);
            normalizer.fit(trainDataIter);
            trainEpochIte = new MultipleEpochsIterator(epochNum, trainDataIter);
            lenetTransfer.fit(trainEpochIte);
        }




        ParentPathLabelGenerator testLabelGenerator = new ParentPathLabelGenerator();
        File testParentFile = new File(testPath);
        FileSplit testSplit = new FileSplit(testParentFile, NativeImageLoader.ALLOWED_FORMATS, random);
        ImageRecordReader testRecordReader = new ImageRecordReader(transferWeight, transferWeight, channelNum, testLabelGenerator);
        testRecordReader.initialize(testSplit);
        DataSetIterator testDataIter = new RecordReaderDataSetIterator(testRecordReader, transferBatchSize, 1, classNum);
        testDataIter.setPreProcessor(normalizer);
        normalizer.fit(testDataIter);
        DataSetIterator testEpochIte = new MultipleEpochsIterator(1, testDataIter);


        Evaluation eval = lenetTransfer.evaluate(testEpochIte);
        log.info("-------------> " + eval.stats());
    }

    public static void main(String[] args) throws Exception {
        new MajhiongClassifier().run2();
    }
}
