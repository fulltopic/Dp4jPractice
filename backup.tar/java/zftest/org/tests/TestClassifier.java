package zftest.org.tests;

import org.datavec.api.io.labels.ParentPathLabelGenerator;
import org.datavec.api.split.FileSplit;
import org.datavec.image.loader.NativeImageLoader;
import org.datavec.image.recordreader.ImageRecordReader;
import org.datavec.image.transform.FlipImageTransform;
import org.datavec.image.transform.ImageTransform;
import org.deeplearning4j.api.storage.StatsStorage;
import org.deeplearning4j.datasets.datavec.RecordReaderDataSetIterator;
import org.deeplearning4j.datasets.iterator.MultipleEpochsIterator;
import org.deeplearning4j.eval.Evaluation;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;
import org.deeplearning4j.nn.conf.*;
import org.deeplearning4j.nn.conf.inputs.InputType;
import org.deeplearning4j.nn.conf.layers.ConvolutionLayer;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.conf.layers.SubsamplingLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.ui.api.UIServer;
import org.deeplearning4j.ui.stats.StatsListener;
import org.deeplearning4j.ui.storage.InMemoryStatsStorage;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.api.preprocessor.DataNormalization;
import org.nd4j.linalg.dataset.api.preprocessor.ImagePreProcessingScaler;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.*;

public class TestClassifier {
    private static final Logger log = LoggerFactory.getLogger(MajhiongClassifier.class);
    private static final int exampleNum = 202 * 3;
    private static final int classNum = 3;
    private static final int batchSize = 16;
    private static final int testBatchSize = 9;
    private static final int epochNum = 25;
    private static final int height = 30;
    private static final int width = 20;
    //    private static final int height = 20;
//    private static final int width = 20;
    private static final int channelNum = 1;
    private static double splitTrainTest = 0.8;
    private static int iterations = 4;
    private static double learningRate = 0.01;

    private static final int seed = 71;
    private static Random random = new Random(seed);
    private static int listenerFreq = 1;
    private static boolean save = false;
    double l2NormBeta = 0.0005;

    private static final String mainPath = "/home/zf/books/DeepLearning-master/majiong/datasets/dataset6";
    private static final String testPath = "/home/zf/books/DeepLearning-master/majiong/datasets/datasettest";

    private MultiLayerNetwork createModel() {
        Map<Integer, Double> lrSchedule = new HashMap<>();
        lrSchedule.put(0, 0.01);
//        lrSchedule.put(1000, 0.005);
//        lrSchedule.put(3000, 0.001);
        lrSchedule.put(3000, 0.005);
//        lrSchedule.put((int)(splitTrainTest * exampleNum * epochNum * iterations / batchSize + 20), 0.005);
//        lrSchedule.put(2000, 0.005);

        MultiLayerConfiguration config = new NeuralNetConfiguration.Builder()
                .seed(seed)
//                .learningRate(learningRate)
                .learningRateDecayPolicy(LearningRatePolicy.Schedule)
                .learningRateSchedule(lrSchedule)
                .iterations(iterations)
                .regularization(true).l2(l2NormBeta)
                .weightInit(WeightInit.XAVIER)
                .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
                .updater(Updater.ADAGRAD)
                .list()
                //Layers
                .layer(0, new ConvolutionLayer.Builder(2, 2)
                        .padding(1, 1)
                        .stride(1, 1)
                        .nIn(channelNum)
                        .nOut(20)
                        .activation(Activation.RELU)
                        .build())
                .layer(1, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(2, 2)
                        .build())
                .layer(2, new ConvolutionLayer.Builder(5, 5)
                        .stride(1, 1)
                        .nOut(50)
                        .activation(Activation.RELU)
                        .build())
                .layer(3, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(2, 2)
                        .build())
                .layer(4, new DenseLayer.Builder().activation(Activation.RELU)
                        .nOut(500).build())
                .layer(5, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                        .nOut(classNum)
                        .activation(Activation.SOFTMAX)
                        .build())
                //Input
                .setInputType(InputType.convolutionalFlat(height, width, channelNum))
                .backprop(true)
                .pretrain(false)
                .build();
        config.setTrainingWorkspaceMode(WorkspaceMode.SEPARATE);


        MultiLayerNetwork model = new MultiLayerNetwork(config);
        model.init();

        return model;
    }


    public MultiLayerNetwork run2() throws Exception {

        DataNormalization normalizer = new ImagePreProcessingScaler(0, 1);

        log.info("Prepare dataset");
        ParentPathLabelGenerator trainLabelGenerator = new ParentPathLabelGenerator();
        File trainParentFile = new File(mainPath);
        FileSplit trainSplit = new FileSplit(trainParentFile, NativeImageLoader.ALLOWED_FORMATS, random);

        ImageRecordReader trainRecordReader = new ImageRecordReader(height, width, channelNum, trainLabelGenerator);
        trainRecordReader.initialize(trainSplit);
        DataSetIterator trainDataIter = new RecordReaderDataSetIterator(trainRecordReader, batchSize, 1, classNum);
        trainDataIter.setPreProcessor(normalizer);
        normalizer.fit(trainDataIter);
        DataSetIterator trainEpochIte = new MultipleEpochsIterator(epochNum, trainDataIter);


        MultiLayerNetwork model = createModel();

        UIServer uiServer = UIServer.getInstance();
        StatsStorage statsStorage = new InMemoryStatsStorage();
        uiServer.attach(statsStorage);
        model.setListeners(new StatsListener(statsStorage));

//        int count = 0;
//        while(trainDataIter.hasNext()) {
//            DataSet next = trainDataIter.next();
//            count += next.asList().size();
//            INDArray labels = next.getLabels();
//            log.info("Labels " + labels);
//        }
//        log.info("# of examples: " + count);

        model.fit(trainEpochIte);

        ImageTransform flipTransform = new FlipImageTransform(new Random(123));
        ImageTransform flipTransform1 = new FlipImageTransform(seed);

        List<ImageTransform> transforms = Arrays.asList(
                new ImageTransform[]{
                        flipTransform,
                        flipTransform1,
                });



        for (ImageTransform transform: transforms) {
            trainRecordReader.initialize(trainSplit, transform);
            trainDataIter = new RecordReaderDataSetIterator(trainRecordReader, batchSize, 1, classNum);
            trainDataIter.setPreProcessor(normalizer);
            normalizer.fit(trainDataIter);
            trainEpochIte = new MultipleEpochsIterator(epochNum, trainDataIter);
            model.fit(trainEpochIte);
        }


        ParentPathLabelGenerator testLabelGenerator = new ParentPathLabelGenerator();
        File testParentFile = new File(testPath);
        FileSplit testSplit = new FileSplit(testParentFile, NativeImageLoader.ALLOWED_FORMATS, random);
        ImageRecordReader testRecordReader = new ImageRecordReader(height, width, channelNum, testLabelGenerator);
        testRecordReader.initialize(testSplit);
        DataSetIterator testDataIter = new RecordReaderDataSetIterator(testRecordReader, testBatchSize, 1, classNum);
        testDataIter.setPreProcessor(normalizer);
        normalizer.fit(testDataIter);
        DataSetIterator testEpochIte = new MultipleEpochsIterator(1, testDataIter);


        Evaluation eval = model.evaluate(testEpochIte);
        log.info("-------------> " + eval.stats());


        log.info("End of test");

        return model;
    }

    public static void main(String[] args) throws Exception {
        new TestClassifier().run2();
    }

}
