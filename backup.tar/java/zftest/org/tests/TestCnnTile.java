package zftest.org.tests;

import org.deeplearning4j.api.storage.StatsStorage;
import org.deeplearning4j.eval.EvaluationBinary;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;
import org.deeplearning4j.nn.conf.*;
import org.deeplearning4j.nn.conf.inputs.InputType;
import org.deeplearning4j.nn.conf.layers.ConvolutionLayer;
import org.deeplearning4j.nn.conf.layers.DenseLayer;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.conf.layers.SubsamplingLayer;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.ui.api.UIServer;
import org.deeplearning4j.ui.stats.StatsListener;
import org.deeplearning4j.ui.storage.InMemoryStatsStorage;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.api.preprocessor.DataNormalization;
import org.nd4j.linalg.dataset.api.preprocessor.ImagePreProcessingScaler;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import zftest.org.dataprocess.RawTileLabelFetcher;
import zftest.org.dataprocess.TilesDataFetcher;
import zftest.org.dataprocess.TilesDataSetIterator;

import java.util.HashMap;
import java.util.Map;

public class TestCnnTile {
    private int batchSize = 16;
    private int numTrainExamples = 32; //588
    private int numTestExamples = 16;

    private DataSetIterator createTrainIterator() throws Exception {
        String trainExamplePath = "/home/zf/workspaces/workspace_java/mjconv2/datasets/tiles/train/";
        TilesDataFetcher trainFetcher = new TilesDataFetcher(trainExamplePath, true);
        DataSetIterator mjTrain = new TilesDataSetIterator(batchSize, numTrainExamples, trainFetcher);

        return mjTrain;
    }

    private DataSetIterator createTestIterator() throws Exception {
        String testExamplePath = "/home/zf/workspaces/workspace_java/mjconv2/datasets/tiles/test/";
        TilesDataFetcher testFetcher = new TilesDataFetcher(testExamplePath, false);
        DataSetIterator mjTest = new TilesDataSetIterator(batchSize, numTestExamples, testFetcher);

        return mjTest;
    }

    public void testIterator() throws Exception {
//        int nChannels = TilesDataFetcher.GetChanNum();
//        int outputNum = 2;
//        int nEpochs = 2;
//        int iterations = 1;
//
//        double l2NormBeta = 0.0005;
//        int width = TilesDataFetcher.GetWidth();
//        int height = TilesDataFetcher.GetHeight();
//        int classNum = RawTileLabelFetcher.TileNum;

        System.out.println("Load data ... ");

        DataSetIterator mjTrain = createTrainIterator();
        DataSetIterator mjTest = createTestIterator();

        int trainIte = 0;
        while(mjTrain.hasNext()) {
            DataSet next = mjTrain.next();
            INDArray features = next.getFeatureMatrix();
            INDArray labels = next.getLabels();

            System.out.println("Get features: " + features.rows() + ", " + features.columns());
            System.out.println("Get labels: " + labels.rows() + ", " + labels.columns());
            System.out.println("" + labels);
            trainIte ++;
        }

        int testIte = 0;
        while(mjTest.hasNext()) {
            DataSet next = mjTest.next();
            INDArray features = next.getFeatureMatrix();
            INDArray labels = next.getLabels();

            System.out.println("Get features: " + features.rows() + ", " + features.columns());
            System.out.println("Get labels: " + labels.rows() + ", " + labels.columns());
            System.out.println("" + labels);
            testIte ++;
        }

        System.out.println("====================================> " + trainIte * batchSize + ", " + testIte * batchSize);
    }

    public MultiLayerNetwork createCnn() {
        int seed = 47;
        int iterations = 1;
        double l2NormBeta = 0.0005;
        int nChannels = TilesDataFetcher.GetChanNum();
        int outputNum = RawTileLabelFetcher.TileNum;
        int height = TilesDataFetcher.GetHeight();
        int width = TilesDataFetcher.GetWidth();

        Map<Integer, Double> lrSchedule = new HashMap<>();
        lrSchedule.put(0, 0.01);
        lrSchedule.put(500, 0.005);

        MultiLayerConfiguration config = new NeuralNetConfiguration.Builder()
                .seed(seed)
                .learningRateDecayPolicy(LearningRatePolicy.Schedule)
                .learningRateSchedule(lrSchedule)
                .iterations(iterations)
                .regularization(true).l2(l2NormBeta)
                .weightInit(WeightInit.XAVIER)
                .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
                .updater(Updater.NESTEROVS)
                .list()
                //Layer
                .layer(0, new ConvolutionLayer.Builder(4, 4)
                        .stride(1, 1)
                        .nIn(nChannels)
                        .nOut(20)
                        .activation(Activation.RELU)
                        .build())
                .layer(1, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(2, 2)
                        .build())
                .layer(2, new ConvolutionLayer.Builder(4, 4)
                        .stride(1, 1)
                        .nOut(50)
                        .activation(Activation.RELU)
                        .build())
                .layer(3, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(2, 2)
                        .build())
                .layer(4, new DenseLayer.Builder().activation(Activation.RELU)
                        .nOut(500)
                        .build())
                .layer(5, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                        .nOut(outputNum)
                        .activation(Activation.SOFTMAX)
                        .build())
                .setInputType(InputType.convolutionalFlat(height, width, nChannels))
                .backprop(true)
                .pretrain(false)
                .build();
        config.setTrainingWorkspaceMode(WorkspaceMode.SEPARATE);


        MultiLayerNetwork model = new MultiLayerNetwork(config);
        model.init();

        return model;
    }

    public MultiLayerNetwork createForward() {
        int seed = 47;
        int iterations = 1;
        double l2NormBeta = 0.0005;
        int nChannels = TilesDataFetcher.GetChanNum();
        int outputNum = RawTileLabelFetcher.TileNum;
        int height = TilesDataFetcher.GetHeight();
        int width = TilesDataFetcher.GetWidth();
        Map<Integer, Double> lrSchedule = new HashMap<>();
        lrSchedule.put(0, 0.01);
        lrSchedule.put(500, 0.005);

        MultiLayerConfiguration config = new NeuralNetConfiguration.Builder()
                .seed(seed)
                .learningRateDecayPolicy(LearningRatePolicy.Schedule)
                .learningRateSchedule(lrSchedule)
                .iterations(iterations)
                .regularization(true).l2(l2NormBeta)
                .weightInit(WeightInit.XAVIER)
                .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
                .updater(Updater.NESTEROVS)
                .list()
//                .layer(0, new DenseLayer.Builder().activation(Activation.RELU)
//                                .nOut(500)
//                                .build())
                .layer(0, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                                .nOut(outputNum)
                                .activation(Activation.SOFTMAX)
                                .build())
                .setInputType(InputType.convolutionalFlat(height, width, nChannels))
                .backprop(true)
                .pretrain(false)
                .build();
        config.setTrainingWorkspaceMode(WorkspaceMode.SEPARATE);

        MultiLayerNetwork model = new MultiLayerNetwork(config);
        model.init();

        return model;
    }

    public void testNN(MultiLayerNetwork model) throws Exception {
        int nEpochs = 20;


        System.out.println("Load data ... ");

        DataSetIterator mjTrain = createTrainIterator();
        DataSetIterator mjTest = createTestIterator();

        DataNormalization normalizer = new ImagePreProcessingScaler(0, 1);
        mjTest.setPreProcessor(normalizer);
        mjTrain.setPreProcessor(normalizer);
        normalizer.fit(mjTest);
        normalizer.fit(mjTrain);

//        MultiLayerNetwork model = createCnn();

        UIServer uiServer = UIServer.getInstance();
        StatsStorage statsStorage = new InMemoryStatsStorage();
        uiServer.attach(statsStorage);

        model.setListeners(new StatsListener(statsStorage));

        System.out.println("Training... ");
        for(int i = 0; i < nEpochs; i ++) {
            mjTrain.reset();
            mjTest.reset();
            model.fit(mjTrain);
            System.out.println("*** Completed epoch *** " + i);

//            ROCBinary eval = new ROCBinary();
            EvaluationBinary eval = new EvaluationBinary();
            model.doEvaluation(mjTest, eval);
            System.out.println("********* Evaluation *****************");
            System.out.println("" + eval.stats());

        }

        System.out.println("End of test");
    }

    public static void main(String[] args) {
        TestCnnTile tester = new TestCnnTile();
        try {
            MultiLayerNetwork model = tester.createForward();
            tester.testNN(model);
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
}
