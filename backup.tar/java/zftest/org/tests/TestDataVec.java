package zftest.org.tests;

import org.datavec.api.io.filters.BalancedPathFilter;
import org.datavec.api.split.FileSplit;
import org.datavec.api.split.InputSplit;
import org.datavec.image.loader.NativeImageLoader;
import org.datavec.image.recordreader.ImageRecordReader;
import org.deeplearning4j.datasets.datavec.RecordReaderDataSetIterator;
import org.deeplearning4j.datasets.datavec.RecordReaderMultiDataSetIterator;
import org.deeplearning4j.datasets.iterator.impl.MnistDataSetIterator;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.api.MultiDataSet;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.api.iterator.MultiDataSetIterator;
import zftest.org.dataprocess.*;

import java.io.File;
import java.io.IOException;
import java.util.Random;

public class TestDataVec {
    public static void TestMnistDataVec() {
        int batchSize = 1; // Test batch size

        /*
            Create an iterator using the batch size for one iteration
         */
        System.out.println("Get datas");

        try {
            DataSetIterator mnistTrain = new MnistDataSetIterator(batchSize, true, 12345);
//            DataSetIterator mnistTest = new MnistDataSetIterator(batchSize, false, 12345);

            DataSet next = mnistTrain.next();
            INDArray features = next.getFeatureMatrix();
            INDArray labels = next.getLabels();

            System.out.println("Get features: " + features.rows() + ", " + features.columns());
            System.out.println("Get labels: " + labels.rows() + ", " + labels.columns());
            System.out.println("" + labels);

//            next = mnistTrain.next();
//            labels = next.getLabels();
//            System.out.println("Get another labels: " + labels);
        }catch(IOException ie) {
            ie.printStackTrace();
            return;
        }
    }

    public static void TestCustomDataVec() {
        long seed = 42;
        Random rng = new Random(seed);
        int numExamples = 20;
        int numLabels = 34;
        int batchSize = 1;
        double splitTrainTest = 0.8;
        int height = 100;
        int width = 100;
        int chanels = 3;
        String READER_KEY = "reader";

        TileLabelGenerator labelMaker = new TileLabelGenerator();
        File mainPath = new File("/home/zf/workspaces/workspace_java/mjconv2/db3/images");
        FileSplit fileSplit = new FileSplit(mainPath, NativeImageLoader.ALLOWED_FORMATS, rng);
        BalancedPathFilter pathFilter = new BalancedPathFilter(rng, labelMaker, numExamples, numLabels, batchSize);

        InputSplit[] inputSplit = fileSplit.sample(pathFilter, splitTrainTest, 1 - splitTrainTest);
        InputSplit trainData = inputSplit[0];
//        InputSplit testData = inputSplit[1];

        ImageRecordReader recordReader = new ImageRecordReader(height, width, chanels, labelMaker);

        try {
            recordReader.initialize(trainData, null);
            DataSetIterator dataIte = new MultiLabelRecordReaderDataSetIterator(recordReader,  batchSize, 0, numLabels);
//            MultiDataSetIterator dataIte = new RecordReaderMultiDataSetIterator.Builder(batchSize)
//                                            .addReader(READER_KEY, recordReader)
//                                            .addOutput(READER_KEY, 0, numLabels)
//                                            .addInput(READER_KEY)
//                                            .build();

            if(dataIte.hasNext()) {
                DataSet next = dataIte.next();
                INDArray features = next.getFeatureMatrix();
                INDArray labels = next.getLabels();

                System.out.println("Get features: " + features.rows() + ", " + features.columns());
                System.out.println("Get labels: " + labels.rows() + ", " + labels.columns());
                System.out.println("" + labels);
            }
        }catch(IOException ie) {
            ie.printStackTrace();
            return;
        }
    }

    public static void TestMjDataVec() {
        String path = "/home/zf/workspaces/workspace_java/mjconv2/db3";
        int exampleNum = 326;
        int batchSize = 2;
        int count = 0;

        try {
//            DataSetIterator dataIte = new MjDataSetIterator(batchSize, exampleNum, true, path, 34);
            MjDataFetcher fetcher = new MjDataFetcher1w(path, true, 2);
            DataSetIterator dataIte = new MjDataSetIterator(batchSize, exampleNum, fetcher);
            INDArray lastFeatures = null;
            while (dataIte.hasNext()) {
                DataSet next = dataIte.next();
                INDArray features = next.getFeatureMatrix();

                INDArray diff = features.eq(lastFeatures);
                System.out.println("==============================> " + diff.sum(1).sum(1));

                lastFeatures = features;

                INDArray labels = next.getLabels();

                count ++;

                System.out.println("Get features: " + features.rows() + ", " + features.columns());
                System.out.println("Get labels: " + labels.rows() + ", " + labels.columns());
                System.out.println("" + labels);
            }
        }catch(IOException ie) {
            ie.printStackTrace();
        }

        System.out.println("*****************************************************Read " + count + " examples");
    }
}
