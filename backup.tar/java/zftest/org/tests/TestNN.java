package zftest.org.tests;

import org.deeplearning4j.api.storage.StatsStorage;
import org.deeplearning4j.datasets.iterator.impl.MnistDataSetIterator;
import org.deeplearning4j.eval.Evaluation;
import org.deeplearning4j.eval.EvaluationBinary;
import org.deeplearning4j.eval.ROCBinary;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;
import org.deeplearning4j.nn.conf.*;
import org.deeplearning4j.nn.conf.inputs.InputType;
import org.deeplearning4j.nn.conf.layers.*;
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.ui.api.UIServer;
import org.deeplearning4j.ui.stats.StatsListener;
import org.deeplearning4j.ui.storage.InMemoryStatsStorage;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.api.preprocessor.DataNormalization;
import org.nd4j.linalg.dataset.api.preprocessor.ImagePreProcessingScaler;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import zftest.org.dataprocess.EvaluationTanh;
import zftest.org.dataprocess.MjDataFetcher;
import zftest.org.dataprocess.MjDataFetcher1w;
import zftest.org.dataprocess.MjDataSetIterator;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class TestNN {
    public static void InitTest() throws Exception{
        int nChannels = 1;
        int outputNum = 34;
        int batchSize = 32;
        int nEpochs = 2;
        int iterations = 2;
        int seed = 47;
        int numTrainExamples = 400; //588
        int numTestExamples = 32;
        double l2NormBeta = 0.0005;
        int width = 400;
        int height = 300;

        String trainExamplePath = "/home/zf/workspaces/workspace_java/mjconv2/db3";
        String testExamplePath = "/home/zf/workspaces/workspace_java/mjconv2/db2";

        System.out.println("Load data ... ");
        DataSetIterator mjTrain = new MjDataSetIterator(batchSize, numTrainExamples, true, trainExamplePath, outputNum);
        DataSetIterator mjTest = new MjDataSetIterator(batchSize, numTestExamples,false, testExamplePath, outputNum);

        System.out.println("Build model ... ");

        Map<Integer, Double> lrSchedule = new HashMap<>();
        lrSchedule.put(0, 0.001);
        lrSchedule.put(500, 0.005);

        DataNormalization normalizer = new ImagePreProcessingScaler(0, 1);
        mjTest.setPreProcessor(normalizer);
        mjTrain.setPreProcessor(normalizer);
        normalizer.fit(mjTest);
        normalizer.fit(mjTrain);


        MultiLayerConfiguration config = new NeuralNetConfiguration.Builder()
                .seed(seed)
                .learningRateDecayPolicy(LearningRatePolicy.Schedule)
                .learningRateSchedule(lrSchedule)
                .iterations(iterations)
                .regularization(true).l2(l2NormBeta)
                .weightInit(WeightInit.XAVIER)
                .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
                .updater(Updater.NESTEROVS)
                .list()
                //Layer
                .layer(0, new ConvolutionLayer.Builder(4, 4)
                                    .stride(1, 1)
                                    .nIn(nChannels)
                                    .nOut(20)
                                    .activation(Activation.RELU)
                                    .build())
                .layer(1, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                                    .kernelSize(2, 2)
                                    .stride(2, 2)
                                    .build())
                .layer(2, new ConvolutionLayer.Builder(4, 4)
                                    .stride(1, 1)
                                    .nOut(50)
                                    .activation(Activation.RELU)
                                    .build())
                .layer(3, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                                    .kernelSize(2, 2)
                                    .stride(2, 2)
                                    .build())
                .layer(4, new DenseLayer.Builder().activation(Activation.RELU)
                                    .nOut(500)
                                    .build())
                .layer(5, new OutputLayer.Builder(LossFunctions.LossFunction.HINGE)
                                    .nOut(outputNum)
                                    .activation(Activation.TANH)
                                    .build())
                .setInputType(InputType.convolutionalFlat(height, width, nChannels))
                .backprop(true)
                .pretrain(false)
                .build();
        config.setTrainingWorkspaceMode(WorkspaceMode.SEPARATE);


        MultiLayerNetwork model = new MultiLayerNetwork(config);
        model.init();

        UIServer uiServer = UIServer.getInstance();
        StatsStorage statsStorage = new InMemoryStatsStorage();
        uiServer.attach(statsStorage);

        model.setListeners(new StatsListener(statsStorage));

        System.out.println("Training... ");
        for(int i = 0; i < nEpochs; i ++) {
            mjTrain.reset();
            mjTest.reset();
            model.fit(mjTrain);
            System.out.println("*** Completed epoch *** " + i);

//            ROCBinary eval = new ROCBinary();
//            mjTest.reset();
            INDArray allZeros = Nd4j.zeros(mjTest.inputColumns());
            EvaluationTanh eval = new EvaluationTanh(allZeros);
            model.doEvaluation(mjTest, eval);
            System.out.println("********* Evaluation *****************");
            System.out.println("" + eval.stats());

            //To get predict

//            System.out.println("The normalizer fit for labels? " + normalizer.isFitLabel());
//            while (mjTest.hasNext()) {
//                DataSet next = mjTest.next();
//                INDArray features = next.getFeatureMatrix();
//                INDArray labels = next.getLabels();
//                System.out.println("Get labels " + labels);
//                INDArray predicts = model.output(features, false);
//                System.out.println("Get predicts: " + predicts);
//
//                eval.eval(labels, predicts);
//            }

        }

        System.out.println("End of test");
    }

    public static void Test1w () throws IOException{
        int nChannels = 1;
        int outputNum = 2;
        int batchSize = 32;
        int nEpochs = 2;
        int iterations = 1;
        int seed = 47;
        int numTrainExamples = 400; //588
        int numTestExamples = 32;
        double l2NormBeta = 0.0005;
        int width = 400;
        int height = 300;

        System.out.println("=================================================> Get epoch " + nEpochs);

        String trainExamplePath = "/home/zf/workspaces/workspace_java/mjconv2/db3";
        String testExamplePath = "/home/zf/workspaces/workspace_java/mjconv2/db2";

        System.out.println("Load data ... ");
        MjDataFetcher trainFetcher = new MjDataFetcher1w(trainExamplePath, true, outputNum);
        MjDataFetcher testFetcher = new MjDataFetcher1w(testExamplePath, false, outputNum);
        DataSetIterator mjTrain = new MjDataSetIterator(batchSize, numTrainExamples, trainFetcher);
        DataSetIterator mjTest = new MjDataSetIterator(batchSize, numTestExamples, testFetcher);

        System.out.println("Build model ... ");

        Map<Integer, Double> lrSchedule = new HashMap<>();
        lrSchedule.put(0, 0.01);
        lrSchedule.put(500, 0.005);

        DataNormalization normalizer = new ImagePreProcessingScaler(0, 1);
        mjTest.setPreProcessor(normalizer);
        mjTrain.setPreProcessor(normalizer);
        normalizer.fit(mjTest);
        normalizer.fit(mjTrain);


        MultiLayerConfiguration config = new NeuralNetConfiguration.Builder()
                .seed(seed)
                .learningRateDecayPolicy(LearningRatePolicy.Schedule)
                .learningRateSchedule(lrSchedule)
                .iterations(iterations)
                .regularization(true).l2(l2NormBeta)
                .weightInit(WeightInit.XAVIER)
                .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
                .updater(Updater.NESTEROVS)
                .list()
                //Layer
                .layer(0, new ConvolutionLayer.Builder(4, 4)
                        .stride(1, 1)
                        .nIn(nChannels)
                        .nOut(20)
                        .activation(Activation.RELU)
                        .build())
                .layer(1, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(2, 2)
                        .build())
                .layer(2, new ConvolutionLayer.Builder(4, 4)
                        .stride(1, 1)
                        .nOut(50)
                        .activation(Activation.RELU)
                        .build())
                .layer(3, new SubsamplingLayer.Builder(SubsamplingLayer.PoolingType.MAX)
                        .kernelSize(2, 2)
                        .stride(2, 2)
                        .build())
                .layer(4, new DenseLayer.Builder().activation(Activation.RELU)
                        .nOut(500)
                        .build())
                .layer(5, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                        .nOut(outputNum)
                        .activation(Activation.SOFTMAX)
                        .build())
                .setInputType(InputType.convolutionalFlat(height, width, nChannels))
                .backprop(true)
                .pretrain(false)
                .build();
        config.setTrainingWorkspaceMode(WorkspaceMode.SEPARATE);


        MultiLayerNetwork model = new MultiLayerNetwork(config);
        model.init();

        UIServer uiServer = UIServer.getInstance();
        StatsStorage statsStorage = new InMemoryStatsStorage();
        uiServer.attach(statsStorage);

        model.setListeners(new StatsListener(statsStorage));

        System.out.println("Training... ");
        for(int i = 0; i < nEpochs; i ++) {
            mjTrain.reset();
            mjTest.reset();
            model.fit(mjTrain);
            System.out.println("*** Completed epoch *** " + i);

//            ROCBinary eval = new ROCBinary();
            EvaluationBinary eval = new EvaluationBinary();
            model.doEvaluation(mjTest, eval);
            System.out.println("********* Evaluation *****************");
            System.out.println("" + eval.stats());

            //To get predict

//            System.out.println("The normalizer fit for labels? " + normalizer.isFitLabel());
//            while (mjTest.hasNext()) {
//                DataSet next = mjTest.next();
//                INDArray features = next.getFeatureMatrix();
//                INDArray labels = next.getLabels();
//                System.out.println("Get labels " + labels);
//                INDArray predicts = model.output(features, false);
//                System.out.println("Get predicts: " + predicts);
//
//                eval.eval(labels, predicts);
//            }

        }

        System.out.println("End of test");
    }
}
