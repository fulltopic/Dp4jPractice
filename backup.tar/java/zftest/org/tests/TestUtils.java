package zftest.org.tests;

import zftest.org.dataprocess.TileLabelGenerator;
import zftest.org.preprocessor.FormatImages;
import zftest.org.preprocessor.TextToBoolean;

public class TestUtils {
    public static void TestPathLabel() {
        String path = "/home/zf/workspaces/workspace_java/mjconv2/db1/images/";
        String fileName = "2018-05-04 16:31:00.465243188 +0800 CST m=+43.654121300.png";
        TileLabelGenerator generator = new TileLabelGenerator();
        System.out.println("Get " + generator.getLabelForPath(path + fileName));
        System.out.println("Get " + generator.getLabelForPath(path));
    }

    public static void TestConvertLabels() {
        String srcPath = "/home/zf/workspaces/workspace_java/mjconv2/db4/rawtiles";
        String dstPath = "/home/zf/workspaces/workspace_java/mjconv2/db4/tiles";
        TextToBoolean.ConvertDir(srcPath, dstPath);
    }

    public static void TestRegex() {
        String content = "<INIT seed=\"0,0,0,0,0,104\" ten=\"250,250,250,250\" oya=\"0\" hai=\"49,13,119,53,106,38,109,44,36,54,14,27,60\"/>";
//        String regex = "s*,hai,s*";
        String[] parts = content.split("\"");
        for(String part: parts){
            System.out.println(part);
        }
        String hai = parts[parts.length - 2];
        System.out.println(hai);
        String[] tiles = hai.split(",");
        for(String tile: tiles) {
            System.out.println(tile);
        }
    }

    public static void TestProcessImages() {
        String srcPath = "/home/zf/workspaces/workspace_java/mjconv2/db4/cutimages";
        String dstPath = "/home/zf/workspaces/workspace_java/mjconv2/db4/images";
        FormatImages formater = new FormatImages(srcPath, dstPath);
        formater.format(326, 400, 300);
//        formater.readImage(dstPath + "/" + "2.png");
    }
}
