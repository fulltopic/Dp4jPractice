package zftest.org.tests;

import org.datavec.api.io.labels.ParentPathLabelGenerator;
import org.datavec.api.split.FileSplit;
import org.datavec.image.loader.NativeImageLoader;
import org.datavec.image.recordreader.ImageRecordReader;
import org.datavec.image.transform.FlipImageTransform;
import org.datavec.image.transform.ImageTransform;
import org.deeplearning4j.datasets.datavec.RecordReaderDataSetIterator;
import org.deeplearning4j.datasets.iterator.MultipleEpochsIterator;
import org.deeplearning4j.eval.Evaluation;
import org.deeplearning4j.nn.api.OptimizationAlgorithm;
import org.deeplearning4j.nn.conf.ComputationGraphConfiguration;
import org.deeplearning4j.nn.conf.Updater;
import org.deeplearning4j.nn.conf.WorkspaceMode;
import org.deeplearning4j.nn.conf.layers.OutputLayer;
import org.deeplearning4j.nn.graph.ComputationGraph;
import org.deeplearning4j.nn.transferlearning.FineTuneConfiguration;
import org.deeplearning4j.nn.transferlearning.TransferLearning;
import org.deeplearning4j.nn.weights.WeightInit;
import org.deeplearning4j.zoo.PretrainedType;
import org.deeplearning4j.zoo.ZooModel;
import org.deeplearning4j.zoo.model.VGG19;
import org.nd4j.linalg.activations.Activation;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.api.preprocessor.DataNormalization;
import org.nd4j.linalg.dataset.api.preprocessor.ImagePreProcessingScaler;
import org.nd4j.linalg.lossfunctions.LossFunctions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class VGG16Classifier {
    private static final int Seed = 71;
    private double learningRate = 0.01;
    private static final int ClassNum = 3;
    private static Random MjRandom = new Random(Seed);
    private static final int ChannelNum = 3;

    private static final Logger log = LoggerFactory.getLogger(VGG16Classifier.class);

    private ComputationGraph createModel() throws  Exception {
        ZooModel zooModel = new VGG19();
        ComputationGraph vgg16 = (ComputationGraph) zooModel.initPretrained(PretrainedType.IMAGENET);

        ComputationGraphConfiguration vgg16Conf = vgg16.getConfiguration();
        vgg16Conf.setTrainingWorkspaceMode(WorkspaceMode.SEPARATE);

//        List<NeuralNetConfiguration> confs = vgg16Con

//        Iterator<NeuralNetConfiguration> confIte = confs.iterator();
//        while(confIte.hasNext()) {
//            NeuralNetConfiguration conf = confIte.next();
//            log.info("Conf : \n" + conf.toJson());
//        }

        FineTuneConfiguration fineTuneConf = new FineTuneConfiguration.Builder()
                .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
                .updater(Updater.ADAGRAD)
                .seed(Seed)
//                                                .learningRatePolicy(LearningRatePolicy.Schedule)
//                                                .learningRateSchedule(lrSchedule)
                .learningRate(learningRate)
                .build();


        ComputationGraph transferGraph = new TransferLearning.GraphBuilder(vgg16)
                .fineTuneConfiguration(fineTuneConf)
                .setFeatureExtractor("fc2")
                .removeVertexAndConnections("predictions")
                .addLayer("predictions",
                        new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)
                                .nIn(4096)
                                .nOut(ClassNum)
                                .weightInit(WeightInit.XAVIER)
                                .activation(Activation.SOFTMAX).build(), "fc2")
                .setOutputs("predictions")
                .build();

        ComputationGraphConfiguration actualConf = transferGraph.getConfiguration();
        log.info("===================================================> Get config size ");
        log.info("" + actualConf);

        return transferGraph;
    }


    //TODO: Set input type in model creation
    public void runModel()
            throws Exception
    {
        String trainPath = "datasets/dataset6";
        String testPath = "datasets/datasettest";
        int height = 224;
        int width = 224;
        int batchSize = 16;
        int epochNum = 20;

        ComputationGraph model = createModel();

        DataNormalization normalizer = new ImagePreProcessingScaler(0, 1);

        log.info("Prepare dataset");
        ParentPathLabelGenerator trainLabelGenerator = new ParentPathLabelGenerator();
        File trainParentFile = new File(trainPath);
        FileSplit trainSplit = new FileSplit(trainParentFile, NativeImageLoader.ALLOWED_FORMATS, MjRandom);

        ImageRecordReader trainRecordReader = new ImageRecordReader(height, width, ChannelNum, trainLabelGenerator);
        trainRecordReader.initialize(trainSplit);
        DataSetIterator trainDataIter = new RecordReaderDataSetIterator(trainRecordReader, batchSize, 1, ClassNum);
        trainDataIter.setPreProcessor(normalizer);
        normalizer.fit(trainDataIter);
        DataSetIterator trainEpochIte = new MultipleEpochsIterator(epochNum, trainDataIter);


        model.fit(trainEpochIte);


        ImageTransform flipTransform = new FlipImageTransform(new Random(123));
        ImageTransform flipTransform1 = new FlipImageTransform(Seed);

        List<ImageTransform> transforms = Arrays.asList(
                new ImageTransform[]{
                        flipTransform,
                        flipTransform1,
                });

        for (ImageTransform transform: transforms) {
            trainRecordReader.initialize(trainSplit, transform);
            trainDataIter = new RecordReaderDataSetIterator(trainRecordReader, batchSize, 1, ClassNum);
            trainDataIter.setPreProcessor(normalizer);
            normalizer.fit(trainDataIter);
            trainEpochIte = new MultipleEpochsIterator(epochNum, trainDataIter);
            model.fit(trainEpochIte);
        }


        log.info("Prepare dataset");
        ParentPathLabelGenerator labelGenerator = new ParentPathLabelGenerator();
        File testParentFile = new File(testPath);
        FileSplit testSplit = new FileSplit(testParentFile, NativeImageLoader.ALLOWED_FORMATS, MjRandom);

        ImageRecordReader testRecordReader = new ImageRecordReader(height, width, ChannelNum, labelGenerator);
        testRecordReader.initialize(testSplit);
        DataSetIterator testDataIter = new RecordReaderDataSetIterator(testRecordReader, 9, 1, ClassNum);
        testDataIter.setPreProcessor(normalizer);
        normalizer.fit(testDataIter);

        DataSetIterator testEpochIte = new MultipleEpochsIterator(1, testDataIter);


        Evaluation eval = model.evaluate(testEpochIte);
        log.info("-------------> " + eval.stats());

        log.info("End of test");

    }

    public static void main(String[] args) {
        try {
            VGG16Classifier tester = new VGG16Classifier();
            tester.runModel();
        }catch(Exception e) {
            e.printStackTrace();
        }
    }
}
