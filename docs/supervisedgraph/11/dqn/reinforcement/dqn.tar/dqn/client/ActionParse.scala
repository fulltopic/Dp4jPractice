package rl.dqn.reinforcement.dqn.client

import MessageParseUtils._
import org.deeplearning4j.gym.StepReply
import rl.dqn.reinforcement.dqn.clientmdpmsg.{ActionResponse}
import org.json.{JSONArray, JSONObject}
import org.nd4j.linalg.api.ndarray.INDArray
import rl.dqn.supervised._

object ActionParse {
  type ReplyType = StepReply[INDArray]

  val pongActionFlag: Int = 1
  val chowActionFlag: Int = 2
  val kanActionFlag: Int = 4
  val reachActionFlag: Int = 32
  val ronActionFlag = Set[Int](8, 9, 10, 11, 12, 13, 15, 16)
  val canRon: Int = 2
  val canRichii: Int = 1
  val canNone: Int = 0



  def getAvailableActions(msg: String, state: Array[Int]): Array[Int] = {
    val actions = Array.fill[Int](ActionLenWoAccept)(0)

    if (msg.startsWith("<T")) {
      //for drop
      for (i <- 0 until TileNum) {
        if ((state(i) & ExtraValueFlag) > 0) {
          actions(i) = 1
        }
      }
    }

    if (msg.contains("t=")) {
      val items = getMsgItems(msg)
      val actionType = dropQuotation(items(1), "t").toInt
      if ((pongActionFlag & actionType) > 0) {
        actions(PongWoAccept) = 1
      }
      if((chowActionFlag & actionType) > 0) {
        actions(ChowWoAccept) = 1
      }
      if((kanActionFlag & actionType) > 0) {
        actions(MinKanWoAccept) = 1 //TODO: How about other kan?
      }
      if(reachActionFlag == actionType) {
        actions(REACHWoAccept) = 1
      }
      if(ronActionFlag.contains(actionType)){
        actions(RonWoAccept) = 1
        //TODO: Ron action requires an extra <N> How if I don't want reach? Just try extra <N>
      }
    }


    actions
  }

  // Maybe have to be java JSONObject to be parsed by java
  def generateJsonInfo(tile: Int, actionCandidates: Array[Int]): JSONObject = {
    val actions = new JSONArray()
    var seq = 0
    actionCandidates.foreach(a => {
      val obj = new JSONObject()
      obj.put(seq.toString, new Integer(a))
      seq += 1
      actions.put(obj)
    })
    val obj = new JSONObject()
    obj.put("tile", new Integer(tile))
    obj.put("actons", actions)

    obj
  }

  //TODO:
  //1. drop, to deal with aka and dora
  //2. chow/pong: to update the state and get the immediately drop tile
  //3. The tile / actions transferred between client and dqr
  //4. Transition of indarray in qlearningdiscrete

  def getDropTile(action: Int, state: Array[Int], rawState: Array[Int]): Int = {
    var tile = action * NumPerTile

    val tiles = for (i <- tile until tile + NumPerTile if rawState(i) > 0) yield i
    if (tiles.length == 1) {
      tile = tiles.head
    }else {
      tile = tiles.filter(c => !isAka(c)).head
    }

    tile
  }

  def parseNoopAction(): String = {
    getLogMsg("N ")
  }


//  def parseReachAction(obj: JSONObject, state: Array[Int], rawState: Array[Int], iam: Int): String = {
//    val dropAction = MsgJsonParser.getAction(obj)
//    val dropTile = getDropTile(dropAction, state, rawState)
//
//    getLogMsg("REACH who=\"" + dropTile + "\"" + " step=\"1\"")
//  }

    def generateDropActions(state: Array[Int]): Array[Int] = {
    val actions = Array.fill[Int](ActionLenWoAccept)(0)
    for (i <- 0 until TileNum) {
      if ((state(i) & ExtraValueFlag) > 0) {
        actions(i) = 1
      }
    }

    actions
  }

  def getActionJson(action: Array[Int]): JSONObject = {
    val obj = new JSONObject()
    val array = new JSONArray()
    for(i <- action.indices) {
      array.put(new Integer(i))
    }
    obj.put("actions", array)

    obj
  }

  def generateCommonActionReply(msg: String, state: Array[Int], rawState: Array[Int]): ActionResponse = {
    val tile = extractMsg(msg).split(" ").map(_.trim).apply(0).drop(1).trim.toInt
    val actions = getAvailableActions(msg, state)
    val info = getActionJson(actions)

    val reply = new StepReply[INDArray](MessageParseUtils.generateIND(state), DefaultReward, false, info)
    new ActionResponse(reply, InvalidAction, tile)
  }


  def genTermActionReply(msg: String, state: Array[Int], doraValue: Array[Int], rawState: Array[Int], iam: Int): ActionResponse = {
    msg match {
      case m if m.contains("AGARI") =>
        getAgariReply(msg, state, doraValue , iam)
      case m if m.contains("RYUUKYOKU") =>
        getRyuukyokuReply(msg, state)
      case _ =>
        println("Received unexpected terminal message " + msg)
        null
    }
  }

  def getAgariReply(msg: String, state: Array[Int], doraValue: Array[Int], iam: Int): ActionResponse = {
    val items = extractMsg(msg).split(" ").map(_.trim)
    var reward = DefaultReward

    items.foreach(item => {
      if (item.startsWith("sc")) {
        reward = item.drop("sc=\"".length).dropRight("\"".length).split(",")(iam * 2 + 1).toInt
      }
      if (item.startsWith("who")) {
        val who = item.drop("who=\"".length).dropRight("\"".length).toInt
        if (who == iam) {
          val tile = (for (i <- items.indices if items(i).contains("machi")) yield items(i).drop("machi=\"".length).dropRight("\"".length).toInt).head
          acceptTile(state, doraValue, tile)
        } //TODO: Suppose iam = 0
      }
    })

    val actions = getAvailableActions(msg, state)
    val info = generateJsonInfo(0, actions) //tile is userless
    val reply = new ReplyType(MessageParseUtils.generateIND(state), reward, true, info)
    new ActionResponse(reply, InvalidAction, 0) //tile is nonsense
  }

  def getRyuukyokuReply(msg: String, state: Array[Int]): ActionResponse = {
    val actions = getAvailableActions(msg, state)
    val info = generateJsonInfo(0, actions) //tile is userless
    val reply = new ReplyType(MessageParseUtils.generateIND(state), DefaultReward, true, info)
    new ActionResponse(reply, InvalidAction, 0) //tile is nonsense
  }

  def genDropActionReply(state: Array[Int], rawState: Array[Int]): ActionResponse = {
    val actions = generateDropActions(state)
    val info = getActionJson(actions)

    val reply = new StepReply[INDArray](MessageParseUtils.generateIND(state), DefaultReward, false, info)
    new ActionResponse(reply, InvalidAction, 0) //tile is nonsense
  }

  def genReachDropActionReply(state: Array[Int], rawState: Array[Int]): ActionResponse = {
    val info = getActionJson(generateDropActions(state))
    val reply = new StepReply[INDArray](MessageParseUtils.generateIND(state), ReachReward, false, info)

    new ActionResponse(reply, REACHWoAccept, 0, true)
  }

  def genReachMsg(state: Array[Int], rawState: Array[Int], tileAction: Int): String = {
    val dropTile = getDropTile(tileAction, state, rawState)

    getLogMsg("REACH hai=\"" + dropTile + "\"") + " | " + getLogMsg("D p=\"" + dropTile + "\"")
  }

  def genDropOnlyMsg(state: Array[Int], rawState: Array[Int], tileAction: Int): String = {
    val dropTile = getDropTile(tileAction, state, rawState)

    getLogMsg("D" + dropTile)
  }

  def genDropAfterReach(msg: String): String = {
    val content =extractMsg(msg)
    val tile = content.split(" ").map(_.trim).apply(0).drop("T".length).toInt

    getLogMsg("D" + tile)
  }

  def getNextReadyMsg(): String = {
    getLogMsg("NEXTREADY")
  }

  def genStealActionMsg(action: Int, tile: Int, state: Array[Int], rawState: Array[Int], doraValue: Array[Int]): String = {
    action match {
      case PongWoAccept => genPongActionMsg(action, tile, state, rawState, doraValue)
      case ChowWoAccept => genChowActionMsg(action, tile, state, rawState, doraValue)
      case MinKanWoAccept =>
        getLogMsg("N ")
      case AnKanWoAccept =>
        println("Received unexpected action request ")
        ""
      case KaKanWoAccept => getLogMsg("N ")
      case _ =>
        println("Received unexpected action request " + action)
        ""
    }
  }

  private[this] def genPongActionMsg(action: Int, tile: Int, state: Array[Int], rawState: Array[Int], doraValue: Array[Int]): String = {
    acceptTile(state, doraValue, tile)

    val candidate = tile / NumPerTile * NumPerTile
    val tiles = for (i <- candidate until candidate + NumPerTile if rawState(i) > 0) yield  i

    val pongTiles = Array.fill[Int](3)(0)

    if(tiles.length > 3) {
      if (isAka(tiles(3)) || tile == tiles(3)) {
        val alterIndex = (for (i <- 0 until 3 if (!isAka(tiles(i)) && tile != tiles(i))) yield i).head
        val tmp = tiles(alterIndex)
        tiles(alterIndex) = tiles(3)
        tiles(3) = tmp
      }
    }

    for (i <- 0 until 3) {
      pongTiles(i) = tiles(i)
    }

    //TODO: Remove tile from hais

    pongTiles.foreach(p => fixTile(state, p))
    pongTiles.foreach(p => updateBoard(tile, state)) // The stolen tile to be updated?

    getLogMsg("N type=\"3\" hai0=\"" + pongTiles(0) + "\" hai1=\"" + pongTiles(1) + "\"")
  }

  def ifTileExist(state: Array[Int], tile: Int): Boolean = {
    (state(tile) & ExtraValueFlag) > 0
  }

  private val chowRandom = new scala.util.Random(37)
  private[this] def genChowActionMsg(action: Int, tile: Int, state: Array[Int], rawState: Array[Int], doraValue: Array[Int]): String = {
    val acceptTile = tile / NumPerTile * NumPerTile
    val candidates = for (i <- acceptTile + 2 until acceptTile + 1 if (ifTileExist(state, i) && ifTileExist(state, i + 1) && ifTileExist(state, i + 2)))
      yield i
    val index = chowRandom.nextInt(candidates.length)

    val candidate = candidates(index)
    val tiles = for (i <- candidate until candidate + 3 if i != tile) yield i

    val tile0 = (for (i <- tiles(0) * NumPerTile until (tiles(0) + 1)* NumPerTile if rawState(i) > 0) yield  i).head
    val tile1 = (for (i <- tiles(1) * NumPerTile until (tiles(1) + 1)* NumPerTile if rawState(i) > 0) yield  i).head

    getLogMsg("N type=\"1\" hai0=\"" + tile0 + "\" hai1=\"" + tile1 + "\"")
  }

  def genAcceptReply(msg: String, state: Array[Int], rawState: Array[Int], doraValue: Array[Int]): ActionResponse = {
    if (!msg.contains("t=")) {
      genDropActionReply(state, rawState)
    }else {
      val action = getAvailableActions(msg, state)
      val info = getActionJson(action)

      val reply = new StepReply[INDArray](MessageParseUtils.generateIND(state), DefaultReward, false, info)

      new ActionResponse(reply, InvalidAction, 0, true)
    }
  }
}
