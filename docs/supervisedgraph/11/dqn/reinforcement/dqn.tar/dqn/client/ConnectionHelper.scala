package rl.dqn.reinforcement.dqn.client

class ConnectionHelper(userName: String) {
  def processMsg(msg: String): String = {
    "---------------------> Received message in connection: " + msg
  }
}


object ConnectionHelper{
//   def connect(): Boolean = true
//
//  def reconnect(): Boolean = true
//
//  def authentication(): Boolean = true
//
//  def init(): Boolean = true
//
//  def close(): Unit = println("Close the connection")
//
//  def receive(): String = ""
//
//  def send(content: String): Unit = println("To send " + content)

  private[this] val keys = Set[String]("GO", "UN", "SHUFFLE")

  def isConnMsg(msg: String): Boolean = {
    keys.foldLeft[Boolean](false)((a, key) => { a || msg.startsWith(key) })
  }

}
