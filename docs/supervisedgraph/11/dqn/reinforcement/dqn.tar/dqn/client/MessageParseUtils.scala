package rl.dqn.reinforcement.dqn.client

import org.nd4j.linalg.factory.Nd4j
import rl.dqn.supervised._

object MessageParseUtils {

  val ActionStep0: Int = 0
  val ActionStep1: Int = 1
  val ActionStep2: Int = 2
  val InvalidAction: Int = -1
  val InvalidTile: Int = -1

  private[this] val keys = Set[String]("TAIKYOKU", " INIT", "T", "D", "U", "E", "V", "F", "W", "G", "N", "RYUUKYOKU", "AGARI", "REACH", "DORA")
  private[this] val actionTitle = Map[Int, (String, String)](0 -> ("T", "D"), 1 -> ("U", "E"), 2 -> ("V", "F"), 3 -> ("W", "G"))
  private[this] val gameMsgSet = scala.collection.immutable.Set[String]("INIT", "DORA", "REACH", "AGARI", "N") //, "PROF"
  val tileKeyPattern = "[d, u, e, v, f, w, t, g, D,U,E,V,F,W,T,G][0-9]+" //efgt for get, uvwd for drop

  def isSceneKey(msg: String): Boolean = {
    keys.foldLeft[Boolean](false)((a, key) => { a || msg.startsWith(key) })
  }

  def isGameMsg(msg: String): Boolean = {
    val key = getKeyInMsg(msg)
    if (gameMsgSet.contains(key)) true
    else key.matches(tileKeyPattern)
  }

  def extractMsg(msg: String): String = {
    msg.trim.drop(1).dropRight(2).trim
  }


  def getTileTile(msg: String): Int = {
    msg.drop(1).toInt
  }

  def updateBoard(tile: Int, state: Array[Int]): Unit = {
    state(tile / NumPerTile + TileNum) += 1
  }

  def acceptTile(state: Array[Int], doraValue: Array[Int], tile: Int): Unit = {
    state(tile / NumPerTile) += 1 + doraValue(tile / NumPerTile) + AkaValues.getOrElse(tile, 0)
  }

  def dropTile(state: Array[Int], doraValue: Array[Int], tile: Int): Unit = {
    state(tile / NumPerTile) -= 1 + doraValue(tile / NumPerTile) + AkaValues.getOrElse(tile, 0)
  }

  def fixTile(state: Array[Int], tile: Int): Unit = {
    state(tile / NumPerTile) += MValue - 1
  }

  def getLogMsg(s: String): String = {
    "<%s />".format(s)
  }

  def isAka(tile: Int): Boolean = {
    AkaValues.getOrElse(tile, 0) == 0
  }

  def isReachAction(action: Int): Boolean = {
    action == ReachStep1 || action == ReachStep2
  }

  def isDropAction(action: Int): Boolean = {
    Range(0, TileNum).contains(action)
  }

  def isStealAction(action: Int): Boolean = {
    action >= ChowWoAccept && action <= RonWoAccept
  }

  def getDora(hai: Int): Int = {
    hai match {
      case tile if tile >= 0 && tile < 27 =>
        val tmp = tile / 9
        (tile + 1) % 9 + tmp * 9
      case tile if tile >= 27 && tile < 31 =>
        val tmp = tile - 27
        (tmp + 1) % 4 + 27
      case _ =>
        val tmp = hai - 31
        (hai + 1) % 3 + 31
    }
  }

  // All input hai for parsexx functions are original hai, not / 4
  def parseDora(hai: Int, state: Array[Int], doraValue: Array[Int]): Unit = {
    if (hai >= 0) {
      val doraHai = getDora(hai / NumPerTile)
      doraValue(doraHai) = DoraValue
      if (state(doraHai) > 0) {
        var tileNum = state(doraHai) & ExtraValueFlag
        tileNum += state(doraHai) / MValue // fixed
        state(doraHai) += tileNum * DoraValue
      }
    }
  }

  def getWhoFromN(msg: String): Int = {
    val content = extractMsg(msg)

    content.split(" ").map(_.trim).apply(1).drop("who=\"".length).dropRight("\"".length).toInt
  }


  def getKeyInMsg(msg: String): String = {
    msg.trim.drop(1).dropRight(2).trim.split(" ").head
  }

  def getMsgItems(msg: String): Seq[String] = {
    extractMsg(msg).split(" ").map(_.trim)
  }

  def dropQuotation(msg: String, title: String): String = {
    msg.drop((title + "=\"").length).dropRight("\"".length)
  }

  def generateIND(state: Array[Int]) = {
    val ind = Nd4j.zeros(PeerStateLen)
    for (i <- state.indices) {
      ind.putScalar(i, state(i))
    }

    ind
  }
}
