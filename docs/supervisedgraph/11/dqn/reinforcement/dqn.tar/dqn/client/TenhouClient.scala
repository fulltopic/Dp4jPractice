package rl.dqn.reinforcement.dqn.client

import java.net.{InetAddress, InetSocketAddress}
import java.util.concurrent.TimeUnit

import akka.actor.{Actor, ActorRef, Props}
import akka.event.Logging
import akka.io.UdpConnected
//import org.deeplearning4j.gym.StepReply
//import org.json.JSONObject
//import org.nd4j.linalg.api.ndarray.INDArray
//import org.nd4j.linalg.factory.Nd4j
import rl.dqn.supervised._
import rl.dqn.reinforcement.dqn.clientmdpmsg.{ActionRequest, ActionResponse, ConnReady}
import rl.dqn.reinforcement.dqn._
//import rl.dqn.reinforcement.dqn.client.MessageParseUtils._
//import rl.dqn.reinforcement.dqn.client.ActionParse

import scala.concurrent.duration.{Duration, FiniteDuration}


class TenhouClient() extends Actor{
  private[this] val log = Logging(context.system, this)
  val userName: String = TestUserName
  val props = Props(new TenhouConnection(new InetSocketAddress(TestServerIp, TestPort), this))
  private[client] val conn = context.actorOf(props, "connection")
  private[this] var mdp: ActorRef = null
  var isDone: Boolean = false
  var tourEnd: Boolean = false

  import context.dispatcher
  context.system.scheduler.schedule(Duration.create(5, TimeUnit.SECONDS), Duration.create(KASnap, TimeUnit.SECONDS), conn, MessageParser.getKAMsg())

  log.info("Tenhou client created")

  //TODO: To make dbtransition not absorb fixed tiles !!!!!! And to read transition from xml files directly !!!
  //TODO: To make dbtransition not absorb fixed tiles !!!!!! And to read transition from xml files directly !!!
  //TODO: To make dbtransition not absorb fixed tiles !!!!!! And to read transition from xml files directly !!!
  //TODO: To make dbtransition not absorb fixed tiles !!!!!! And to read transition from xml files directly !!!


  def dummy(x: Any): Unit = {
    log.info("Received unknown message " + x)
  }

  def receive = {
    // Waiting for udp connection to be ready
    case m: ConnReady =>
      log.info("Connection ready, become ready")
      conn ! MessageParser.getHeloMsg(TestUserName)
      log.info("Sent hello to server")
      context.become(auth(sender()))
    case _ => log.info("Someone sent message too early")
  }

  def auth(mx : ActorRef): Receive = {
    case msg: String if msg.contains("HELO") =>
      conn ! MessageParser.getHeloReply(msg)
      conn ! MessageParser.getPxrMsg()
    case msg: String if msg.contains("LN") =>
      conn ! MessageParser.getKAMsg()
      conn ! MessageParser.getJoinMsg()
      context.become(join(mx))
    case x: Any => dummy(x)
  }

  def join(mx: ActorRef): Receive = {
    case msg: String if msg.contains("REJOIN") =>
      conn ! MessageParser.getRejoinMsg(msg)
    case msg: String if msg.contains("GO") =>
      iam = MessageParser.getIam(msg)
      conn ! MessageParser.getGokMsg()
      conn ! ActionParse.getNextReadyMsg()
      tourEnd = false
      context.become(inGame(mx))
    case x: Any => dummy(x)
  }

  protected def inGame(mx: ActorRef): Receive = {
    case msg: String if MessageParseUtils.isGameMsg(msg) =>
      isDone = MessageParser.isTerminalMsg(msg)
      if (MessageParser.requiresAction(msg, iam)) {
        if (msg.startsWith("<T") && state(REACHWoAccept) == 1) {
          conn ! ActionParse.genDropAfterReach(msg)
        }else {
          if (msg.startsWith("<T")) {
            mdp.tell(ActionParse.genAcceptReply(msg, state, rawState, doraValue), this.self)
            context.become(inAction(mx))
          }else if (msg.contains("t")) {
            mdp.tell(ActionParse.generateCommonActionReply(msg, state, rawState), this.self)
            context.become(inAction(mx))
          }else if (msg.contains("<N") && MessageParseUtils.getWhoFromN(msg) == iam){ // the second step of steal
            mdp.tell(ActionParse.genDropActionReply(state, rawState), this.self)
            context.become(inAction(mx))
          }else if (MessageParser.isTerminalMsg(msg)) {
            mdp.tell(ActionParse.genTermActionReply(msg, state, rawState, doraValue, iam), this.self)
            context.become(inAction(mx))
          }
        }
      }else {
        // updateState
        if (msg.contains("INIT")) {
          isDone = false
        }
        reward = MessageParser.parseNoReplyMsg(msg, state, doraValue, iam)
      }
    case msg: String if msg.contains("PROF") =>
      tourEnd = true
    case msg: String if msg.contains("MYREACH") =>
      mdp.tell(ActionParse.genReachDropActionReply(state, rawState), this.self)
      context.become(inAction(mx))
    case x: Any => dummy(x)
  }


  protected  def inAction(mx: ActorRef): Receive = {
    case request: ActionRequest => {
      if (tourEnd) {
        conn ! MessageParser.getByeMsg()
        conn ! MessageParser.getJoinMsg() // To sleep?
        context.become(join(mx))
      }else if (isDone) {
        // omit action from nn
        conn ! ActionParse.getNextReadyMsg()
        context.become(inGame(mx))
      }else {
        request.action match {
          case NOOPWoAccept =>
            conn ! ActionParse.parseNoopAction()
            context.become(inGame(mx))
          case action if MessageParseUtils.isDropAction(action) =>
            if (request.isReach) {
              val msgs = ActionParse.genReachMsg(state, rawState, action).split("|").map(_.trim)
              msgs.foreach(msg => conn ! msg)
              context.become(inGame(mx))
            } else {
              conn ! ActionParse.genDropOnlyMsg(state, rawState, action)
              context.become(inGame(mx))
            }
          case action if action == REACHWoAccept =>
            this.self ! "MYREACH"
            context.become(inGame(mx))
          case action if MessageParseUtils.isStealAction(action) =>
            conn ! ActionParse.genStealActionMsg(action, request.tile, state, rawState, doraValue)
            context.become(inGame(mx))
        }
      }
    }
    case x: Any => dummy(x)
  }

}
