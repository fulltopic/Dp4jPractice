package rl.dqn.reinforcement.dqn.clientmdpmsg
import rl.dqn.reinforcement.dqn.client.ActionParse._
import rl.dqn.supervised.NOOPWoAccept

class ActionRequest(val action: Int, val tile: Int, val isReach: Boolean = false) {
}
  // The tile is the tile that received to trigger the action
