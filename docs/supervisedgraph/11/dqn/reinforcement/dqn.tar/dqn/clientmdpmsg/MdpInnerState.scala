package rl.dqn.reinforcement.dqn.clientmdpmsg

import rl.dqn.supervised._

class MdpInnerState {
  var iam: Int = 0
  val state = Array.fill[Int](PeerStateLen)(0)
  val rawState = Array.fill[Int](TileNum * NumPerTile)(0)
  var reward: Int = DefaultReward
  val doraValue = Array.fill[Int](PeerStateLen)(0)
}
