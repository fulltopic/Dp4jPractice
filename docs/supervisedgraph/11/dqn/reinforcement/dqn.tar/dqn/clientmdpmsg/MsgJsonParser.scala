package rl.dqn.reinforcement.dqn.clientmdpmsg

import org.deeplearning4j.gym.StepReply
import rl.dqn.supervised._
import org.json.{JSONArray, JSONObject}
import org.nd4j.linalg.api.ndarray.INDArray
import org.nd4j.linalg.factory.Nd4j

object MsgJsonParser {
  val dropAction = "DROP"
  val stealAction = "STEAL"
  val noopAction = "NOOP"
  val stepReplyKeyName = "stepReply"
  val actionTypeKeyName = "actionType"
  val isRequestKeyName = "isRequest"
  val actionKeyName = "action"
  val origActionKeyName = "origAction"
  val stepKeyName = "step"
  val availableActionsKeyName = "actions"


  def genHead(action: Int, isRequest: Boolean, actionType: String, step: Int): JSONObject = {
    val obj = new JSONObject()

    obj.put(actionTypeKeyName, dropAction)
    obj.put(isRequestKeyName, isRequest)
    obj.put(actionKeyName, new Integer(action))
    obj.put(stepKeyName, new Integer(step))
  }

  def genDropMsg(action: Int, isRequest: Boolean, step: Int): JSONObject = {
    val obj = genHead(action, isRequest, dropAction, step)
    obj.put(stepKeyName, 1)
  }

  def genReachStep1Request(): JSONObject = {
    genHead(REACHWoAccept, true, stealAction, 0)
  }

  private[this] def genStateIND(state: Array[Int]): INDArray = {
    val stateIND = Nd4j.zeros(PeerStateLen)
    for (i <- 0 until PeerStateLen) {
      stateIND.putScalar(i, state(i))
    }

    stateIND
  }

  private[this] def genReplyActions(actions: Array[Int]): JSONObject = {
    val obj = new JSONObject()
    val array = new JSONArray()
    for (i <- actions.indices) {
      array.put(actions(i))
    }
    obj.put(availableActionsKeyName, array)

    obj
  }

  def genStep1Response(state: Array[Int], actions: Array[Int], action: Int, reward: Int): JSONObject = {
    val stateInd = genStateIND(state)
    val replyActions = genReplyActions(actions)
    val stepReply = new StepReply[INDArray](stateInd, reward, false, replyActions)

    val obj = genHead(action, false, dropAction, 1)
    obj.put(stepReplyKeyName, stepReply)

    obj
  }

  def getAction(obj: JSONObject): Int = {
    obj.getInt(actionKeyName)
  }

  def getOrigAction(obj: JSONObject): Int = {
    obj.getInt(origActionKeyName)
  }
}
