package rl.dqn.reinforcement.dqn.mdp

import org.deeplearning4j.rl4j.space.ActionSpace
import org.nd4j.linalg.api.ndarray.INDArray
import org.nd4j.linalg.factory.Nd4j
import rl.dqn.supervised._

import scala.util.Random

class TenhouActionSpace extends ActionSpace[Int] {
  private[this] var random = new Random(47)

  override def randomAction(): Int = random.nextInt(getSize)

  override def setSeed(seed: Int): Unit = {
    random = new Random(seed)
  }

  override def encode(action: Int): INDArray = {
    val actVec = Nd4j.zeros(getSize)
    actVec.putScalar(action, 1)

    actVec
  }

  override def getSize(): Int = ActionLenWoAccept

  override def noOp(): Int = NOOPWoAccept
}
