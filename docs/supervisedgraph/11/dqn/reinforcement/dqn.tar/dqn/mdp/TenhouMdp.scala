package rl.dqn.reinforcement.dqn.mdp

import akka.actor.{ActorSystem, Props}
import akka.pattern.Patterns
import akka.util.Timeout
import org.deeplearning4j.gym.StepReply
import org.deeplearning4j.rl4j.mdp.MDP
import org.deeplearning4j.rl4j.space.{ActionSpace, ObservationSpace}
import org.nd4j.linalg.api.ndarray
import org.nd4j.linalg.api.ndarray.INDArray
import org.nd4j.linalg.factory.Nd4j
import rl.dqn.reinforcement.dqn.client.TenhouClient
import rl.dqn.reinforcement.dqn.clientmdpmsg.{ActionRequest, ActionResponse, MsgJsonParser}
import rl.dqn.supervised._
import rl.dqn.reinforcement.dqn.clientmdpmsg.MsgJsonParser._
import rl.dqn.reinforcement.dqn.client.MessageParseUtils

import scala.concurrent.{Await, Future}
import scala.concurrent.duration.Duration
import org.json.JSONObject

class TenhouMdp extends MDP[INDArray, Int, TenhouActionSpace] {
  private[this] var done = false

  val system = ActorSystem("testSystem")
  private val client = system.actorOf(Props[TenhouClient], "tenhouClient")
  println("Tenhou mdp created")


  override def getObservationSpace: ObservationSpace[INDArray] = new TenhouObservationSpace[INDArray]()

  override def getActionSpace: TenhouActionSpace = new TenhouActionSpace()

  //TODO: To send reset to client to send reset message to server
  override def reset: INDArray = {
//    done = false
//    client.reset()
    Nd4j.zeros(0)
  }

  override def close(): Unit = {
    // To send close to connection
  }


  import java.util.concurrent.TimeUnit
  var lastStep: Int = 1
  var isReach: Boolean = false
  val timeout = new Timeout(100000L, TimeUnit.SECONDS) // As infinity
  var lastTile: Int = MessageParseUtils.InvalidTile
  override def step(action: Int): StepReply[ndarray.INDArray] = {
    println("Get response in mdp")
    val request = generateRequest(action, lastTile)
    val rspFuture: Future[AnyRef] = Patterns.ask(client, request, timeout)
    val rspObj = Await.result(rspFuture, timeout.duration).asInstanceOf[ActionResponse]
    isReach = rspObj.isReach
    isDoneFlag = rspObj.reply.isDone
    lastTile = rspObj.tile

    rspObj.reply
  }

  private[this] def generateRequest(action: Int, tile: Int): ActionRequest = {
    new ActionRequest(action, 0, isReach)
  }

  var isDoneFlag: Boolean = false
  //TODO: Make client send isDone
  override def isDone: Boolean = isDoneFlag

  override def newInstance: TenhouMdp = new TenhouMdp()
}
