package rl.dqn.reinforcement

package object dqn {
  val TestPort: Int = 52222
  val TestServerIp = "localhost"
  val TestUserName: String = "test"
  val KASnap: Int = 15
}
