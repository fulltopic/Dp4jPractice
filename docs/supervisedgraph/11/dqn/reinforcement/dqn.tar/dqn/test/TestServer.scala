package rl.dqn.reinforcement.dqn.test

import java.net.InetSocketAddress

import akka.actor.{Actor, ActorRef}
import akka.event.Logging
import akka.io.{IO, Udp}
import akka.util.ByteString
import rl.dqn.reinforcement.dqn._

class TestServer extends Actor{
  val log = Logging(context.system, this)

  import context.system
  IO(Udp) ! Udp.Bind(self, new InetSocketAddress(TestServerIp, TestPort))
  log.info("Server bind tried")

  def receive = {
    case Udp.Bound(local) =>
      log.info("In receive")
      context.become(ready(sender()))
  }

  def dummy(socket: ActorRef): Unit = {
    log.info("dummy")
  }

  def ready(socket: ActorRef): Receive = {
    case Udp.Received(data, remote) =>
      val processed = "T123"
      log.info("Server reply " + data.utf8String)
      socket ! Udp.Send(ByteString(processed), remote)
    case msg: String =>
      log.info("Received a message from queue")
      dummy(socket)
    case Udp.Unbind =>
      log.info("Unbind")
      socket ! Udp.Unbind
    case Udp.Unbound =>
      log.info("unbound")
      context.stop(self)
    case _ => dummy(socket)
  }
}
