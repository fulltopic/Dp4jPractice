package rl.dqn.reinforcement.dqn.client

import MessageParseUtils._
import org.deeplearning4j.gym.StepReply
import rl.dqn.reinforcement.dqn.clientmdpmsg.{ActionResponse, MdpInnerState}
import org.json.{JSONArray, JSONObject}
import org.nd4j.linalg.api.ndarray.INDArray
import rl.dqn.supervised._

class ActionParse(innerState: MdpInnerState) {
  type ReplyType = StepReply[INDArray]

  val pongActionFlag: Int = 1
  val chowActionFlag: Int = 4
  val kanActionFlag: Int = 2
//  val kaKanActionFlag: Int = 16
  val reachActionFlag: Int = 32
//  val kitaActionFlag: Int = 32
  val ankanActionFlag: Int = 3
//  val canRon: Int = 2
//  val canRichii: Int = 1
//  val canNone: Int = 0



  def getAvailableActions(msg: String): Array[Int] = {
    val state = innerState.state

    val actions = Array.fill[Int](ActionLenWoAccept)(0)

    if (msg.startsWith("<T") && !msg.contains(" t=")) {
      //for drop
      for (i <- 0 until TileNum) {
        if ((state(i) & ExtraValueFlag) > 0) {
          actions(i) = 1
        }
      }
    }

    if (msg.contains("t=")) {
      val items = getMsgItems(msg)
      val actionType = dropQuotation(items(1), "t").toInt
      println("-----------------------------> To process actionType " + actionType)
      if ((pongActionFlag & actionType) > 0) {
        actions(PongWoAccept) = 1
      }
      if((chowActionFlag & actionType) > 0) {
        actions(ChowWoAccept) = 1
      }
      if((kanActionFlag & actionType) > 0) {
        actions(KaKanWoAccept) = 1
        // TODO: other kan?
      }


      if(MessageParseUtils.isReachIndicator(actionType)) {
        println("============================> I am in reach action")
        actions(REACHWoAccept) = 1
        innerState.inReachAction = true
      }
      if(MessageParseUtils.isRonIndicator(actionType)){
        actions(RonWoAccept) = 1
        //Ron action requires an extra <N> How if I don't want reach? Just try extra <N>
        // Ron whatever, no other choice currently
      }

      actions(NOOPWoAccept) = 1
    }


//    println("Send action: " + (for (i <- actions.indices if (actions(i) > 0)) yield  i).mkString(","))
    actions
  }

  // Maybe have to be java JSONObject to be parsed by java
//  def generateJsonInfo(tile: Int, actionCandidates: Array[Int]): JSONObject = {
//    val actions = new JSONArray()
//    var seq = 0
//    actionCandidates.foreach(a => {
//      val obj = new JSONObject()
//      obj.put(seq.toString, new Integer(a))
//      seq += 1
//      actions.put(obj)
//    })
//    val obj = new JSONObject()
//    obj.put(jsonTileKey, new Integer(tile))
//    obj.put(jsonActionKey, actions)
//
//    obj
//  }


  def getDropTile(actionTile: Int): Int = {
    val rawState = innerState.rawState

    var tile = actionTile * NumPerTile

    val tiles = for (i <- tile until tile + NumPerTile if rawState(i) > 0) yield i
    if (tiles.length == 1) {
      tile = tiles.head
    }else {
      try {
        tile = tiles.filter(c => !isAka(c)).head
      }catch {
        case e: Throwable =>
          println("Drop failed " + tile)
          println(tiles.mkString(","))
          val fTiles = tiles.filter(c => !isAka(c))
          println(fTiles.mkString(","))
          println(fTiles.length)
          println(fTiles.head)

          for(i <- rawState.indices) {
            println(i + ": " + rawState(i) + ", ")
          }
          println("")
          throw e
      }
    }

    tile
  }

  def parseNoopAction(): String = {
    getLogMsg("N ")
  }


  def generateDropActions(): Array[Int] = {
    val state = innerState.state

    val actions = Array.fill[Int](ActionLenWoAccept)(0)
    for (i <- 0 until TileNum) {
      if ((state(i) & ExtraValueFlag) > 0) {
        actions(i) = 1
      }
    }

    actions
  }

  def getActionJson(action: Array[Int]): JSONObject = {
    val obj = new JSONObject()
    val array = new JSONArray()
    for(i <- action.indices if action(i) > 0) {
      array.put(new Integer(i))
    }
    obj.put("actions", array)

    obj
  }

  //TODO: Ankan may happen at this point
  def generateMyActionReply(msg: String): ActionResponse = {
    val tile = extractMsg(msg).split(" ").map(_.trim).apply(0).drop(1).trim.toInt
    MessageParseUtils.acceptTile(innerState, tile)

    val actions = getAvailableActions(msg)
    val info = getActionJson(actions)

    val reply = new StepReply[INDArray](MessageParseUtils.generateIND(innerState), DefaultReward, false, info)
    new ActionResponse(reply, InvalidAction, tile)
  }

  def generatePeerActionReply(msg: String): ActionResponse = {
    val tile = extractMsg(msg).split(" ").map(_.trim).apply(0).drop(1).trim.toInt
    MessageParseUtils.updateBoard(tile, innerState) //TODO: Good to update in this line?

    val actions = getAvailableActions(msg)
    val info = getActionJson(actions)

    val reply = new StepReply[INDArray](MessageParseUtils.generateIND(innerState), DefaultReward, false, info)
    println("Get tile for action: " + tile)
    new ActionResponse(reply, InvalidAction, tile)
  }


  def genTermActionReply(msg: String): ActionResponse = {
    msg match {
      case m if m.contains("AGARI") =>
        getAgariReply(msg)
      case m if m.contains("RYUUKYOKU") =>
        getRyuukyokuReply(msg)
      case _ =>
        println("Received unexpected terminal message " + msg)
        null
    }
  }

  def getAgariReply(msg: String): ActionResponse = {
    val iam = innerState.iam

    val items = extractMsg(msg).split(" ").map(_.trim)
    var reward = DefaultReward

    items.foreach(item => {
      if (item.startsWith("sc")) {
        reward = item.drop("sc=\"".length).dropRight("\"".length).split(",")(iam * 2 + 1).toInt
      }
      if (item.startsWith("who")) {
        val who = item.drop("who=\"".length).dropRight("\"".length).toInt
        if (who == iam) {
          val tile = (for (i <- items.indices if items(i).contains("machi")) yield items(i).drop("machi=\"".length).dropRight("\"".length).toInt).head
          MessageParseUtils.acceptTile(innerState, tile)
        } //TODO: Suppose iam = 0
      }
    })

    val actions = getAvailableActions(msg)
//    val info = generateJsonInfo(0, actions) //tile is userless
    val info = getActionJson(actions)
    val reply = new ReplyType(MessageParseUtils.generateIND(innerState), reward, true, info)
    new ActionResponse(reply, InvalidAction, 0) //tile is nonsense
  }

  def getRyuukyokuReply(msg: String): ActionResponse = {
    val actions = getAvailableActions(msg)
    val info = getActionJson(actions) //tile is userless
    val reply = new ReplyType(MessageParseUtils.generateIND(innerState), DefaultReward, true, info)
    new ActionResponse(reply, InvalidAction, 0) //tile is nonsense
  }

  def genDropActionReply(): ActionResponse = {

    val actions = generateDropActions()
    val info = getActionJson(actions)

    val reply = new StepReply[INDArray](MessageParseUtils.generateIND(innerState), DefaultReward, false, info)
    new ActionResponse(reply, InvalidAction, 0) //tile is nonsense
  }

  def genReachDropActionReply(): ActionResponse = {
    val info = getActionJson(generateDropActions())
    val reply = new StepReply[INDArray](MessageParseUtils.generateIND(innerState), ReachReward, false, info)

    new ActionResponse(reply, REACHWoAccept, 0, true)
  }

  def genReachMsg(tileAction: Int): String = {
    val dropTile = getDropTile(tileAction)

    if(innerState.decideReach) {
      getLogMsg("REACH hai=\"" + dropTile + "\"") + " | " + getLogMsg("D p=\"" + dropTile + "\"")
    }else {
      getLogMsg("N ") + " | " + getLogMsg("D p=\"" + dropTile + "\"")
    }
  }

  def genDropOnlyMsg(tileAction: Int): String = {
    val dropTile = getDropTile(tileAction)

    getLogMsg("D p=\"" + dropTile + "\"")
  }

  def genDropAfterReach(msg: String): String = {
    val content =extractMsg(msg)
    val tile = content.split(" ").map(_.trim).apply(0).drop("T".length).toInt

    getLogMsg("D p=\"" + tile + "\"")
  }

  def getNextReadyMsg: String = getLogMsg("NEXTREADY")

  def genStealActionMsg(action: Int, tile: Int): String = {
    action match {
      case PongWoAccept => genPongActionMsg(action, tile)
      case ChowWoAccept => genChowActionMsg(action, tile)
      case MinKanWoAccept =>
        getLogMsg("N ")
      case AnKanWoAccept =>
        println("Received unexpected action request ")
        ""
      case KaKanWoAccept => getLogMsg("N ")
      case _ =>
        println("Received unexpected action request " + action)
        ""
    }
  }

  private[this] def genChowActionMsg(action: Int, tile: Int): String = {
    val rawState = innerState.rawState

    //TODO: Not to accept tile before <N who == me> received

    val acceptTile = tile / NumPerTile
    val candidates = for (i <- math.max(acceptTile - 2, 0) to math.min(acceptTile, 27 - 1 - 2) if canChow(i, acceptTile))
      yield i

    val index = chowRandom.nextInt(candidates.length)

    val candidate = candidates(index)
    //    println("Get candidate " + candidate)
    val tiles = for (i <- 1 until 3 if (i + candidate) != tile) yield candidate + i
    //    println(tiles.mkString(","))



    val tile0 = (for (i <- tiles(0) * NumPerTile until (tiles(0) + 1)* NumPerTile if rawState(i) > 0) yield  i).head
    val tile1 = (for (i <- tiles(1) * NumPerTile until (tiles(1) + 1)* NumPerTile if rawState(i) > 0) yield  i).head

    getLogMsg("N type=\"3\" hai0=\"" + tile0 + "\" hai1=\"" + tile1 + "\"")
  }

  private[this] def genPongActionMsg(action: Int, tile: Int): String = {
    val rawState = innerState.rawState

//    MessageParseUtils.acceptTile(innerState, tile)

    val candidate = tile / NumPerTile * NumPerTile
    val tiles = for (i <- candidate until candidate + NumPerTile if rawState(i) > 0) yield  i

    val pongTiles = Array.fill[Int](2)(0)
    for (i <- 0 until 2) {
      pongTiles(i) = tiles(i)
    }

    if(tiles.length > 2) {
//      if (isAka(tiles(2)) || tile == tiles(2)) {
      if (isAka(tiles(2))) {
//        val alterIndex = (for (i <- 0 until 3 if (!isAka(tiles(i)) && tile != tiles(i))) yield i).head
        val alterIndex = (for (i <- pongTiles.indices if !isAka(pongTiles(i))) yield i).head
        pongTiles(alterIndex) = tiles(2)
      }
    }

    val dropTiles = pongTiles.filter(t => t != tile)


    //TODO: Update my state after pong in N message received

//    pongTiles.foreach(p => MessageParseUtils.fixTile(innerState, p))
//    pongTiles.foreach(p => MessageParseUtils.updateBoard(tile, innerState)) // The stolen tile to be updated?

    getLogMsg("N type=\"1\" hai0=\"" + dropTiles(0) + "\" hai1=\"" + dropTiles(1) + "\"")
  }

  def ifTileExist(state: Array[Int], tile: Int): Boolean = {
    (state(tile) & ExtraValueFlag) > 0
  }

  private val chowRandom = new scala.util.Random(37)

  //TODO: Make it function in function
  private def canChow(candidate: Int, actionTile: Int): Boolean = {
    var rc: Boolean = true

    for (i <- 0 until 3) {
      if (candidate != actionTile) {
        if (innerState.state(i + candidate) <= 0) rc = false
      }
    }

    rc
  }



  def genAcceptReply(msg: String): ActionResponse = {
    val state = innerState.state

    if (!msg.contains("t=")) {
      genDropActionReply()
    }else {
      val action = getAvailableActions(msg)
      val info = getActionJson(action)

      val reply = new StepReply[INDArray](MessageParseUtils.generateIND(innerState), DefaultReward, false, info)

      new ActionResponse(reply, InvalidAction, 0, true)
    }
  }

  def genRonMsg(msg: String): String = {
    val indicator = MessageParseUtils.getRonIndicator(msg)
    val replyType = MessageParseUtils.getRonType(indicator)

    getLogMsg("N type=\"" + replyType + "\"")
  }
}
