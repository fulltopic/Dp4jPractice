package rl.dqn.reinforcement.dqn.client

import org.nd4j.linalg.factory.Nd4j
import rl.dqn.reinforcement.dqn.clientmdpmsg.MdpInnerState
import rl.dqn.supervised._

object MessageParseUtils{

  val ActionStep0: Int = 0
  val ActionStep1: Int = 1
  val ActionStep2: Int = 2
  val InvalidAction: Int = -1
  val InvalidTile: Int = -1

  private[this] val keys = Set[String]("TAIKYOKU", " INIT", "T", "D", "U", "E", "V", "F", "W", "G", "N", "RYUUKYOKU", "AGARI", "REACH", "DORA")
  private[this] val sceneKeys = Set[String]("HELO", "JOIN", "REJOIN", "UN", "LN", "GO", "PROF")
  private[this] val actionTitle = Map[Int, (String, String)](0 -> ("T", "D"), 1 -> ("U", "E"), 2 -> ("V", "F"), 3 -> ("W", "G"))
  private[this] val gameMsgSet = scala.collection.immutable.Set[String]("INIT", "DORA", "REACH", "AGARI", "N", "RYUUKYOKU") //, "PROF"
  val dropKeyPattern = "[e, f, g, E, F, G][0-9]+"
  val acceptKeyPattern = "[u, v, w, U,V,W]"
  val myAcceptPattern = "[T, t][0-9]+"
  val myDropPattern = "[D][0-9]+"
  val tileKeyPattern = "[d, u, e, v, f, w, t, g, D,U,E,V,F,W,T,G][0-9]+" //efgd for drop, uvwt for accept
  val ronActionFlags = Set[Int](8, 9, 10, 11, 12, 13, 15, 16)

  def isSceneKey(msg: String): Boolean = {
//
    if (isGameMsg(msg)) true
    else sceneKeys.foldLeft[Boolean](false)((a, key) => { a || msg.contains(key) })
  }

  def isGameMsg(msg: String): Boolean = {
    val key = getKeyInMsg(msg)
//    println("--> " + key)
    if (gameMsgSet.contains(key)) true
    else key.matches(dropKeyPattern) || key.matches(acceptKeyPattern) || key.matches(myAcceptPattern) || key.matches(myDropPattern)
  }

  def isReachIndicator(action: Int): Boolean = (action == 32)

  def isRonIndicator(action: Int): Boolean = {
    ronActionFlags.contains(action)
  }


  def extractMsg(msg: String): String = {
    msg.trim.drop(1).dropRight(2).trim
  }


  def getTileTile(msg: String): Int = {
    msg.drop(1).toInt
  }

  def updateBoard(tile: Int, innerState: MdpInnerState): Unit = {
    val state = innerState.state
    state(tile / NumPerTile + TileNum) += 1
  }

  def acceptTile(innerState: MdpInnerState, tile: Int): Unit = {
    val state = innerState.state
    val doraValue = innerState.doraValue
    val rawState = innerState.rawState

    state(tile / NumPerTile) += 1 + doraValue(tile / NumPerTile) + AkaValues.getOrElse(tile, 0)
    rawState(tile) += 1

    println("======================================> Accepted " + tile)
  }

  def dropTile(innerState: MdpInnerState, tile: Int): Unit = {
    val state = innerState.state
    val doraValue = innerState.doraValue
    val rawState = innerState.rawState

    state(tile / NumPerTile) -= 1 + doraValue(tile / NumPerTile) + AkaValues.getOrElse(tile, 0)
    rawState(tile) -= 1

    println("======================================> Dropped " + tile)
  }

  def fixTile(innerState: MdpInnerState, tile: Int): Unit = {
    val state = innerState.state

    state(tile / NumPerTile) += MValue - 1
  }

  def getLogMsg(s: String): String = {
    "<%s />".format(s)
  }

  def isAka(tile: Int): Boolean = {
    AkaValues.getOrElse(tile, 0) > 0
  }

  def isReachAction(action: Int): Boolean = {
    action == ReachStep1 || action == ReachStep2
  }

  def reached(innerState: MdpInnerState): Boolean = {
    innerState.state(PeerReachIndex) > 0
  }

  def isDropAction(action: Int): Boolean = {
    Range(0, TileNum).contains(action)
  }

  def isStealAction(action: Int): Boolean = {
    action >= ChowWoAccept && action <= RonWoAccept
  }

  def getDora(hai: Int): Int = {
    hai match {
      case tile if tile >= 0 && tile < 27 =>
        val tmp = tile / 9
        (tile + 1) % 9 + tmp * 9
      case tile if tile >= 27 && tile < 31 =>
        val tmp = tile - 27
        (tmp + 1) % 4 + 27
      case _ =>
        val tmp = hai - 31
        (hai + 1) % 3 + 31
    }
  }

  // All input hai for parsexx functions are original hai, not / 4
  def parseDora(hai: Int, innerState: MdpInnerState): Unit = {
    val state = innerState.state
    val doraValue = innerState.doraValue

    if (hai >= 0) {
      val doraHai = getDora(hai / NumPerTile)
      doraValue(doraHai) = DoraValue
      if (state(doraHai) > 0) {
        var tileNum = state(doraHai) & ExtraValueFlag
        tileNum += state(doraHai) / MValue // fixed
        state(doraHai) += tileNum * DoraValue
      }
    }
  }

  def getWhoFromN(msg: String): Int = {
    val content = extractMsg(msg)

    content.split(" ").map(_.trim).apply(1).drop("who=\"".length).dropRight("\"".length).toInt
  }


  def getKeyInMsg(msg: String): String = {
    msg.trim.drop(1).dropRight(2).trim.split(" ").head
  }

  def getMsgItems(msg: String): Seq[String] = {
    extractMsg(msg).split(" ").map(_.trim)
  }

  def dropQuotation(msg: String, title: String): String = {
    msg.drop((title + "=\"").length).dropRight("\"".length)
  }

  def generateIND(innerState: MdpInnerState) = {
    val state = innerState.state

    val ind = Nd4j.zeros(PeerStateLen)
    for (i <- state.indices) {
      ind.putScalar(i, state(i))
    }

    ind
  }

  val ronActions = Set[Int](16, 48, 64, 8, 9, 10, 11, 12, 13, 15)
  def isRonIndicator(msg: String): Boolean = {
    var isRon: Boolean = false

    if (msg.startsWith("<T") && msg.contains(" t=")) {
      val action = getRonIndicator(msg)
      println("Get ron action: " + action)

      isRon = ronActions.contains(action)
    }else {
      val items = extractMsg(msg).split(" ").map(_.trim)
      if (items.length == 2) {
        if (items(0).matches(dropKeyPattern)) {
          val actionType = items(1).drop("t=\"".length).dropRight("\"".length).toInt
          if (ronActions.contains(actionType)) {
            isRon = true
          }
        }
      }
    }

    isRon
  }

  def getRonIndicator(msg: String): Int = {
    extractMsg(msg).split(" ").map(_.trim).apply(1).drop("t=\"".length).dropRight("\"".length).toInt
  }

  def getRonType(indicator: Int): Int = {
    if (!ronActions.contains(indicator)) {
      println("!!!!!!!!!!!!!!!!!!!!!!!! Invalid ron indicator ! " + indicator)
      0
    }else {
      indicator match {
        case 16 => 7
        case 48 => 7
        case 64 => 9
        case _ => 6
      }
    }
  }
}
