package rl.dqn.reinforcement.dqn.client

import rl.dqn.supervised._
import MessageParseUtils._
import rl.dqn.reinforcement.dqn.clientmdpmsg.MdpInnerState

class MessageParser(innerState: MdpInnerState) {

  private[this] val translation_table = Array[Int](63006, 9570, 49216, 45888, 9822, 23121, 59830, 51114, 54831, 4189, 580, 5203, 42174, 59972,
  55457, 59009, 59347, 64456, 8673, 52710, 49975, 2006, 62677, 3463, 17754, 5357)


  def getHeloMsg(userName: String): String = {
    "<HELO name=\"" + userName + "\" tid=\"f0\" sx=\"M\" />"
  }

  def getHeloReply(heloMsg: String): String = {
    val items = heloMsg.split(" ").map(_.trim)
    val authMsg = items.filter(m => m.contains("auth"))(0).drop("auth=\"".length).dropRight("\"".length)
    val parts = authMsg.split("-")
    val part1 = parts(0)
    val part2 = parts(1)
//    println("getHeloReply " + part1 + ", " + part2)
//    println("-->" + ("2" + part1.drop(2)))
//    println("-->" + part1.takeRight(1))
    val tableIndex = ("2" + part1.drop(2)).toInt % (12 - part1.takeRight(1).toInt) * 2
    val a = translation_table(tableIndex) ^ BigInt(part2.take(4), 16).toInt
    val b = translation_table(tableIndex + 1) ^ BigInt(part2.takeRight(4), 16).toInt
    val postfix = ("%02X".format(a) + "%02X".format(b)).toLowerCase()

    getLogMsg("AUTH val=\"" + part1 + "-" + postfix + "\"") //TODO: What's this format?
  }

  def getPxrMsg(): String = {
    getLogMsg("PXR V=\"9\"")
  }

  def getKAMsg(): String = {
    getLogMsg("Z ")
  }

  def getJoinMsg(): String = {
    getLogMsg("JOIN t=\"0,1\"")
  }

  def getRejoinMsg(msg: String): String = {
    val joinMsg = msg.trim.drop(7).dropRight(2).trim
    getLogMsg("JOIN " + joinMsg)
  }

  def getGokMsg(): String = {
    getLogMsg("GOK")
  }

  def getNextReadyMsg(): String = {
    getLogMsg("NEXTREADY")
  }

  def getByeMsg(): String = getLogMsg("BYE ")

  def getIam(msg: String): Int = {
    val items = msg.split("<")
    val iamItem = items(2)
    if (iamItem.contains("TAIKYOKU")) {
      iamItem.drop(14).take(1).toInt
    }else {
      println("Can not get TAIKYOKU tag")
      0
    }
  }

  def isTerminalMsg(msg: String): Boolean = {
    msg.contains("AGARI") || msg.contains("RYUUKYOKU")
  }

  val tileHead = Set[String]("<F", "<E", "<G", "<f", "<e", "<g")
  def requiresAction(msg: String): Boolean = {
//    println("-------------------> Requires action: " + msg)
    val iam = innerState.iam
    msg match {
      case s if s.startsWith("<T") => true
      case s if tileHead.foldLeft[Boolean](false)((a, b) => {a || s.startsWith(b)}) && s.contains("t") => true
      case s if s.contains("INIT") => false
//        s.contains("t=")
//      case s if s.startsWith("<T") =>
//        val numS = s.trim.drop(2).dropRight(2)
//        numS.matches("[0-9]+")
      case s if isTerminalMsg(s) => true
        // TODO: N with who == me
      case s if s.startsWith("<N") && MessageParseUtils.getWhoFromN(msg) == iam => true
      case _ => false
    }
  }

  val acceptPeerPattern = "[e, f, g, E, F, G][0-9]+"
  val dropPeerPattern = "[u, v, w, U, V, W][0-9]+"
  val acceptMinePattern = "[T, t][0-9]+"
  val dropMinePattern = "[D, d][0-9]+"

  def parseNoReplyMsg(msg: String): Int = {
    val key = getKeyInMsg(msg)
    key match {
      case "INIT" => parseInitMsg(msg)
      case "REACH" => parseReachMsg(msg)
      case "N" => parseNMsg(msg)

      case k if k.split(" ").head.matches(tileKeyPattern) => parseTileMsg(key.split(" ").head)
      case _ => DefaultReward
    }
  }

  def parseReachMsg(msg: String): Int = {
    println("Processed reach message " + msg)
    val state = innerState.state

    val items = msg.split(" ").map(_.trim)
    val who = items(1).drop("who=\"".length).dropRight("\"".length).toInt

    if(who == innerState.iam) {
      println("I am reached " + who + " " + innerState.iam)
      state(PeerReachIndex) = ReachStep1
    }

    items match {
      case elems: Array[String] if elems.length == 3 =>
        // step1
        state(PeerCommonReach + who) = ReachStep1
      case elems: Array[String] if elems.length == 4 =>
        // step2
        state (PeerCommonReach + who) = ReachStep2
      case _ => println("Unexpected message " + msg)
    }
    DefaultReward //Reach had happened
  }

  def parseTileMsg(key: String): Int = {
    key match {
      case k if k.matches(dropPeerPattern) =>
        MessageParseUtils.updateBoard(getTileTile(key), innerState)
        DefaultReward
      case k if k.matches(acceptPeerPattern) => DefaultReward
      case k if k.matches(acceptMinePattern) =>
        println("-----------------------------------_>  Seemed received unexpected T message " + key)
//        MessageParseUtils.acceptTile(innerState, MessageParseUtils.getTileTile(k))
        DefaultReward
      case k if k.matches(dropMinePattern) =>
        MessageParseUtils.dropTile(innerState, MessageParseUtils.getTileTile(k))
        MessageParseUtils.updateBoard(MessageParseUtils.getTileTile(k), innerState)
        DefaultReward //Seemed impossible
      case _ =>
        println("Failed to parse tile message " + key)
        DefaultReward
    }
  }


  def parseInitMsg(msg: String): Int = {
    val state = innerState.state

    for (i <- state.indices) {
      state(i) = 0
    }

    val items = msg.trim.drop(1).dropRight(2).trim.split(" ").map(_.trim)
    val haiMsg = items(4).drop("hai=\"".length).dropRight("\"".length)
    val tiles = haiMsg.split(",").map(_.toInt)
    tiles.foreach(tile => MessageParseUtils.acceptTile(innerState, tile))

    val doraHai = items(1).drop("seed=\"".length).dropRight("\"".length).split(",").map(_.trim).map(_.toInt).apply(DoraInSeed)
    MessageParseUtils.parseDora(doraHai, innerState)

    val oya = items(3).drop("oya=\"".length).dropRight("\"".length).toInt
    if (oya == innerState.iam) {
      state(PeerOyaIndex) = 1
    }

    DefaultReward
  }

  def parseChow(m: Int) = {
    var chowTile = (m >> 10) & 63
    val r = chowTile % 3

    chowTile /= 3
    chowTile = chowTile / 7 * 9 + chowTile % 7
    chowTile *= 4

    val candidates = new Array[Int](3)
    candidates(0) = chowTile + ((m >> 3) & 3)
    candidates(1) = chowTile + 4 + ((m >> 5) & 3)
    candidates(2) = chowTile + 8 + ((m >> 7) & 3)

    val peers = new Array[Int](2)
    r match {
      case 0 =>
        chowTile = candidates(0)
        peers(0) = candidates(1)
        peers(1) = candidates(2)
      case 1 =>
        chowTile = candidates(1)
        peers(0) = candidates(0)
        peers(1) = candidates(2)
      case 2 =>
        chowTile = candidates(2)
        peers(0) = candidates(0)
        peers(1) = candidates(1)
    }

    peers.foreach(peer => MessageParseUtils.updateBoard(peer, innerState))
  }

  def parsePong(m: Int) = {
    val state = innerState.state

    var pongTile = (m >> 9) & 127
    val r = pongTile % 3
    pongTile /= 3
    pongTile *= 4
    pongTile += r

    for(i <- 0 until 2) {
     MessageParseUtils.updateBoard(pongTile, innerState)
    }
  }

  def parseKakan(m: Int) = {
    val state = innerState.state

    val unused = (m >> 5) & 3
    var kakanTile = (m >> 9) & 127

    kakanTile /= 3
    kakanTile *= 4
    kakanTile += unused

    MessageParseUtils.updateBoard(kakanTile, innerState) //Not sure
  }

  def parseAnkan(m: Int) = {
    //Seemed kakan won't be announced
  }

  def parseKita(m: Int) = {
    // Don't know how to with kita
  }

  def parseMinKan(m: Int) = {
    val state = innerState.state

    val kanTile = (m >> 8) & 255

    for (i <- 0 until NumPerTile) {
      MessageParseUtils.updateBoard(kanTile, innerState)
    }
  }

  def parseNMsg(msg: String): Int = {
    val content = extractMsg(msg)
    val items = content.split(" ").map(_.trim)
    val m = items(2).drop("m=\"".length).dropRight("\"".length).toInt

    m match {
      case value: Int if (value & ChowFlag) > 0 => parseChow(m)
      case value: Int if (value & PongFlag) > 0 => parsePong(m)
      case value: Int if (value & KakanFlag) > 0 => parseKakan(m)
      case value: Int if (value & AnkanFlag) == 0 => parseAnkan(m)
      case value: Int if (value >> KitaBits & 1) == 1 => parseKita(m)
      case _ => parseMinKan(m)
    }

    DefaultReward
  }

}
