package rl.dqn.reinforcement.dqn.client

import java.net.{InetSocketAddress}

import akka.actor.{Actor, ActorRef, Props}
import akka.event.Logging
import akka.io.UdpConnected
import rl.dqn.supervised._
import rl.dqn.reinforcement.dqn.clientmdpmsg.{ActionRequest, ActionResponse, ConnReady}
import rl.dqn.reinforcement.dqn._

import scala.concurrent.duration.{Duration, FiniteDuration}


class TenhouClient() extends Actor{
  private[this] val log = Logging(context.system, this)
  val userName: String = TestUserName
  val props = Props(new TenhouConnection(new InetSocketAddress(TestServerIp, TestPort), this))
  private[client] val conn = context.actorOf(props, "connection")
  private[this] var mdp: ActorRef = null //TODO: Assign mdp
  var tourEnd: Boolean = false
  val msgHelper = new MsgHelper()
  var isReadyFlag: Boolean = false

  val toBeInit: Boolean = false

//  import context.dispatcher
//  context.system.scheduler.schedule(Duration.create(5, TimeUnit.SECONDS), Duration.create(KASnap, TimeUnit.SECONDS), conn, msgHelper.getKAMsg())

  log.info("Tenhou client created")

  def isReady(): Boolean = isReadyFlag

  def dummy(x: Any): Unit = {
    x match {
      case msg: String if msg.contains("ISCLIENTOK?") =>
        sender().tell("NO", this.self)
      case x: AnyRef =>
        log.info("Received unknown message " + x)
    }
  }

  def receive = {
    case m: ConnReady =>
      log.info("Connection ready, become ready")
      conn ! msgHelper.getHeloMsg(TestUserName)
      log.info("Sent hello to server")
      context.become(auth(sender()))
    case x: AnyRef => dummy(x)
  }

  def slowDown(): Unit = {
    Thread.sleep(1000)
  }

  //TODO: To sleep for a while for consequent message sending
  def auth(mx : ActorRef): Receive = {
    case msg: String if msg.contains("HELO") =>
      conn ! msgHelper.getHeloReply(msg)
      slowDown()
      conn ! msgHelper.getPxrMsg()
    case msg: String if msg.contains("LN") =>
      conn ! msgHelper.getKAMsg()
      slowDown()
      conn ! msgHelper.getJoinMsg()
      context.become(join(mx))
    case x: Any => dummy("auth: " + x)
  }

  def join(mx: ActorRef): Receive = {
    case msg: String if msg.contains("REJOIN") =>
      tourEnd = false
      conn ! msgHelper.getRejoinMsg(msg)
    case msg: String if msg.contains("GO") =>
      //TODO: Parse i am from GO message
      conn ! msgHelper.getGokMsg()
      context.become(init(mx))
    case msg: String if msg.contains("UN") =>
      log.info("Received UN")
    case msg: String if msg.contains("TAIKYOKU") =>
      msgHelper.parseTaikyokuMsg(msg)
      context.become(inGame(mx))
    case x: Any => dummy("join " + x)
  }

  def init(mx: ActorRef): Receive = {
    case request: ActionRequest =>
      mdp = sender()
      conn ! msgHelper.getNextReadyMsg()
      tourEnd = false
      isReadyFlag = true
      context.become(inGame(mx))
    case msg: String if msg.contains("ISCLIENTOK?") =>
      sender().tell("YES", this.self)
    case x: AnyRef => dummy(x)
  }

  protected def inGame(mx: ActorRef): Receive = {
    case msg: String if MessageParseUtils.isGameMsg(msg) =>
      log.info("Received message to be processed: " + msg)
      if (msgHelper.requiresAction(msg)) {
        msg match {
          case s if msgHelper.isTerminalMsg(s) =>
            //TODO: Set reached after reach message of me received
            mdp.tell(msgHelper.genTermActionReply(msg), this.self)
            if (tourEnd) {
              conn ! msgHelper.getByeMsg()
              context.become(join(mx))
            }else {
              context.become(init(mx))
            }
          case s if s.startsWith("<T") =>
            if (msgHelper.isRonIndicator(s)) {
              conn ! msgHelper.genRonMsg(msg)
            }else {
              mdp ! msgHelper.generateMyActionReply(msg)
              context.become(inAction(mx))
            }
          case s if s.contains(" t=") =>
            if (msgHelper.isRonIndicator(s)) {
              conn ! msgHelper.genRonMsg(s)
              slowDown()
              conn! msgHelper.parseNoopAction()
            }else {
              mdp.tell(msgHelper.generatePeerActionReply(msg), this.self)
              context.become(inAction(mx))
            }
          case s if s.contains("<N") && MessageParseUtils.getWhoFromN(s) == msgHelper.iam() => // the second step of steal
            mdp.tell(msgHelper.genDropActionReply(), this.self)
            context.become(inAction(mx))
          case _ =>
            log.error("Received unexpected message in requireAction " + msg)
        }
      }else {
        msgHelper.parseNoReplyMsg(msg)
        if (msgHelper.reached()) {
          context.become(inReach(mx))
        }
      }
    case msg: String if msg.contains("PROF") =>
      tourEnd = true
    case msg: String if msg.contains("MYREACH") =>
      mdp.tell(msgHelper.genReachDropActionReply(), this.self)
      context.become(inAction(mx))
    case x: Any => dummy("inGame " + x)
  }

  protected def inReach(mx: ActorRef): Receive = {
    case msg: String if msgHelper.isTerminalMsg(msg) =>
      log.debug("------------------------------> I am in reach")
      mdp.tell(msgHelper.genTermActionReply(msg), this.self)
      if (tourEnd) {
        conn ! msgHelper.getByeMsg()
        context.become(join(mx))
      }else {
        context.become(init(mx))
      }
    case msg: String if msg.startsWith("<T") =>
      if (msg.contains(" t=")) {
        conn ! msgHelper.genRonMsg(msg)
        context.become(inGame(mx))
      }else {
        conn ! msgHelper.genDropAfterReach(msg)
      }
    case msg: String if MessageParseUtils.isGameMsg(msg) =>
      log.debug("Received message after reach, to ignore " + msg)
    case x: Any => dummy("inReach " + x)
  }

  protected  def inAction(mx: ActorRef): Receive = {
    case request: ActionRequest => {
      mdp = sender()
      request.action match {
        case NOOPWoAccept =>
          conn ! msgHelper.parseNoopAction()
          context.become(inGame(mx))
        case action if MessageParseUtils.isDropAction(action) =>
          //TODO: How if decides not reach?
          if (msgHelper.isInReachAction()) {
            val msgs = msgHelper.genReachMsg(action).split("\\|").map(_.trim)
//            log.info(msgs.mkString(","))
            msgs.foreach(msg => {
              conn ! msg
              slowDown()
            })
            context.become(inGame(mx))
          } else {
            conn ! msgHelper.genDropOnlyMsg(action)
            context.become(inGame(mx))
          }
        case action if action == REACHWoAccept =>
          log.info("MDP decides to reach")
          mdp.tell(msgHelper.genReachDropActionReply(), this.self)
        case action if MessageParseUtils.isStealAction(action) =>
          conn ! msgHelper.genStealActionMsg(action, request.tile)
          context.become(inGame(mx))
      }
    }
    case x: Any => dummy("inAction " + x)
  }

}
