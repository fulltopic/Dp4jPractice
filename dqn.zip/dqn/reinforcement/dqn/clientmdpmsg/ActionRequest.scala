package rl.dqn.reinforcement.dqn.clientmdpmsg

class ActionRequest(val action: Int, val tile: Int, val isReach: Boolean = false) {
}
  // The tile is the tile that received to trigger the action
