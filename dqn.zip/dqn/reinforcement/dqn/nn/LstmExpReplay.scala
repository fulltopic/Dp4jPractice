package rl.dqn.reinforcement.dqn.nn

import java.util

import org.deeplearning4j.rl4j.learning.sync.{ExpReplay, Transition}
import rl.dqn.reinforcement.dqn.config.DqnSettings

class LstmExpReplay(){
  private val transList = new java.util.ArrayList[LstmTransition](DqnSettings.ReplayBufferSize)

  def getBatch(size: Int): java.util.ArrayList[LstmTransition] = {
    transList
  }

  def getBatch: util.ArrayList[LstmTransition] = getBatch(transList.size())

  def store(transition: LstmTransition): Unit = {
    transList.add(transition)
  }

  def clear(): Unit = transList.clear()
}
