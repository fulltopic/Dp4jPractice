package rl.dqn.reinforcement.dqn.nn;

import org.deeplearning4j.gym.StepReply;
import org.deeplearning4j.rl4j.learning.Learning;
import org.deeplearning4j.rl4j.learning.sync.qlearning.QLearning;
import org.deeplearning4j.rl4j.mdp.MDP;
import org.deeplearning4j.rl4j.network.dqn.IDQN;
import org.deeplearning4j.rl4j.util.DataManager;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.primitives.Pair;
import rl.dqn.reinforcement.dqn.client.MessageParseUtils;
import rl.dqn.reinforcement.dqn.client.RewardLogger;
import rl.dqn.reinforcement.dqn.config.DqnSettings;
import rl.dqn.reinforcement.dqn.mdp.TenhouIntegerActionSpace;

import java.util.ArrayList;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class TenhouBiLstmQLDiscrete  extends TenhouSimpleDenseQLDiscrete {
    Logger logger = LoggerFactory.getLogger(TenhouBiLstmQLDiscrete.class);
    
    private LstmExpReplay replayBuffer = new LstmExpReplay();
    private TenhouLstmEpsGreedy lstmEps = null;
    private ArrayList<INDArray> inputHistory = new ArrayList<>(DqnSettings.LstmSeqCap());
    private ArrayList<INDArray> rawInputHistory = new ArrayList<>(DqnSettings.LstmSeqCap());
    private ArrayList<Integer> actionHistory = new ArrayList<>(DqnSettings.LstmSeqCap());


    public TenhouBiLstmQLDiscrete(QLearning.QLConfiguration conf, MDP<TenhouArray, Integer, TenhouIntegerActionSpace> mdp, IDQN dqn, DataManager dataManager) {
        super(conf, mdp, dqn, dataManager);

        this.egPolicy = new TenhouLstmEpsGreedy(dqn, conf.getUpdateStart(), epsilonNbStep, conf.getMinEpsilon(), this);
        this.lstmEps = new TenhouLstmEpsGreedy(dqn, conf.getUpdateStart(), epsilonNbStep, conf.getMinEpsilon(), this);

    }

    public void preEpoch() {
        super.preEpoch();
        inputHistory.clear();
        rawInputHistory.clear();
        actionHistory.clear();
    }

    public QLearning.QLStepReturn<TenhouArray>  trainStep(TenhouArray obs){
        int action;
        INDArray rawInput = getInput(obs);
        INDArray input = DqnUtils.getNNInput(rawInput);

        Double maxQ;

        if(historyInput == null) {
            historyInput = input;
            rawHistoryInput = rawInput;
        }

        rawInputHistory.add(rawInput);
        if (inputHistory.isEmpty()) {
            inputHistory.add(input);
        }



        logger.debug("inputHistory: " + inputHistory);
        logger.debug("rawInput: " + rawInputHistory);

        INDArray dqnInput = Nd4j.create(new int[]{1, 74, inputHistory.size()}, 'f');
        for (int i = 0; i < inputHistory.size(); i ++) {
            for (int k = 0; k < 74; k ++) {
                dqnInput.putScalar(new int[] {0, k, i}, inputHistory.get(i).getDouble(k));
            }
        }


        INDArray qss = getCurrentDQN().output(dqnInput);
        INDArray qs = Nd4j.create(1, 42);
        for (int i = 0; i < 42; i ++) {
            qs.putScalar(0, i, qss.getDouble(0, i, inputHistory.size() - 1));
        }
        int maxAction = Learning.getMaxAction(qs);
        maxQ = qs.getDouble(maxAction);
        action = lstmEps.nextAction(rawInput, qs);
        actionHistory.add(action);
        logger.debug("qs " + qs);
        logger.debug("maxAction " + maxAction);
        logger.debug("maxQ " + maxQ);
        logger.debug("action " + action);

        lastAction = action;
        StepReply<TenhouArray> stepReply = getMdp().step(action);
        accuReward += stepReply.getReward() * conf.getRewardFactor();
        logger.debug("The reward " + accuReward);

//        RewardLogger.writeLog("maxQ: " + maxQ);
//        RewardLogger.writeLog("reward: " + accuReward);

        INDArray rawNInput = getInput(stepReply.getObservation());
        INDArray nInput = DqnUtils.getNNInput(rawNInput);


        inputHistory.add(nInput.sub(historyInput));
//        rawInputHistory.add(rawNInput);
//        logger.debug("******************** " + inputHistory);
//        logger.debug("******************** " + rawInputHistory);

        historyInput = nInput;
        rawHistoryInput = rawNInput;
        accuReward = 0;


        return new QLStepReturn<>(maxQ, getCurrentDQN().getLatestScore(), stepReply);
    }

    protected void printShape(INDArray data, String comment) {
        logger.debug(comment);
        int[] shape = data.shape();
        logger.debug("------------------>" + shape.length);
        for (int i = 0; i < shape.length; i ++) {
            logger.debug(shape[i] + ", ");
        }
        logger.debug("\n");
    }

    protected Pair<INDArray, INDArray> setLstmTarget(ArrayList<LstmTransition> transitions) {
        logger.debug("---------------------------------------> setTarget");
        if (transitions.size() == 0) {
            throw new IllegalArgumentException("too few transitions");
        }

        int size = transitions.size();

        int[] shape = getHistoryProcessor() == null ? getMdp().getObservationSpace().getShape()
                : getHistoryProcessor().getConf().getShape();
        int[] nshape = makeShape(size, shape);
//        int[] lstmShape = makeShape(1, nshape);

        INDArray obs = Nd4j.create(nshape);
        INDArray nextObs = Nd4j.create(nshape);
        int[] actions = new int[size];
        boolean[] areTerminal = new boolean[size];

        INDArray dqnOutputAr = Nd4j.create(size, getMdp().getActionSpace().getSize());
        printShape(obs, "obs");
        printShape(nextObs, "nextObs");
        printShape(dqnOutputAr, "dqnOutputAr");


        for (int i = 0; i < size; i++) {
            LstmTransition trans = transitions.get(i);
            areTerminal[i] = trans.isTerminal();
            actions[i] = trans.action();

            dqnOutputAr.putRow(i, trans.qs());

            if (i <= 0) {
                INDArray obsArray = trans.rawInput();
                obs.putRow(i, DqnUtils.getNNInput(obsArray));

                nextObs.putRow(i, DqnUtils.getNNInput(trans.rawNextInput()));
            }else {
                LstmTransition lastTrans = transitions.get(i - 1);
                INDArray obsArray = DqnUtils.getNNInput(trans.rawInput());
                INDArray lastObsArray = DqnUtils.getNNInput(lastTrans.rawInput());
                obs.putRow(i, obsArray.sub(lastObsArray));

                INDArray nextArray = DqnUtils.getNNInput(trans.rawNextInput());
                nextObs.putRow(i, nextArray.sub(obsArray));
            }
        }

//        INDArray dqnOutputAr = dqnOutput(obs);
        INDArray dqnOutputNext = targetDqnOutput(nextObs);

        logger.debug("before dqnOutputAr " + dqnOutputAr);

        logger.debug("obs " + obs);
        logger.debug("nextObs " + nextObs);



        double[] tempQ = new double[size];
        for (int i = 0; i < size; i ++) {
            org.nd4j.linalg.primitives.Pair<Double, Integer> tempPair = MessageParseUtils.getLegalQAction(transitions.get(i).rawNextInput(), dqnOutputNext.getRow(i));
            tempQ[i] = tempPair.getFirst();
        }

//        printShape(getMaxAction, "getMaxAction");
//        printShape(tempPair.getKey(), "tempQ");

        for (int i = 0; i < size; i++) {
            double yTar = transitions.get(i).reward();
            logger.debug("reward " + yTar);
            if (!areTerminal[i]) {
                double q = tempQ[i];
                yTar += getConfiguration().getGamma() * q;
                logger.debug("q = " + q + ", yTar = " + yTar);
            }


            if(dqnOutputAr.shape().length > 2) {
                double previousV = dqnOutputAr.getDouble(i, actions[i], 0);

                double lowB = previousV - getConfiguration().getErrorClamp();
                double highB = previousV + getConfiguration().getErrorClamp();
                double clamped = Math.min(highB, Math.max(yTar, lowB));

                dqnOutputAr.putScalar(i, actions[i], 0, clamped);
            }
            else {
                double previousV = dqnOutputAr.getDouble(i, actions[i]);
                double lowB = previousV - getConfiguration().getErrorClamp();
                double highB = previousV + getConfiguration().getErrorClamp();
                double clamped = Math.min(highB, Math.max(yTar, lowB));

                dqnOutputAr.putScalar(i, actions[i], clamped);
            }
        }

//        printShape(dqnOutputAr, "dqnOutputAr");
        logger.debug("after dqnOutputAr " + dqnOutputAr);

        replayBuffer.clear();

        return new Pair<>(obs, dqnOutputAr);
    }
}
