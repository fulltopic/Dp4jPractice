package rl.dqn.reinforcement.dqn.nn.datapocess

import java.io.File
import java.util

import akka.event.slf4j.Logger
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import org.nd4j.linalg.api.ndarray.INDArray
import org.nd4j.linalg.dataset.DataSet
import org.nd4j.linalg.dataset.api.DataSetPreProcessor
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator
import org.nd4j.linalg.factory.Nd4j
import rl.dqn.supervised.{ActionLenWoAccept, PeerStateLen}

import scala.collection.mutable
import scala.concurrent.{Await, Future}
import scala.concurrent.duration.Duration
import scala.util.{Failure, Random, Success}

class TenhouBiLstmEvalIterator(xmlParentDir: String, batchSize: Int, val model: MultiLayerNetwork = null) extends  DataSetIterator {
  private val logger = Logger("TenhouBiLstmEvalIterator") 
 
  val itemRandom: Random = new Random(System.currentTimeMillis())
  private val dirs = new File(xmlParentDir).listFiles().filter(_.isDirectory).toList
  var files = List.empty[String]
  dirs.foreach(dir => {
    val dirFiles = dir.listFiles().filter(_.isFile).map(_.getAbsolutePath)
    files = files ++ dirFiles
  })
  logger.debug("Get files " + files.length)

  val seqLen: Int = 16
  private val fileOrder = Random.shuffle(files.indices.toList).toArray
  var fileIndex: Int = 0
  var doneFileNum: Int = 0
  var currentReaders = Array.empty[TenhouLstmReader]
  var toLoad: Boolean = true

  var currentData = List.empty[List[(INDArray, Int)]]

  val fileNumPerLoad: Int = 8


  override def next(): DataSet = {
    this.next(batchSize)
  }

  override def totalExamples(): Int = {
    logger.debug("----------------------------> Called totalExamples: ")
    0
  }

  override def inputColumns(): Int = {
    PeerStateLen
  }

  override def totalOutcomes(): Int = ActionLenWoAccept

  override def resetSupported(): Boolean = true

  override def asyncSupported(): Boolean = true

  override def reset(): Unit = {
    fileIndex = 0
    currentData = List.empty[List[(INDArray, Int)]]
    //TODO: Reset currentData
  }

  override def batch(): Int = batchSize

  override def numExamples(): Int = {
    logger.debug("-------------------------> Total num examples ")
    0
  }

  override def setPreProcessor(preProcessor: DataSetPreProcessor): Unit = {
    //do nothing
  }

  override def getPreProcessor: DataSetPreProcessor = null

  override def getLabels: util.List[String] = {
    //do nothing
    null
  }

  override def cursor(): Int = {
    logger.debug("-------------------------> Cursor ")
    0
  }

  override def hasNext: Boolean = {
    fileIndex < files.length
  }


  import scala.concurrent.ExecutionContext.Implicits.global
  def getLoadFuture(reader: TenhouLstmReader): Future[List[List[(INDArray, Int)]]] = Future {
    reader.getData()
  }


  protected def loadNewFile(): Unit = {
    logger.debug("-----------------------------> Load " + files.length + ", " + fileIndex)
    val fileNum = math.min(fileNumPerLoad, files.length - fileIndex)

    currentReaders = new Array[TenhouLstmReader](fileNum)
    for (i <- 0 until fileNum) {
      currentReaders(i) = new TenhouLstmReader(files(fileOrder(fileIndex)))
      fileIndex += 1
    }


    val futures = for (reader <- currentReaders) yield getLoadFuture(reader)
    var count: Int = 0

    futures.foreach(future => {
      future onComplete {
        case Success(playerData) =>
          currentData = currentData ++ playerData
          count += 1
        case Failure(_) =>
          count += 1
      }
    })

    futures.foreach(future => Await.ready(future, Duration.Inf))

    currentData = currentData.filter(data => data.nonEmpty)
    currentData = currentData.filter(data => data.length > 0)

    currentData = Random.shuffle(currentData)

    toLoad = false
    logger.debug("Get all readers loaded "  + count)
  }

  var currentScene = Array.empty[(INDArray, Int)]
  var deltas = List.empty[(INDArray, Int)]
  var stepIndex: Int = 0
  val myBatchSize: Int = 1

//  override def next(num: Int): DataSet = {
//    if (currentData.isEmpty && hasNext) {
//      loadNewFile()
//    }
//
//    if (stepIndex >= currentScene.length) {
//      currentScene = currentData.head.toArray
//      currentData = currentData.tail
//      stepIndex = 0
//      logger.debug("reset " + stepIndex + ", " + currentScene.length + ", " + currentData.length)
//    }
//    logger.debug(stepIndex + ", " + currentScene.length)
//
//    val mySeqLen = stepIndex + 1
//    val actionLen = ActionLenWoAccept
//    val input = Nd4j.create(Array[Int](myBatchSize, inputColumns(), mySeqLen), 'f')
//    val labels = Nd4j.create(Array[Int](myBatchSize, actionLen, mySeqLen), 'f')
//    var delta = currentScene(stepIndex)._1
//    if (stepIndex > 0) {
//      delta = delta.sub(currentScene(stepIndex - 1)._1)
//    }
//    val action = currentScene(stepIndex)._2
//    deltas = deltas :+ (delta, action)
//
//
//    for (i <- 0 until mySeqLen) {
//      for (k <- 0 until inputColumns()) {
//        input.putScalar(Array[Int](0, k, i), deltas(i)._1.getDouble(k))
//      }
//      labels.putScalar(Array[Int](0, deltas(i)._2, i), 1.0)
//    }
//
//    stepIndex += 1
//    //    logger.debug("update " + stepIndex)
//
//    new DataSet(input, labels)
//  }


  override def next(num: Int): DataSet = {
    if (currentData.length < num && hasNext) {
      loadNewFile()
    }

    if (stepIndex >= currentScene.length) {
      currentScene = currentData.head.toArray
      currentData = currentData.tail
      stepIndex = 0
      //      logger.debug("reset " + stepIndex + ", " + currentScene.length)
    }
    logger.debug("reset " + stepIndex + ", " + currentScene.length)

    val mySeqLen = stepIndex + 1
    val actionLen = ActionLenWoAccept
    val input = Nd4j.create(Array[Int](myBatchSize, inputColumns(), mySeqLen), 'f')
    val labels = Nd4j.create(Array[Int](myBatchSize, actionLen, mySeqLen), 'f')

    for (i <- 0 until mySeqLen) {
      //      if (i >= currentScene.length) {
      //        logger.debug("---------------------------------------------->")
      //        logger.debug(i)
      //        logger.debug(stepIndex)
      //        logger.debug(currentScene.length)
      //        logger.debug(currentData.length)
      //        logger.debug(fileIndex)
      //        logger.debug(files.length)
      //      }
      var delta = currentScene(i)._1
      if (i > 0) {
        delta = currentScene(i)._1.sub(currentScene(i - 1)._1)
      }
      val action = currentScene(i)._2
      for (k <- 0 until inputColumns()) {
        input.putScalar(Array[Int](0, k, i), delta.getDouble(k))
      }
      labels.putScalar(Array[Int](0, action, i), 1.0)
    }

    stepIndex += 1
    //    logger.debug("update " + stepIndex)

    new DataSet(input, labels)
  }
}
