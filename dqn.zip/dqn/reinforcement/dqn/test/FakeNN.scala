package rl.dqn.reinforcement.dqn.test

import org.deeplearning4j.gym.StepReply
import org.json.JSONObject
import org.nd4j.linalg.api.ndarray
import org.nd4j.linalg.api.ndarray.INDArray
import rl.dqn.reinforcement.dqn.client.MessageParseUtils
import rl.dqn.reinforcement.dqn.mdp.TenhouMdp
import rl.dqn.supervised._

import scala.io.Source
import scala.util.parsing.json.JSONArray

class FakeNN(index: Int) {
  val fileName = "/home/zf/workspaces/workspace_java/tenhoulogs/clienttest/test" + index + "a.txt"
  var lines = Source.fromFile(fileName).getLines.toList

  val mdp = new TenhouMdp()
  Thread.sleep(3000)
  var inReach: Boolean = true
  var done: Boolean = false
  var lastState: INDArray = null

  private def checkActionValidation(reply: INDArray, action: Int): Unit = {
    action match {
      case a: Int if a >= 0 && a < TileNum =>
        if ((reply.getDouble (action).asInstanceOf[Int] & ExtraValueFlag) < 0) {
          println (reply)
          throw new Exception ("Invalid drop action: " + action + reply.getDouble (action).asInstanceOf[Int] )
        }

      case a: Int if a == REACHWoAccept =>
        if (reply.getDouble (PeerReachIndex) != 0.5) {
        throw new Exception ("Invalid reach action: " + reply.getDouble (PeerReachIndex) )
      }

      case a: Int if a == ChowWoAccept || a == PongWoAccept =>
        var candidates = List.empty[Int]
        for (i <- 0 until PeerStateLen) {
          val value = reply.getDouble (i)
          if (math.floor (value) < value) {
            candidates = candidates :+ i
          }
        }
        if (candidates.length <= 0) {
          println (reply)
          throw new Exception ("No potential tile to be stolen " + action)
        }

      case a:Int if a == NOOPWoAccept => //do nothing
      case _ =>
        println ("?????????????????????????? Don't know how to check this action " + action)
    }
  }


  private def callStep(actions: List[String]): Unit = {
    try {
      println("===========================> Action head " + actions.head)
    }catch {
      case e: Throwable =>
        println("End of test")
        System.exit(0)
    }
    mdp.isDone match {
      case true =>
        lines = actions
        println("==============> Is done " + lines.head)
      case false =>
        actions match {
        case Nil => println ("End of action service")
        case line :: tail =>
          var action: Int = NOOPWoAccept
          val content = line.drop ("Send:".length).trim
          content match {
            case s: String if s.startsWith ("<D") =>
              action = MessageParseUtils.extractMsg (s).split (" ").map (_.trim).apply (1).drop ("p=\"".length).dropRight ("\"".length).toInt / NumPerTile
//              println ("Get action " + action)
              checkActionValidation(lastState, action)
              val reply = mdp.step (action)
              lastState = reply.getObservation
              done = reply.isDone
              callStep (tail)
            case s: String if s.startsWith ("<N") =>
              var nextStep: Boolean = true
              if (! s.contains("type=")) {
                action = NOOPWoAccept
              }else {
                val nType = s.trim.drop("<".length).dropRight("/>".length).trim.split(" ").apply(1).trim.drop("type=\"".length).dropRight("\"".length).toInt
                nType match {
                  case 3 => action = ChowWoAccept
                  case 1 => action = PongWoAccept
                  case 6 => nextStep = false
                  case 7 => nextStep = false
                  case 9 => nextStep = false
                  case _ =>
                    println("?????????????????????????????? How to deal with kan?")
                    action = NOOPWoAccept
                }
              }

              if (nextStep) {
                checkActionValidation(lastState, action)
                val reply = mdp.step(action)
                done = reply.isDone
                lastState = reply.getObservation
//                callStep(tail)
              }
              callStep(tail)

            case s: String if s.startsWith ("<REACH") =>
              println ("------------------> NN in reach ")
              inReach = ! inReach
              if (inReach) {
                action = MessageParseUtils.extractMsg (s).split (" ").map (_.trim).apply (1).drop ("hai=\"".length).dropRight ("\"".length).toInt / NumPerTile
                val reply = mdp.step (action)
                done = reply.isDone
                callStep (tail.tail)
              } else {
                action = REACHWoAccept
                checkActionValidation(lastState, action)
                val reply = mdp.step (action)
                lastState = reply.getObservation
                done = reply.isDone
                callStep (actions)
              }
            case _ =>
              println ("Can not parse the message " + line)
              callStep (actions)
          }
        case _ => println ("Unexpected case ")
      }
    }
  }

  def steps(): Unit = {
    while (true) {
      done = false
      lastState = mdp.reset()
      callStep(lines)
    }
  }

}
