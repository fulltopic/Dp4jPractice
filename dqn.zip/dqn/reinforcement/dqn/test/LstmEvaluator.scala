package rl.dqn.reinforcement.dqn.test

import java.io.File
import java.util

import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import org.nd4j.linalg.api.ndarray.INDArray
import org.nd4j.linalg.dataset.DataSet
import org.nd4j.linalg.dataset.api.DataSetPreProcessor
import org.nd4j.linalg.factory.Nd4j
import rl.dqn.reinforcement.dqn.nn.datapocess.TenhouLstmReader
import rl.dqn.supervised.{ActionLenWoAccept, PeerStateLen}

import scala.collection.immutable.HashMap
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}
import scala.util.{Failure, Random, Success}

class LstmEvaluator(model: MultiLayerNetwork, xmlParentDir: String) {
  val itemRandom: Random = new Random(System.currentTimeMillis())
  private val dirs = new File(xmlParentDir).listFiles().filter(_.isDirectory).toList
  var files = List.empty[String]
  dirs.foreach(dir => {
    val dirFiles = dir.listFiles().filter(_.isFile).map(_.getAbsolutePath)
    files = files ++ dirFiles
  })
  println("Get files " + files.length)

  val seqLen: Int = 16
  private val fileOrder = Random.shuffle(files.indices.toList).toArray
  var fileIndex: Int = 0
  var doneFileNum: Int = 0
  var currentReaders = Array.empty[TenhouLstmReader]
  var toLoad: Boolean = true

  var currentData = List.empty[List[(INDArray, Int)]]

  val fileNumPerLoad: Int = 8

  def inputColumns(): Int = {
    PeerStateLen
  }

  def totalOutcomes(): Int = ActionLenWoAccept


  def reset(): Unit = {
    fileIndex = 0
    currentData = List.empty[List[(INDArray, Int)]]
    currentScene = Array.empty[(INDArray, Int)]
  }

  def hasNext: Boolean = {
    fileIndex < files.length
  }


  import scala.concurrent.ExecutionContext.Implicits.global
  def getLoadFuture(reader: TenhouLstmReader): Future[List[List[(INDArray, Int)]]] = Future {
    reader.getData()
  }


  protected def loadNewFile(): Unit = {
    println("-----------------------------> Load " + files.length + ", " + fileIndex)
    val fileNum = math.min(fileNumPerLoad, files.length - fileIndex)

    currentReaders = new Array[TenhouLstmReader](fileNum)
    for (i <- 0 until fileNum) {
      currentReaders(i) = new TenhouLstmReader(files(fileOrder(fileIndex)))
      fileIndex += 1
    }


    val futures = for (reader <- currentReaders) yield getLoadFuture(reader)
    var count: Int = 0

    futures.foreach(future => {
      future onComplete {
        case Success(playerData) =>
          currentData = currentData ++ playerData
          count += 1
        case Failure(_) =>
          count += 1
      }
    })

    futures.foreach(future => Await.ready(future, Duration.Inf))

    currentData = currentData.filter(data => data.nonEmpty)

    currentData = Random.shuffle(currentData)

    toLoad = false
    println("Get all readers loaded "  + count)
  }


  val tT = scala.collection.mutable.HashMap.empty[Int, Int] // predict = 1 && label = 1
  val tF = scala.collection.mutable.HashMap.empty[Int, Int] // predict = 1 && label != 1
  val fT = scala.collection.mutable.HashMap.empty[Int, Int] // label = 1 && predict != 1, key = label
  var total: Double = 0.0

  for (i <- 0 until ActionLenWoAccept) {
    tT(i) = 0
    tF(i) = 0
    fT(i) = 0
  }


  var currentScene = Array.empty[(INDArray, Int)]
  var stepIndex: Int = 0
  val myBatchSize: Int = 1

  def next(num: Int): Unit = {
    if (currentData.length < num && hasNext) {
      loadNewFile()
    }

    if (stepIndex >= currentScene.length) {
      currentScene = currentData.head.toArray
      currentData = currentData.tail
      stepIndex = 0
      model.rnnClearPreviousState()
    }

//    val mySeqLen = stepIndex + 1
    val actionLen = ActionLenWoAccept
    val input = Nd4j.create(Array[Int](myBatchSize, inputColumns()), 'f')
//    val labels = Nd4j.create(Array[Int](myBatchSize, actionLen), 'f')
    val label = currentScene(stepIndex)._2

    var delta = currentScene(stepIndex)._1
    if (stepIndex > 0) {
      delta = currentScene(stepIndex)._1.sub(currentScene(stepIndex - 1)._1)
    }

    for (i <- 0 until inputColumns()) {
      input.putScalar(0, i, delta.getDouble(i))
    }
//    labels.putScalar(0, currentScene(stepIndex)._2, 1.0)
    val predict = model.rnnTimeStep(input)
    val action = predict.argMax(1).getDouble(0).toInt
    if (action == label) {
      tT(action) += 1
    }else {
      tF(action) += 1
      fT(label) += 1
    }

    stepIndex += 1
    total += 1
    //    println("update " + stepIndex)
  }

  def printEval(): Unit = {
    println("--------------------------> Accuracy ")
    println(tT.mkString(", "))
    println("\n--------------------------> tF ")
    println(tF.mkString(", "))
    println("\n--------------------------> fT ")
    println(fT.mkString(", "))

    println(tT.filter(item => item._2 > 0).foldLeft[Int](0)((a, b) => (a + b._2)).toDouble / total)
    println(tF.filter(item => item._2 > 0).foldLeft[Int](0)((a, b) => (a + b._2)).toDouble / total)
    println(fT.filter(item => item._2 > 0).foldLeft[Int](0)((a, b) => (a + b._2)).toDouble / total)


  }

}
