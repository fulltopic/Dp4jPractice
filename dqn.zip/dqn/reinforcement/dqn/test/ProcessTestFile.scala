package rl.dqn.reinforcement.dqn.test

import java.io.{BufferedReader, File, PrintWriter}

import scala.io.Source

object ProcessTestFile extends App {
  val fileDir = "/home/zf/workspaces/workspace_java/tenhoulogs/clienttest/"
  val fileName = "test7"
  val postName = ".txt"
  val dstFileName = fileDir + fileName + "p" + postName
  val actionFileName = fileDir + fileName + "a" + postName

  val pw = new PrintWriter(new File(dstFileName))
  for (line <- Source.fromFile(fileDir + fileName + postName).getLines) {
//    println("Process --> " + line)
    if (!line.contains("Send") && !line.contains("Get")) {

    }else {
      val index = math.max(line.indexOf("Send"), line.indexOf("Get"))
      val content = line.drop(index)
      if (content.startsWith("Get")) {
//        println(content)
//        println("The counter " + content.count(c => c == '<'))
       if (content.count(c => c == '<') > 1) {
         val cs = content.split("<").map(_.trim)
         cs.foreach(s => {
           if(s.contains(">")) {
             pw.write("Get: <" + s + "\n")
           }
         })
       }else {
         pw.write(content + "\n")
       }
      }else {
        if (!content.contains("<Z")) {
          pw.write(content + "\n")
        }
      }
    }
  }
  pw.flush()

  var recordSendMsg: Boolean = false
  val notRecordKey = Set[String]("HELO", "AUTH", "PXR", "LN", "JOIN", "GO", "UN", "TAIKYOKU", "NEXTREADY")
  val actionPw = new PrintWriter(new File(actionFileName))
  var reached: Int = 0

  for (line <- Source.fromFile(dstFileName).getLines) {
    if (line.contains("INIT")) {
      recordSendMsg = true
      reached = 0
    }
    else if (notRecordKey.foldLeft[Boolean](false)((a, b) => { a || line.contains(b)})) recordSendMsg = false
    else if (recordSendMsg) {
      if (line.contains("Send: ")) {
        if (reached < 2) {
          if (line.contains("REACH hai=")) {
            reached = 1
          }else if (line.contains("D p=") && reached == 1) {
            reached = 2
          }
          actionPw.write(line + "\n")
        }else{
          if (line.contains("<N type=\"")) {
            println(" " + line)
            val actionType = line.drop("Send: <".length).dropRight("/>".length).trim.split(" ").map(_.trim).apply(1).drop("type=\"".length).dropRight("\"".length).toInt
            if (actionType == 6 || actionType == 7 || actionType == 9) {
              actionPw.write(line + "\n")
            }
          }
        }
      }
    }
  }

  actionPw.close()

}
