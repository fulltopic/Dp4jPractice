package rl.dqn.reinforcement.dqn.test

import java.io.{File, PrintWriter}


object SupervisedLogger {
//  val rewardFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/testdqnmodels/supervised/evalstats_" + System.currentTimeMillis() + ".txt"
  val rewardFileName = "/home/ec2-user/tenhoulogs/dqntest/supervised/evalstats" + System.currentTimeMillis() + ".txt"
  val rewardWriter: PrintWriter = new PrintWriter(new File(rewardFileName))

  //  def setFileName(fileName: String): Unit = {
  //    rewardFileName = fileName + System.currentTimeMillis() + ".txt"
  //
  //    initLogger()
  //  }
  //
  //  private def initLogger(): Unit = {
  //    if (rewardWriter != null) {
  //      rewardWriter.close()
  //    }
  //
  //    rewardWriter = new PrintWriter(new File(rewardFileName))
  //  }

  def writeLog(msg: String): Unit = {
    rewardWriter.print(msg + "\n")
    rewardWriter.flush()
  }
}
