package rl.dqn.reinforcement.dqn.test

import akka.actor.{ActorSystem, Props}

object TestClient extends App {
  val system = ActorSystem("testSystem")
  val index = 7

  val server = system.actorOf(Props(new TestServer(index)), "server")

  Thread.sleep(3000)
//  val nn = new FakeNN(index)
  val nn = new RandomNN()
  nn.steps()

}
