package rl.dqn.reinforcement.dqn.test

import java.io.{File, PrintWriter}

import org.deeplearning4j.nn.api.OptimizationAlgorithm
import org.deeplearning4j.nn.conf.{NeuralNetConfiguration, Updater}
import org.deeplearning4j.nn.conf.layers.{GravesBidirectionalLSTM, GravesLSTM, RnnOutputLayer}
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import org.deeplearning4j.nn.weights.WeightInit
import org.deeplearning4j.ui.api.UIServer
import org.deeplearning4j.ui.stats.StatsListener
import org.deeplearning4j.ui.storage.InMemoryStatsStorage
import org.deeplearning4j.util.ModelSerializer
import org.nd4j.linalg.activations.Activation
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.lossfunctions.LossFunctions.LossFunction
import rl.dqn.reinforcement.dqn.nn.datapocess.{TenhouBiLstmEvalIterator, TenhouLstmIterator}
import rl.dqn.supervised.{ActionLenWoAccept, PeerStateLen}

object TestDqnInput extends App{
  var trainPath: String = ""
  var validPath: String = ""
  var modelPath: String = ""
  var logFile: PrintWriter = null;

  def initLocalPath(): Unit = {
    trainPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/train/"
    validPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/validation/"
    modelPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/model"
    logFile = new PrintWriter(new File("/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/output.txt"))
  }

  def initCloudPath(): Unit = {
    trainPath = "/home/ec2-user/tenhoulogs/xmlfiles/trainwrapper/"
    validPath = "/home/ec2-user/tenhoulogs/xmlfiles/validwrapper/"
    modelPath = "/home/ec2-user/tenhoulogs/xmlfiles/models/bilstmmodel"
    logFile = new PrintWriter(new File("/home/ec2-user/tenhoulogs/xmlfiles/output.txt"))
  }

  def testIterator(): Unit = {
    val iterator = new TenhouLstmIterator(trainPath, 16, false, createSimpleModel())

    var count: Int = 0
    while (iterator.hasNext) {
      //      println("" + count)
      count += 1
      iterator.next()
    }
  }

  def createSimpleBiModel(): MultiLayerNetwork = {
    val lstmLayerSize: Int = 256
    val tbpttLength: Int = 1

    val conf = new NeuralNetConfiguration.Builder().
      optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .iterations(1).learningRate(0.05)
      .seed(12345).regularization(true)
      .l2(0.001)
      .weightInit(WeightInit.DISTRIBUTION)
      .updater(Updater.RMSPROP)
      .list
      .layer(0, new GravesBidirectionalLSTM.Builder().nIn(PeerStateLen).nOut(lstmLayerSize).activation(Activation.TANH).build)
      //      .layer(1, new GravesLSTM.Builder().nIn(lstmLayerSize).nOut(lstmLayerSize).activation(Activation.TANH).build)
      .layer(1, new RnnOutputLayer.Builder(LossFunction.MSE).activation(Activation.SOFTMAX)        //MCXENT + softmax for classification
      .nIn(lstmLayerSize).nOut(ActionLenWoAccept).build())
      //      .layer(1, new DenseLayer.Builder().nOut(lstmLayerSize).activation(Activation.RELU).build())
      //      .layer(2, new OutputLayer.Builder(LossFunction.NEGATIVELOGLIKELIHOOD).activation(Activation.SOFTMAX)
      //        .nIn(lstmLayerSize)
      //      .nOut(ActionLenWoAccept).build)
      //      .backpropType(BackpropType.TruncatedBPTT)
      //      .tBPTTForwardLength(tbpttLength)
      //      .tBPTTBackwardLength(tbpttLength)
      .pretrain(false)
      .backprop(true).build

    //    val testProcessor: InputPreProcessor = new RnnToFeedForwardPreProcessor()
    //    val preMap = new util.HashMap(Integer, InputPreProcessor)()
    //    preMap.put(new Integer(1), testProcessor)
    //    conf.setInputPreProcessors(preMap)

    val model = new MultiLayerNetwork(conf)
    model.init()


    model
  }

  def create2LModel(): MultiLayerNetwork = {
    val lstmLayerSize: Int = 256
    val tbpttLength: Int = 1

    val conf = new NeuralNetConfiguration.Builder().
      optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .iterations(1).learningRate(0.05)
      .seed(12345).regularization(true)
      .l2(0.001)
      .weightInit(WeightInit.DISTRIBUTION)
      .updater(Updater.RMSPROP)
      .list
      .layer(0, new GravesLSTM.Builder().nIn(PeerStateLen).nOut(lstmLayerSize).activation(Activation.TANH).build)
      .layer(1, new GravesLSTM.Builder().nOut(lstmLayerSize).activation(Activation.TANH).build())
      //      .layer(1, new GravesLSTM.Builder().nIn(lstmLayerSize).nOut(lstmLayerSize).activation(Activation.TANH).build)
      .layer(2, new RnnOutputLayer.Builder(LossFunction.MSE).activation(Activation.SOFTMAX)        //MCXENT + softmax for classification
      .nIn(lstmLayerSize).nOut(ActionLenWoAccept).build())
      //      .layer(1, new DenseLayer.Builder().nOut(lstmLayerSize).activation(Activation.RELU).build())
      //      .layer(2, new OutputLayer.Builder(LossFunction.NEGATIVELOGLIKELIHOOD).activation(Activation.SOFTMAX)
      //        .nIn(lstmLayerSize)
      //      .nOut(ActionLenWoAccept).build)
      //      .backpropType(BackpropType.TruncatedBPTT)
      //      .tBPTTForwardLength(tbpttLength)
      //      .tBPTTBackwardLength(tbpttLength)
      .pretrain(false)
      .backprop(true).build

    //    val testProcessor: InputPreProcessor = new RnnToFeedForwardPreProcessor()
    //    val preMap = new util.HashMap(Integer, InputPreProcessor)()
    //    preMap.put(new Integer(1), testProcessor)
    //    conf.setInputPreProcessors(preMap)

    val model = new MultiLayerNetwork(conf)
    model.init()


    model
  }


  def createSimpleModel(): MultiLayerNetwork = {
    val lstmLayerSize: Int = 256
    val tbpttLength: Int = 1

    val conf = new NeuralNetConfiguration.Builder().
      optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .iterations(1).learningRate(0.05)
      .seed(12345).regularization(true)
      .l2(0.001)
      .dropOut(0.5)
      .weightInit(WeightInit.DISTRIBUTION)
      .updater(Updater.RMSPROP)
      .list
      .layer(0, new GravesLSTM.Builder().nIn(PeerStateLen).nOut(lstmLayerSize).activation(Activation.TANH).build)
      //      .layer(1, new GravesLSTM.Builder().nIn(lstmLayerSize).nOut(lstmLayerSize).activation(Activation.TANH).build)
      .layer(1, new RnnOutputLayer.Builder(LossFunction.MSE).activation(Activation.SOFTMAX)        //MCXENT + softmax for classification
      .nIn(lstmLayerSize).nOut(ActionLenWoAccept).build())
      //      .layer(1, new DenseLayer.Builder().nOut(lstmLayerSize).activation(Activation.RELU).build())
      //      .layer(2, new OutputLayer.Builder(LossFunction.NEGATIVELOGLIKELIHOOD).activation(Activation.SOFTMAX)
      //        .nIn(lstmLayerSize)
      //      .nOut(ActionLenWoAccept).build)
      //      .backpropType(BackpropType.TruncatedBPTT)
      //      .tBPTTForwardLength(tbpttLength)
      //      .tBPTTBackwardLength(tbpttLength)
      .pretrain(false)
      .backprop(true).build

    //    val testProcessor: InputPreProcessor = new RnnToFeedForwardPreProcessor()
    //    val preMap = new util.HashMap(Integer, InputPreProcessor)()
    //    preMap.put(new Integer(1), testProcessor)
    //    conf.setInputPreProcessors(preMap)

    val model = new MultiLayerNetwork(conf)
    model.init()


    model
  }


  def train(model: MultiLayerNetwork): Unit = {
    val uiServer = UIServer.getInstance
    val statsStorage = new InMemoryStatsStorage
    uiServer.attach(statsStorage)
    model.setListeners(new StatsListener(statsStorage))

    val batchSize = 16
    val trainIte = new TenhouLstmIterator(trainPath, batchSize)
    val validIte = new TenhouLstmIterator(validPath, batchSize)

    //Test path
    val modelFileName = modelPath + System.currentTimeMillis() + ".txt"
    ModelSerializer.writeModel(model, modelFileName, true)

    val epochNum = 8

    for (i <- 0 until epochNum) {
      trainIte.reset()
      while (trainIte.hasNext) {
        val ds = trainIte.next()
        model.fit(ds)
      }

      validIte.reset()
      val eval = model.evaluate(validIte)
      println(eval)
      logFile.write(eval + "\n")

      val modelFileName = modelPath + System.currentTimeMillis() + ".txt"
      ModelSerializer.writeModel(model, modelFileName, true)
    }


  }

  def testSavedBiModel(): Unit = {
    val testFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/minitest/"
    val modelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/bilstmmodel_bestsofar.txt"

    val model = createSimpleBiModel()
    val loadedeModel = ModelSerializer.restoreMultiLayerNetwork(modelFileName)
    val paramTable = loadedeModel.paramTable()
    model.setParamTable(paramTable)

    val testIterator = new TenhouLstmIterator(testFileName, 1, false, model)
    testIterator.reset()

    val eval = model.evaluate(testIterator)
    println(eval)
  }

  def testBiSeqIterator(): Unit = {
    val testFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/minitest/"
    val modelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/bilstmmodel_bestsofar.txt"

    val model = createSimpleBiModel()
    val loadedeModel = ModelSerializer.restoreMultiLayerNetwork(modelFileName)
    val paramTable = loadedeModel.paramTable()
    model.setParamTable(paramTable)

    val testIterator = new TenhouBiLstmEvalIterator(testFileName, 1, model)
    testIterator.reset()

    val eval = model.evaluate(testIterator)
    println(eval)
  }

  def testInput(): Unit = {
    val modelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/bilstmmodel_bestsofar.txt"

    val model = createSimpleBiModel()
    val loadedeModel = ModelSerializer.restoreMultiLayerNetwork(modelFileName)
    val paramTable = loadedeModel.paramTable()
    model.setParamTable(paramTable)

    //TODO !!!!!!!!!!!!!!!!!!!!!!!!!! Strange input !!!!!!!!!!!!!!!!!!!!
    val dataStr = "[[0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.50,  0.25,  0.25,  0.25,  0.25,  0.25,  0.50,  0.00,  0.00,  0.25,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.25,  0.00,  0.00,  0.25,  0.00,  0.00,  0.25,  0.25,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00], [0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  -0.25,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.25,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.25,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00], [0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.25,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  -0.25,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.25,  0.25,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.25,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00]]"
    val data1 = dataStr.trim.drop(1).dropRight(2).replaceAll("\\],", "\\].")
    println(data1.length)
    println(data1)
    var data2 = data1.split("\\].").map(_.trim).toList
    println(data2.length)

    var inputs = List.empty[Array[Double]]
    while (data2.nonEmpty) {
      val data = data2.head.drop(1).split(",").map(_.trim).map(_.toDouble)
      println("Get data")
      println(data.mkString(", "))
      inputs = inputs :+ data
      data2 = data2.tail
    }

    val inputArray = Nd4j.create(Array[Int](1, inputs(0).length, inputs.length), 'f')
    for (i <- 0 until inputs.length) {
      for (k <- 0 until inputs.head.length) {
        inputArray.putScalar(0, k, i, inputs(i)(k))
      }
    }

    val output = model.output(inputArray)
    println(output)
  }

  // # 3,
  def diffQs(): Unit = {
    val data1 = Array[Double](-3.85,  -5.08,  -1.89,  -3.94,  3.67,  -3.79,  -3.02,  -3.16,  -4.80,  -1.79,  -6.10,  -6.80,  1.96,  2.80,  -3.32,  -6.63,  -3.10,  -2.52,  -1.40,  -1.98,  -2.61,  -0.95,  0.74,  -0.04,  -1.29,  -1.64,  -1.93,  2.23,  3.11,  -7.97,  -4.40,  -7.35,  -7.96,  -2.97,  -22.19,  -22.12,  -22.49,  -22.25,  -22.19,  -22.10,  -22.15,  -22.38)
    val data2 = Array[Double](-3.85,  -5.08,  -1.89,  -3.94,  2.67,  -3.79,  -3.02,  -3.16,  -4.80,  -1.79,  -6.10,  -6.80,  1.96,  2.80,  -3.32,  -6.63,  -3.10,  -2.52,  -1.40,  -1.98,  -2.61,  -0.95,  0.74,  -0.04,  -1.29,  -1.64,  -1.93,  2.23,  3.11,  -7.97,  -4.40,  -7.35,  -7.96,  -2.97,  -22.19,  -22.12,  -22.49,  -22.25,  -22.19,  -22.10,  -22.15,  -22.38)

    for (i <- data1.indices) {
      if (data1(i) != data2(i)) {
        println(i + ": " + data1(i) + " --> " + data2(i))
      }
    }
  }
//  initLocalPath()
  //  initCloudPath()
//  train(create2LModel())
  //  train(create2LModel())

  //  testIterator()

  //  testSavedModel()
  //  testBiSeqIterator()

//  testInput()
  diffQs()
}
