package rl.dqn.reinforcement.dqn.test

import akka.actor.{ActorSystem, Props}
import rl.dqn.reinforcement.dqn.mdp.TenhouMdp
import rl.dqn.reinforcement.dqn._

object TestFuture extends App {
//  val server = new TestServer()
  val system = ActorSystem("testSystem")

  val server = system.actorOf(Props[TestServer], "server")
  Thread.sleep(3000)
  val testActor = system.actorOf(Props[MyActor], "myActor")
  Thread.sleep(1000)


  testActor ! "testttttt"
  Thread.sleep(100)
  testActor ! "test1"
//  testActor ! "test2"
//  Thread.sleep(100)
//  testActor ! "whoareyou"

  val mdp = new TenhouMdp()
  Thread.sleep(3000)
  mdp.step(1)
  println("End of mdp.step")
}
