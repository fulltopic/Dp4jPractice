package rl.dqn.reinforcement.dqn.test

import org.nd4j.linalg.api.ndarray.INDArray
import org.nd4j.linalg.factory.Nd4j
import rl.dqn.supervised._
import rl.dqn.reinforcement.dqn.client.MessageParseUtils

object TestReachTile extends App {
  def genIND(state: Array[Double]): INDArray = {
    val indState = Nd4j.zeros(state.length)
    for (i <- state.indices) {
      indState.putScalar(i, state(i))
    }

    indState
  }

  //10
  def test13yao_1(): Unit = {
    val tileState = Array.fill[Double](PeerStateLen)(0)
    tileState(0) = 1
    tileState(8) = 1
    tileState(9) = 1
    tileState(17) = 1
    tileState(18) = 1
    tileState(26) = 1

    tileState(27) = 1
    tileState(28) = 1
    tileState(29) = 1
    tileState(30) = 1
    tileState(31) = 1
    tileState(32) = 1
    tileState(33) = 1

    tileState(10) = 1

    MessageParseUtils.getReachDropTile(genIND(tileState))
  }

  //7, 31
  def test7Pairs_1(): Unit = {
    val tileState = Array.fill[Double](PeerStateLen)(0)
    for (i <- 0 until 6) {
      tileState(i) = 2
    }

    tileState(7) = 1
    tileState(31) = 1

    MessageParseUtils.getReachDropTile(genIND(tileState))
  }

  //7, 31
  def test7Pairs_2(): Unit = {
    val tileState = Array.fill[Double](PeerStateLen)(0)
    for (i <- 0 until 4) {
      tileState(i) = 2
    }

    tileState(8) = 2
    tileState(9) = 2

    tileState(7) = 1
    tileState(31) = 1

    MessageParseUtils.getReachDropTile(genIND(tileState))
  }

  //20, 21
  def test4Group_1(): Unit = {
    val tileState = Array.fill[Double](PeerStateLen)(0)

    for(i <- 0 until 9) tileState(i) = 1
    for(i <- 9 until 12) tileState(i) = 1
    tileState(20) = 1
    tileState(21) = 1

    MessageParseUtils.getReachDropTile(genIND(tileState))
  }

  // 0, 20, 1, 21, 2, 3
  def test4Group_2(): Unit = {
    val tileState = Array.fill[Double](PeerStateLen)(0)

    for(i <- 0 until 4) tileState(i) = 3

    tileState(20) = 1
    tileState(21) = 1

    MessageParseUtils.getReachDropTile(genIND(tileState))
  }

  // 20, 29, 21, 32, 31, 30
  def test4Group_3(): Unit = {
    val tileState = Array.fill[Double](PeerStateLen)(0)

    for(i <- 29 until 33) tileState(i) = 3

    tileState(20) = 1
    tileState(21) = 1

    MessageParseUtils.getReachDropTile(genIND(tileState))
  }

  // 0, 20, 21, 9, 7, 8
  def test4Group_4(): Unit = {
    val tileState = Array.fill[Double](PeerStateLen)(0)

    for(i <- 7 until 10) tileState(i) = 3
    tileState(0) = 3

    tileState(20) = 1
    tileState(21) = 1

    MessageParseUtils.getReachDropTile(genIND(tileState))
  }

  // 6
  def test4Group_5(): Unit = {
    val tileState = Array.fill[Double](PeerStateLen)(0)

    for(i <- 1 until 4) tileState(i) = 3
    tileState(0) = 2
    tileState(4) = 2
    tileState(6) = 1


    MessageParseUtils.getReachDropTile(genIND(tileState))
  }

  //25
  def testError_1(): Unit = {
    val tileState = Array[Double](0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 2)

    MessageParseUtils.getReachDropTile(genIND(tileState))
  }

  // 8
  def testError_2(): Unit = {
    val rawTiles = Array[Double]( 0, 0, 0, 0, 0, 0, 0, 3, 1, 0, 0, 2, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0)

    MessageParseUtils.getReachDropTile(genIND(rawTiles))
  }

  //12, 19
  def testError_3(): Unit = {
    val rawTiles = Array[Double](0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 2, 0, 2, 2, 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)

    MessageParseUtils.getReachDropTile(genIND(rawTiles))
//    println(MessageParseUtils.is7Pairs(rawTiles))
  }

  def testError_4(): Unit = {
    val rawTiles = Array[Double](0, 1, 1, 1, 2, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0)
    MessageParseUtils.getReachDropTile(genIND(rawTiles))
  }

  def testExample_1(): Unit = {
    val rawTiles = Array[Double]( 0, 0, 0, 0, 2, 0, 2, 2, 0,            0, 0, 0, 1, 0, 0, 0, 0, 0,     0, 0, 0, 0, 0, 0, 2, 1, 2, 0, 0, 0, 2, 0, 0, 0)

    MessageParseUtils.getReachDropTile(genIND(rawTiles))
  }


  def getTiles(rawTiles: Array[Double]): Array[Int] = {
    val tiles = rawTiles.map(_.toInt & ExtraValueFlag)
    println(tiles.take(TileNum).mkString(","))

    tiles.take(TileNum)
  }

  def getMaxAction(rawTiles: Array[Double], qs: Array[Double]): Unit = {
    val tiles = getTiles(rawTiles)
    val maxQs = qs.max
    val maxAction = qs.indices.filter(i => qs(i) == maxQs).head
    println("Get " + qs.length + ", " + maxQs + ", " + maxAction)

    val availableActions = tiles.indices.filter(i => tiles(i) > 0).toSet
    println("available actions: " + availableActions.mkString(", "))

    val availableQs = availableActions.map(i => (i, qs(i))).toArray
    var tQs = Double.MinValue
    var action: Int = -1
    for (i <- availableQs.indices) {
      if (availableQs(i)._2 > tQs) {
        tQs = availableQs(i)._2
        action = availableQs(i)._1
      }
    }

    println("actions " + maxAction + ", " + action)
  }

  def testGetMaxAction(): Unit = {
    val rawTiles = Array[Double](0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  27.00,  9.00,  0.00,  0.00,  18.00,  9.00,  0.00,  9.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  9.00,  18.00,  18.00,  9.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  1.00,  0.00,  0.00,  0.00,  1.00,  1.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  1.00,  1.00,  1.00,  0.00,  0.00,  1.00,  0.00,  0.00,  0.00,  1.00,  1.00,  0.00,  1.00,  0.00,  1.00,  1.00,  0.00,  1.00,  0.00,  0.00,  0.00,  0.00,  1.00,  0.00)
    val qs = Array[Double](2296.38,  3118.75,  2862.38,  2636.56,  2986.88,  3179.96,  3178.25,  3016.77,  2924.79,  3086.75,  3114.37,  2412.40,  2534.72,  2773.48,  2992.24,  3124.67,  2982.44,  3220.00,  3149.09,  2945.75,  2202.45,  3155.35,  2975.28,  3095.53,  3033.92,  3160.21,  3211.69,  2758.96,  3274.27,  2943.49,  2999.75,  2989.92,  3147.65,  3260.14,  3176.75,  3090.38,  -0.04,  -0.16,  0.05,  -0.01,  -0.13,  3214.72)
    getMaxAction(rawTiles, qs)
  }

  def testGetTiles(): Unit = {
    val rawTiles = Array[Double](0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  27.00,  9.00,  0.00,  0.00,  18.00,  9.00,  0.00,  9.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  9.00,  18.00,  18.00,  9.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  1.00,  0.00,  0.00,  0.00,  1.00,  1.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  0.00,  1.00,  1.00,  1.00,  0.00,  0.00,  1.00,  0.00,  0.00,  0.00,  1.00,  1.00,  0.00,  1.00,  0.00,  1.00,  1.00,  0.00,  1.00,  0.00,  0.00,  0.00,  0.00,  1.00,  0.00)
    getTiles(rawTiles)
  }

  def testIsRon(): Unit = {
    val msg = "<e132 t=\"9\"/>"
    println(MessageParseUtils.isRonIndicator(msg))

    val msg2 = "<E53 t=\"8\"/>"
    println(MessageParseUtils.isRonIndicator(msg2))
    println(MessageParseUtils.getRonType(MessageParseUtils.getRonIndicator(msg2)))
  }

  def testKaikyoku(): Unit = {
    val msg = "<TAIKYOKU oya=\"0\" log=\"2018081518gm-0001-0000-c44f8034\"/>"
    println(msg)
  }


//  test13yao_1()
//  test7Pairs_1()
//  test7Pairs_2()
//  test4Group_1()
  test4Group_2()
//  test4Group_3()
//  test4Group_4()
//  test4Group_5()
//  testError_1()
//  testGetMaxAction()
//  testGetTiles()
//  testIsRon()
//  testError_4()
//  testExample_1()

//  println(MessageParseUtils.isMyReachIndicator("<REACH who=\"0\" step=\"1\"/>"))
//  val tester = new java.util.ArrayList[Int](50)
//  tester.add(9)
//  tester.add(0)
//  println(tester.size())

}