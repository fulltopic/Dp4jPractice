package rl.dqn.reinforcement.dqn.test

import org.nd4j.linalg.api.ndarray.INDArray
import org.nd4j.linalg.factory.Nd4j
import rl.dqn.reinforcement.dqn.nn.datapocess.TenhouXmlFileReader
import rl.dqn.supervised._

object TestReader extends  App {
  val fileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/mjlog_pf4-20_n1/2011020416gm-00a9-0000-025480d4&tw=0.xml"
  val reader = new TenhouXmlFileReader(fileName)

  reader.readFile()

  def allzero(data: INDArray): Boolean = {
    var isAllZero = true
    for (i <- 0 until PeerStateLen) {
      if (data.getDouble(i) != 0) {
        isAllZero = false
      }
    }

    isAllZero
  }

  def countTile(data: INDArray): Int = {
    var count = 0
    for (i <- 0 until TileNum) {
      if (data.getDouble(i) != 0) {
        count += 1
      }
    }

    count
  }

  var data: INDArray = Nd4j.zeros(PeerStateLen)
  var count: Int = 0
  do {
    data = reader.getNext()._1
    count += 1
    println(data)

    println(countTile(data))
  }while(! allzero(data))

  println(count)
}
