package rl.dqn.reinforcement.dqn.test

import rl.dqn.reinforcement.dqn.client.{MessageParseUtils, MessageParser}
import rl.dqn.reinforcement.dqn.clientmdpmsg.MdpInnerState

object TestReinit extends App{
//  val innerState = new MdpInnerState()
//  val msgParser = new MessageParser(innerState)
//  val reinitMsg = "<REINIT seed=\"1,1,0,5,2,93\" ten=\"190,404,190,216\" oya=\"1\" hai=\"6,15,24,78,89,98,124\" m0=\"61919,26698\" m3=\"19935\" kawa0=\"120,110,104,13,111,96,79\" kawa1=\"135,116,113,106,11,100,132,31\" kawa2=\"122,75,133,105,45,34\" kawa3=\"36,59,7,90,72,125\"/>"
//  msgParser.parseReinitMsg(reinitMsg)
//  println(innerState.state.mkString(", "))

  val data1 = Array[Double](3.64,  -6.87,  1.91,  -0.29,  -4.11,  2.62,  2.01,  -5.85,  -1.12,  -2.87,  -7.82,  4.00,  0.86,  -1.99,  -1.47,  -2.33,  -4.33,  -5.76,  0.52,  -0.51,  -4.29,  1.36,  -0.46,  -0.63,  0.41,  -0.19,  -2.75,  -6.81,  -6.87,  -19.00,  -5.00,  -3.58,  -11.94,  0.31,  -11.30,  -11.03,  -12.93,  -12.69,  -12.61,  -12.68,  -12.67,  -12.44)
  val data2 = Array[Double](3.48,  -6.87,  1.91,  -0.29,  -4.11,  2.62,  2.01,  -5.85,  -1.12,  -2.87,  -7.82,  4.00,  0.86,  -1.99,  -1.47,  -2.33,  -4.33,  -5.76,  0.52,  -0.51,  -4.29,  1.36,  -0.46,  -0.63,  0.41,  -0.19,  -2.75,  -6.81,  -6.87,  -19.00,  -5.00,  -3.58,  -11.94,  0.31,  -11.30,  -11.03,  -12.93,  -12.69,  -12.61,  -12.68,  -12.67,  -12.44)

  for (i <- data1.indices) {
    if (data1(i) != data2(i)) {
      println("Diff " + i)
    }
  }
}
