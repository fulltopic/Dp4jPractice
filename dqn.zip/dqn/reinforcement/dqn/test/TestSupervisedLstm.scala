package rl.dqn.reinforcement.dqn.test

import java.io.{File, PrintWriter}
import java.util

import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import rl.dqn.reinforcement.dqn.nn.datapocess.{TenhouBiLstmEvalIterator, TenhouLstmIterator}
import org.deeplearning4j.nn.api.OptimizationAlgorithm
import org.deeplearning4j.nn.conf._
import org.deeplearning4j.nn.conf.layers._
import org.deeplearning4j.nn.conf.preprocessor.RnnToFeedForwardPreProcessor
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import org.deeplearning4j.nn.weights.WeightInit
import org.deeplearning4j.ui.api.UIServer
import org.deeplearning4j.ui.stats.StatsListener
import org.deeplearning4j.ui.storage.InMemoryStatsStorage
import org.deeplearning4j.util.ModelSerializer
import org.nd4j.linalg.activations.Activation
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.lossfunctions.LossFunctions.LossFunction
import rl.dqn.supervised._


object TestSupervisedLstm extends  App{
  var trainPath: String = ""
  var validPath: String = ""
  var modelPath: String = ""
  var logFile: PrintWriter = null;

  def initLocalPath(): Unit = {
    trainPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/train/"
    validPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/validation/"
    modelPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/model"
    logFile = new PrintWriter(new File("/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/output.txt"))
  }

  def initCloudPath(): Unit = {
    trainPath = "/home/ec2-user/tenhoulogs/xmlfiles/trainwrapper/"
    validPath = "/home/ec2-user/tenhoulogs/xmlfiles/validwrapper/"
    modelPath = "/home/ec2-user/tenhoulogs/xmlfiles/models/bilstmmodel"
    logFile = new PrintWriter(new File("/home/ec2-user/tenhoulogs/xmlfiles/output.txt"))
  }

  def testIterator(): Unit = {
    val iterator = new TenhouLstmIterator(trainPath, 16, false, createSimpleModel())

    var count: Int = 0
    while (iterator.hasNext) {
//      println("" + count)
      count += 1
      iterator.next()
    }
  }

  def createSimpleBiModel(): MultiLayerNetwork = {
    val lstmLayerSize: Int = 256
    val tbpttLength: Int = 1

    val conf = new NeuralNetConfiguration.Builder().
      optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .iterations(1).learningRate(0.05)
      .seed(12345).regularization(true)
      .l2(0.001)
      .weightInit(WeightInit.DISTRIBUTION)
      .updater(Updater.RMSPROP)
      .list
      .layer(0, new GravesBidirectionalLSTM.Builder().nIn(PeerStateLen).nOut(lstmLayerSize).activation(Activation.TANH).build)
//      .layer(1, new GravesLSTM.Builder().nIn(lstmLayerSize).nOut(lstmLayerSize).activation(Activation.TANH).build)
      .layer(1, new RnnOutputLayer.Builder(LossFunction.MSE).activation(Activation.SOFTMAX)        //MCXENT + softmax for classification
        .nIn(lstmLayerSize).nOut(ActionLenWoAccept).build())
//      .layer(1, new DenseLayer.Builder().nOut(lstmLayerSize).activation(Activation.RELU).build())
//      .layer(2, new OutputLayer.Builder(LossFunction.NEGATIVELOGLIKELIHOOD).activation(Activation.SOFTMAX)
//        .nIn(lstmLayerSize)
//      .nOut(ActionLenWoAccept).build)
//      .backpropType(BackpropType.TruncatedBPTT)
//      .tBPTTForwardLength(tbpttLength)
//      .tBPTTBackwardLength(tbpttLength)
      .pretrain(false)
      .backprop(true).build

//    val testProcessor: InputPreProcessor = new RnnToFeedForwardPreProcessor()
//    val preMap = new util.HashMap[Integer, InputPreProcessor]()
//    preMap.put(new Integer(1), testProcessor)
//    conf.setInputPreProcessors(preMap)

    val model = new MultiLayerNetwork(conf)
    model.init()


    model
  }

  def create2LModel(): MultiLayerNetwork = {
    val lstmLayerSize: Int = 256
    val tbpttLength: Int = 1

    val conf = new NeuralNetConfiguration.Builder().
      optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .iterations(1).learningRate(0.05)
      .seed(12345).regularization(true)
      .l2(0.001)
      .dropOut(0.5)
      .weightInit(WeightInit.DISTRIBUTION)
      .updater(Updater.RMSPROP)
      .list
      .layer(0, new GravesLSTM.Builder().nIn(PeerStateLen).nOut(lstmLayerSize).activation(Activation.TANH).build)
      .layer(1, new GravesLSTM.Builder().nOut(lstmLayerSize).activation(Activation.TANH).build())
      //      .layer(1, new GravesLSTM.Builder().nIn(lstmLayerSize).nOut(lstmLayerSize).activation(Activation.TANH).build)
      .layer(2, new RnnOutputLayer.Builder(LossFunction.MSE).activation(Activation.IDENTITY)        //MCXENT + softmax for classification
      .nIn(lstmLayerSize).nOut(ActionLenWoAccept).build())
      //      .layer(1, new DenseLayer.Builder().nOut(lstmLayerSize).activation(Activation.RELU).build())
      //      .layer(2, new OutputLayer.Builder(LossFunction.NEGATIVELOGLIKELIHOOD).activation(Activation.SOFTMAX)
      //        .nIn(lstmLayerSize)
      //      .nOut(ActionLenWoAccept).build)
      //      .backpropType(BackpropType.TruncatedBPTT)
      //      .tBPTTForwardLength(tbpttLength)
      //      .tBPTTBackwardLength(tbpttLength)
      .pretrain(false)
      .backprop(true).build

    //    val testProcessor: InputPreProcessor = new RnnToFeedForwardPreProcessor()
    //    val preMap = new util.HashMap[Integer, InputPreProcessor]()
    //    preMap.put(new Integer(1), testProcessor)
    //    conf.setInputPreProcessors(preMap)

    val model = new MultiLayerNetwork(conf)
    model.init()


    model
  }


  def createSimpleModel(): MultiLayerNetwork = {
    val lstmLayerSize: Int = 256
    val tbpttLength: Int = 1

    val conf = new NeuralNetConfiguration.Builder().
      optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .iterations(1).learningRate(0.05)
      .seed(12345).regularization(true)
      .l2(0.001)
      .dropOut(0.5)
      .weightInit(WeightInit.DISTRIBUTION)
      .updater(Updater.RMSPROP)
      .list
      .layer(0, new GravesLSTM.Builder().nIn(PeerStateLen).nOut(lstmLayerSize).activation(Activation.TANH).build)
      //      .layer(1, new GravesLSTM.Builder().nIn(lstmLayerSize).nOut(lstmLayerSize).activation(Activation.TANH).build)
      .layer(1, new RnnOutputLayer.Builder(LossFunction.MSE).activation(Activation.SOFTMAX)        //MCXENT + softmax for classification
      .nIn(lstmLayerSize).nOut(ActionLenWoAccept).build())
      //      .layer(1, new DenseLayer.Builder().nOut(lstmLayerSize).activation(Activation.RELU).build())
      //      .layer(2, new OutputLayer.Builder(LossFunction.NEGATIVELOGLIKELIHOOD).activation(Activation.SOFTMAX)
      //        .nIn(lstmLayerSize)
      //      .nOut(ActionLenWoAccept).build)
      //      .backpropType(BackpropType.TruncatedBPTT)
      //      .tBPTTForwardLength(tbpttLength)
      //      .tBPTTBackwardLength(tbpttLength)
      .pretrain(false)
      .backprop(true).build

    //    val testProcessor: InputPreProcessor = new RnnToFeedForwardPreProcessor()
    //    val preMap = new util.HashMap[Integer, InputPreProcessor]()
    //    preMap.put(new Integer(1), testProcessor)
    //    conf.setInputPreProcessors(preMap)

    val model = new MultiLayerNetwork(conf)
    model.init()


    model
  }


  def train(model: MultiLayerNetwork): Unit = {
    val uiServer = UIServer.getInstance
    val statsStorage = new InMemoryStatsStorage
    uiServer.attach(statsStorage)
    model.setListeners(new StatsListener(statsStorage))

    val batchSize = 16
    val trainIte = new TenhouLstmIterator(trainPath, batchSize)
    val validIte = new TenhouLstmIterator(validPath, batchSize)

    //Test path
    val modelFileName = modelPath + System.currentTimeMillis() + ".txt"
    ModelSerializer.writeModel(model, modelFileName, true)

    val epochNum = 8

    for (i <- 0 until epochNum) {
      trainIte.reset()
      while (trainIte.hasNext) {
        val ds = trainIte.next()
        model.fit(ds)
      }

      validIte.reset()
      val eval = model.evaluate(validIte)
      println(eval)
      logFile.write(eval + "\n")

      val modelFileName = modelPath + System.currentTimeMillis() + ".txt"
      ModelSerializer.writeModel(model, modelFileName, true)
    }


  }

  def testSavedBiModel(): Unit = {
    val testFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/minitest/"
    val modelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/bilstmmodel_bestsofar.txt"

    val model = createSimpleBiModel()
    val loadedeModel = ModelSerializer.restoreMultiLayerNetwork(modelFileName)
    val paramTable = loadedeModel.paramTable()
    model.setParamTable(paramTable)

    val testIterator = new TenhouLstmIterator(testFileName, 1, false, model)
    testIterator.reset()

    val eval = model.evaluate(testIterator)
    println(eval)
  }

  def testSavedRnnModel(): Unit = {
    val testFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/minitest/"
    val modelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/model_lstm_2layer.xml"

    val model = create2LModel()
    val loadedeModel = ModelSerializer.restoreMultiLayerNetwork(modelFileName)
    val paramTable = loadedeModel.paramTable()
    model.setParamTable(paramTable)

    val testIterator = new TenhouLstmIterator(testFileName, 1, false, model)
    testIterator.reset()

//    val dataSet = testIterator.next()
//    val features = dataSet.getFeatures
//    println(features.shape().mkString(","))
    //1, 74, 16

    val tActual = Array.fill[Int](42)(0) //actual == 1
    val tT = Array.fill[Int](42)(0) // actual == 1 && output == 1
    val fT = Array.fill[Int](42)(0) // actual != 0 && output == 1
    val ff = Array.fill[Int](42)(0) // actual == 1 && output != 1
    var count: Int = 0
    val expCount: Int = Int.MaxValue
    while (testIterator.hasNext && count < expCount) {
      model.rnnClearPreviousState()

      val dataSet = testIterator.next()
      val features = dataSet.getFeatures
      val datas = features.getRow(0)
      val actions = dataSet.getLabels().getRow(0) //42, 1
//      println(actions)
//      println(datas.shape().mkString(","))

      val inputData = Nd4j.create(Array[Int](1, 74, 1), 'f')

      for (i <- 0 until datas.shape()(1)) {
        val data = datas.getColumn(i)

        for (k <- 0 until 74) {
          inputData.putScalar(0, k, 0, data.getDouble(k, 0))
        }

        val output = model.rnnTimeStep(inputData)
        println("Output")
        println(output)

//        println("Argmax")
//        println(actions)
        val outputAction = output.argMax(1).getInt(0, 0)
        val actualAction = actions.argMax(0).getInt(0, i)
//        println(actualAction)
        println(outputAction + (if (outputAction == actualAction) "==" else "!=") + actualAction)

        if (outputAction == actualAction) {
          tT(outputAction) = tT(outputAction) + 1
          tActual(actualAction) = tActual(actualAction) + 1
//          println("match " + outputAction)
        }else if(actions.getInt(actualAction, i) > 0){
          tActual(actualAction) = tActual(actualAction) + 1
          fT(outputAction) = fT(outputAction) + 1
          ff(actualAction) = ff(actualAction) + 1
//          println("mismatch " + outputAction + ", " + actualAction)
        }
      }


      count += 1
    }

    println("Accuracy")
    for (i <- tActual.indices if tActual(i) > 0) {
      println(i + ": " + tT(i).toDouble / tActual(i).toDouble)
    }

//    val eval = model.evaluate(testIterator)
//    println(eval)
  }

  def testBiSeqIterator(): Unit = {
    val testFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/minitest/"
    val modelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/bilstmmodel_bestsofar.txt"

    val model = createSimpleBiModel()
    val loadedeModel = ModelSerializer.restoreMultiLayerNetwork(modelFileName)
    val paramTable = loadedeModel.paramTable()
    model.setParamTable(paramTable)

    val testIterator = new TenhouBiLstmEvalIterator(testFileName, 1, model)
    testIterator.reset()

    for (i <- 0 until 16) testIterator.next()

    var count: Int = 0
    while (testIterator.hasNext && count < 3) {
      val dataSet = testIterator.next()
      val features = dataSet.getFeatures
      println("features " + features)

      val output = model.output(features)
      println("output " + output)

      count += 1
    }

//    val eval = model.evaluate(testIterator)
//    println(eval)
  }

  initLocalPath()
//  initCloudPath()
//  train(create2LModel())
  train(create2LModel())

//  testIterator()

//  testSavedModel()
//  testBiSeqIterator()
//  testSavedRnnModel
}
