package rl.dqn.reinforcement.dqn.test

object TestSupervisedLstm2 extends App{
  TestSupervisedLstm.initLocalPath()
  TestSupervisedLstm.testSavedRnnModel
}
