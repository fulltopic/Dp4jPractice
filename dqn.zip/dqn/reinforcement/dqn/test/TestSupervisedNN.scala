package rl.dqn.reinforcement.dqn.test

import java.io.{File, FileOutputStream, PrintWriter}

import org.deeplearning4j.datasets.fetchers.BaseDataFetcher
import org.deeplearning4j.datasets.iterator.BaseDatasetIterator
import org.deeplearning4j.nn.api.OptimizationAlgorithm
import org.deeplearning4j.nn.conf.inputs.InputType
import org.deeplearning4j.nn.conf.{LearningRatePolicy, NeuralNetConfiguration, Updater, WorkspaceMode}
import org.deeplearning4j.nn.conf.layers._
import org.deeplearning4j.nn.multilayer.MultiLayerNetwork
import org.deeplearning4j.nn.weights.WeightInit
import org.deeplearning4j.ui.api.UIServer
import org.deeplearning4j.ui.stats.StatsListener
import org.deeplearning4j.ui.storage.InMemoryStatsStorage
import org.deeplearning4j.util.ModelSerializer
import org.nd4j.linalg.activations.Activation
import org.nd4j.linalg.factory.Nd4j
import org.nd4j.linalg.lossfunctions.LossFunctions
import rl.dqn.reinforcement.dqn.nn.datapocess.{TenhouXmlCnnFetcher, TenhouXmlFectcher}
import rl.dqn.supervised.{ActionLenWoAccept, PeerStateLen, TileNum}

import scala.util.Random

object TestSupervisedNN  {
  def getRandomParam[T](params: Array[T]): T = {
    params(Random.nextInt(params.length))
  }

  def generateParams(): (Int, Int, Int, Double, Activation, LossFunctions.LossFunction) = {
    val hiddenNodes = Array[Int](64, 128, 256, 512)
    val denseLayerNums = Array[Int](1, 2, 3)
    val lstmSizes = Array[Int](64, 128, 256, 512)
    val startLr = Array[Double](10.0, 8.0, 5.0, 1.0)
    val lastDnnActivations = Array[Activation](Activation.RELU, Activation.TANH, Activation.SOFTSIGN)
    val outputLossFunc = Array[LossFunctions.LossFunction](LossFunctions.LossFunction.MCXENT, LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD)

    (getRandomParam(hiddenNodes), getRandomParam(denseLayerNums), getRandomParam(lstmSizes), getRandomParam(startLr), getRandomParam(lastDnnActivations), getRandomParam(outputLossFunc))
  }


  def createModel(): MultiLayerNetwork = {
    val hiddenNode: Int = 128
    val denseLayerNum: Int = 1
    val startLr: Double = 20
    val lossFunc = LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD

    println("" + hiddenNode + ", " + denseLayerNum + ", " + startLr  + ", " + lossFunc)

    val lrShedule: java.util.Map[Integer, java.lang.Double] = new java.util.HashMap[Integer, java.lang.Double]()
    lrShedule.put(0, startLr)
//    lrShedule.put(20, startLr / 2)
//    lrShedule.put(230, 0.1)
//    lrShedule.put(230, 1.0)

    val listBuilder = new NeuralNetConfiguration.Builder()
      .learningRateDecayPolicy(LearningRatePolicy.Schedule)
      .learningRateSchedule(lrShedule)
//      .learningRate(startLr)
      .iterations(1)
      .seed(47)
      .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .updater(Updater.ADAGRAD)
      .weightInit(WeightInit.XAVIER)
      .regularization(true)
      .l2(0.0005)
      .list()

    listBuilder.layer(0, new DenseLayer.Builder().nIn(PeerStateLen).nOut(hiddenNode).activation(Activation.RELU).build())
    listBuilder.layer(1, new DenseLayer.Builder().nOut(hiddenNode).activation(Activation.RELU).build())
    listBuilder.layer(2, new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD).nOut(ActionLenWoAccept).activation(Activation.SOFTMAX).build())



    val mlnConf = listBuilder.pretrain(false).backprop(true).build
    mlnConf.setTrainingWorkspaceMode(WorkspaceMode.SEPARATE)
    val model = new MultiLayerNetwork(mlnConf)
    model.init()

    model
  }

  var trainPath: String = ""
  var validPath: String = ""
  var modelPath: String = ""
  var logFile: PrintWriter = null;

  def initLocalPath(): Unit = {
    trainPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/train/"
    validPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/validation/"
    modelPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/nnmodel"
    logFile = new PrintWriter(new File("/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/output.txt"))
  }

  def initCloudPath(): Unit = {
    trainPath = "/home/ec2-user/tenhoulogs/xmlfiles/trainwrapper/"
    validPath = "/home/ec2-user/tenhoulogs/xmlfiles/validwrapper/"
    modelPath = "/home/ec2-user/tenhoulogs/xmlfiles/models/"
    logFile = new PrintWriter(new File("/home/ec2-user/tenhoulogs/xmlfiles/output.txt"))
  }


  def writeLog(content: String): Unit = {
    logFile.write(content + "\n")
    logFile.flush()
  }

  def train(model: MultiLayerNetwork, trainFetcher: BaseDataFetcher, validFetcher: BaseDataFetcher): Unit = {
    Nd4j.zeros(2)
    println("----------------------------------------> " + trainPath)
    println("----------------------------------------> " + validPath)

    val batchSize = 64
    val numExamples = 1
    val epochNum: Int = 32

//    val trainFetcher = new TenhouXmlFectcher(trainPath, toRandom)
    val trainIte = new BaseDatasetIterator(batchSize, numExamples, trainFetcher)

//    val validFetcher = new TenhouXmlFectcher(validPath, toRandom)
    val validIte = new BaseDatasetIterator(batchSize, numExamples, validFetcher)


//    val model = createModel()

    val uiServer = UIServer.getInstance
    val statsStorage = new InMemoryStatsStorage
    uiServer.attach(statsStorage)
    model.setListeners(new StatsListener(statsStorage))

    for (i <- 0 until epochNum) {
      trainIte.reset()
      model.fit(trainIte)

      validIte.reset()
      val eval = model.evaluate(validIte)
      //      val eval = new Evaluation()
      //      model.doEvaluation(validIte, eval)


      val stat = eval.stats()
      writeLog("=========================================> Evaluation")
      writeLog(stat)
      println(stat)

      val MJModelFile = new File(modelPath + "_" + System.currentTimeMillis() + ".xml")
      val fos = new FileOutputStream(MJModelFile)
      ModelSerializer.writeModel(model, fos, true)
    }

    writeLog("::::::::::::::::::::::::::::::::::::::::: End of training")
  }

  def testSavedModel(): Unit = {
    val testFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/smalltest/"
    val modelFileName = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/nnmodel_1533105293833.xml"

    val model = createModel()
    val loadedModel = ModelSerializer.restoreMultiLayerNetwork(modelFileName)
    val paramTable = loadedModel.paramTable()
    model.setParamTable(paramTable)

    val testFetcher = new TenhouXmlCnnFetcher(testFileName, TileNum)
    val testIterator = new BaseDatasetIterator(64, 1, testFetcher)
    testIterator.reset()

    val eval = model.evaluate(testIterator)
    println(eval)
  }

  def main(args: Array[String]): Unit = {
    initLocalPath()
//      initCloudPath()
//    val outputLen: Int = 8
//    val trainFetcher = new TenhouXmlCnnFetcher(trainPath, TileNum)
//    val validFetcher = new TenhouXmlCnnFetcher(validPath, TileNum)
//    train(createModel(), trainFetcher, validFetcher)
    testSavedModel()
  }
}
