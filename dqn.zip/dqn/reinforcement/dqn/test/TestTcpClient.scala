package rl.dqn.reinforcement.dqn.test

import akka.actor.{ActorSystem, Props}
import org.nd4j.linalg.factory.Nd4j
import rl.dqn.reinforcement.dqn.client.MessageParseUtils.{getLogMsg, isAka}
import rl.dqn.reinforcement.dqn.client.MsgHelper

object TestTcpClient extends  App{
//  val index = 1
//
//  val server = system.actorOf(Props(new TestTcpServer(index)), "server")
//
//  Thread.sleep(3000)
  val test = Nd4j.zeros(2, 2)
  println(test)

val system = ActorSystem("testSystem")

  val nn = new RandomNN()
  nn.steps()


//  private def canChow(candidate: Int, actionTile: Int): Boolean = {
//
//    val state = Array[Double](0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 2.0, 26.0, 0.0, 0.0, 0.0, 1.0, 18.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 18.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 2.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
//
//
//    (0 until 3).filter(i => {(i + candidate) != actionTile}).count(i => {(state(i + candidate).toInt & 7) > 0}) >= 2
//
//  }
//
//  val rawState = Array[Int](0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0)
//  val tile = 16
//  println("-------------------------> Get steal tile " + tile)
//
//  val acceptTile = tile
//  val candidates = for (i <- math.max(acceptTile - 2, 0) to math.min(acceptTile, 27 - 1 - 2) if canChow(i, tile))
//    yield i
//
//  println("After candidates")
//  println(candidates.mkString(","))
}
