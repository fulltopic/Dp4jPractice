package rl.dqn.reinforcement.supervised

import java.io.{File, FileOutputStream, PrintWriter}
import java.util
import java.util.Map

import org.deeplearning4j.datasets.iterator.BaseDatasetIterator
import org.deeplearning4j.nn.api.OptimizationAlgorithm
import org.deeplearning4j.nn.conf.{ComputationGraphConfiguration, NeuralNetConfiguration}
import org.deeplearning4j.nn.conf.inputs.InputType
import org.deeplearning4j.nn.conf.layers.{DenseLayer, OutputLayer}
import org.deeplearning4j.nn.graph.ComputationGraph
import org.deeplearning4j.nn.weights.WeightInit
import org.deeplearning4j.optimize.api.IterationListener
import org.deeplearning4j.optimize.listeners.ScoreIterationListener
import org.deeplearning4j.rl4j.network.ac.{ActorCriticFactoryCompGraphStdDense, ActorCriticLoss}
import org.deeplearning4j.rl4j.util.Constants
import org.deeplearning4j.ui.api.UIServer
import org.deeplearning4j.ui.stats.StatsListener
import org.deeplearning4j.ui.storage.InMemoryStatsStorage
import org.deeplearning4j.util.ModelSerializer
import org.nd4j.linalg.activations.Activation
import org.nd4j.linalg.api.ndarray.INDArray
import org.nd4j.linalg.learning.config.Adam
import org.nd4j.linalg.lossfunctions.LossFunctions
import rl.dqn.reinforcement.dqn.nn.datapocess.TenhouXmlCnnFetcher
import rl.dqn.reinforcement.dqn.test.TestSupervisedNN.{logFile, modelPath, writeLog}
import rl.dqn.supervised.TileNum
import rl.dqn.supervised.fileprocess.ReplayTransFetcherWoAccept

object SupervisedDense extends App{
  def CreateActorCritic(netConf: ActorCriticFactoryCompGraphStdDense.Configuration, numInputs: Int, numOutputs: Int, supervised: Boolean): ComputationGraph = {
    var inputType = InputType.feedForward(numInputs)
    if (!supervised) inputType = InputType.recurrent(numInputs)

    val confB = new NeuralNetConfiguration.Builder()
      .seed(Constants.NEURAL_NET_SEED).iterations(1)
      .optimizationAlgo(OptimizationAlgorithm.STOCHASTIC_GRADIENT_DESCENT)
      .learningRate(netConf.getLearningRate)
      .updater(new Adam())
    //.updater(Updater.NESTEROVS).momentum(0.9)
    //                        .updater(Updater.RMSPROP).rmsDecay(conf.getRmsDecay())
//    (if (netConf.getUpdater != null) netConf.getUpdater else new Adam)
      .weightInit(WeightInit.XAVIER).regularization(netConf.getL2 > 0)
      .l2(netConf.getL2).graphBuilder
      .setInputTypes(inputType)
      .addInputs("input")
      .addLayer("0", new DenseLayer.Builder().nIn(numInputs).nOut(netConf.getNumHiddenNodes).activation(Activation.RELU).build, "input")

    for (i <- 1 until netConf.getNumLayer) {
      confB.addLayer(i + "", new DenseLayer.Builder().nIn(netConf.getNumHiddenNodes).nOut(netConf.getNumHiddenNodes).activation(Activation.RELU).build, (i - 1) + "")
    }

    if (supervised) {
      confB.addLayer("softmax", new OutputLayer.Builder(LossFunctions.LossFunction.NEGATIVELOGLIKELIHOOD).activation(Activation.SOFTMAX).nOut(numOutputs).build, (netConf.getNumLayer - 1) + "")
      confB.setOutputs("softmax")
    }
    else {
      confB.addLayer("value", new OutputLayer.Builder(LossFunctions.LossFunction.MSE).activation(Activation.IDENTITY).nOut(1).build, (netConf.getNumLayer - 1) + "")
      confB.addLayer("softmax", new OutputLayer.Builder(new ActorCriticLoss).activation(Activation.SOFTMAX).nOut(numOutputs).build, (netConf.getNumLayer - 1) + "")
      confB.setOutputs("value", "softmax")
    }

    val graphConf = confB.asInstanceOf[ComputationGraphConfiguration.GraphBuilder]

    //        confB.inputPreProcessor("0", new TenhouInputPreProcessor());

    val cgconf = graphConf.pretrain(false).backprop(true).build
    val model = new ComputationGraph(cgconf)
    model.init()

    if (netConf.getListeners != null) {
      val listeners = new util.ArrayList[IterationListener]()
      for (listener <- netConf.getListeners) {
        listeners.add(listener)
      }
      model.setListeners(listeners)
    } else model.setListeners(new ScoreIterationListener(Constants.NEURAL_NET_ITERATION_LISTENER))
    model
  }

  def getConfig: ActorCriticFactoryCompGraphStdDense.Configuration = {
    val config = ActorCriticFactoryCompGraphStdDense.Configuration.builder
      .learningRate(1e-2)
      .l2(0)
      .numHiddenNodes(128)
      .numLayer(2)
      .useLSTM(false)
      .build

    config
  }

  def printParamArch(model: ComputationGraph): Unit = {
    val params = model.paramTable
    import scala.collection.JavaConversions._
    for (key <- params.keySet) {
      System.out.println(key)
    }
  }

  def testParam(): Unit = {
    val graph = CreateActorCritic(getConfig, 74, 42, true)
    printParamArch(graph)
    val newGraph = CreateActorCritic(getConfig, 74, 42, false)
    printParamArch(newGraph)
    val params = graph.paramTable
    val newParams = newGraph.paramTable
    import scala.collection.JavaConversions._
    for (key <- params.keySet) {
      if (newParams.containsKey(key)) {
        System.out.println("Set params into " + key)
        newGraph.setParam(key, params.get(key))
      }
    }
  }


  var trainPath: String = ""
  var validPath: String = ""
  var modelPath: String = ""
  var logFile: PrintWriter = null;

  def initLocalPath(): Unit = {
    trainPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/train/"
    validPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/validation/"
    modelPath = "/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/supervised/models/nnmodel"
    logFile = new PrintWriter(new File("/home/zf/workspaces/workspace_java/tenhoulogs/logs/xmlfiles/output.txt"))
  }

  def writeLog(content: String): Unit = {
    logFile.write(content + "\n")
    logFile.flush()
  }

  def train(): Unit = {
    val batchSize = 32
    val iterationNum = 1
    val epochNum = 8

    val trainFetcher = new TenhouXmlCnnFetcher(trainPath, TileNum, true)
    val trainIte = new BaseDatasetIterator(batchSize, iterationNum, trainFetcher)
    val validFetcher = new TenhouXmlCnnFetcher(validPath, TileNum, true)
    val validIte = new BaseDatasetIterator(batchSize, iterationNum, validFetcher)

    val model = CreateActorCritic(getConfig, 74, 42, true)

    val uiServer = UIServer.getInstance
    val statsStorage = new InMemoryStatsStorage
    uiServer.attach(statsStorage)
    model.setListeners(new StatsListener(statsStorage))

    for (i <- 0 until epochNum) {
      trainIte.reset()
      model.fit(trainIte)

      validIte.reset()
      val eval = model.evaluate(validIte)
      //      val eval = new Evaluation()
      //      model.doEvaluation(validIte, eval)


      val stat = eval.stats()
      writeLog("=========================================> Evaluation")
      writeLog(stat)
      println(stat)

      val MJModelFile = new File(modelPath + "_" + System.currentTimeMillis() + ".xml")
      val fos = new FileOutputStream(MJModelFile)
      ModelSerializer.writeModel(model, fos, true)
    }

    writeLog("::::::::::::::::::::::::::::::::::::::::: End of training")
  }

  initLocalPath()
  train()
}
