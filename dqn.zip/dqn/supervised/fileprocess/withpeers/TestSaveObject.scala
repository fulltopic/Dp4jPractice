package rl.dqn.supervised.fileprocess.withpeers

import java.io.{FileInputStream, FileOutputStream, ObjectInputStream, ObjectOutputStream}

import rl.dqn.supervised.utils.ReplayDB
import rl.dqn.supervised.PeerStateLen

object TestSaveObject {
  val xmlFileName = TestFileProcessorWithPeers.dir + "testscene1.xml"
  val objFileName = TestFileProcessorWithPeers.dir + "testscene1.obj"

  def testSave(): Unit = {
    val tester = TestFileProcessorWithPeers.createTester(xmlFileName)
    val db = new ReplayDB()
    tester.save(db)

    val fileStream = new FileOutputStream(objFileName)
    val objStream = new ObjectOutputStream(fileStream)

    objStream.writeObject(db)
    objStream.close()
    fileStream.close()
  }

  def testLoad(): Unit = {
    val tester = TestFileProcessorWithPeers.createTester(xmlFileName)

    val fileStream = new FileInputStream(objFileName)
    val objStream = new ObjectInputStream(fileStream)

    val db: ReplayDB = objStream.readObject().asInstanceOf[ReplayDB]

    println(tester.trans.length)
    println(db.datas.size())
    println("Get the same length of collection ")


    for (i <- tester.trans.indices) {
      val dbTran = db.datas.get(i)
      val xmlTran = tester.trans(i)
      println("=========================> element " + i)
      println(dbTran.getAction == xmlTran.getAction)
      println(dbTran.getReward == xmlTran.getReward)
      println(dbTran.isTerminal == xmlTran.isTerminal)

      println(xmlTran.getNextObservation.eq(dbTran.getNextObservation).sumNumber() == PeerStateLen)

      xmlTran.getObservation.zip(dbTran.getObservation).foreach(tranPair => println(tranPair._1.eq(tranPair._2).sumNumber() == PeerStateLen))
    }

  }

  def main(args: Array[String]): Unit = {
//    testSave()
    testLoad()
  }
}
